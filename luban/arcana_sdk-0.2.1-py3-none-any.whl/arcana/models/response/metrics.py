from __future__ import annotations

from typing import Any, List, Optional

from pydantic import Field

from arcana.models.arcana_api_schema import ArcanaApiSchema
from arcana.models.enums import OutputMode, PortfolioEvaluationMode


class SupportedPortfolioOptions(ArcanaApiSchema):
    evaluation_modes: List[PortfolioEvaluationMode] = Field(examples=[[PortfolioEvaluationMode.BACKTEST]])
    output_modes: List[OutputMode] = Field(examples=[[OutputMode.CUMULATIVE_PERCENTAGE]])
    output_modes_supporting_periodicity: List[OutputMode] = Field(examples=[[OutputMode.CUMULATIVE_PERCENTAGE]])


class Metric(ArcanaApiSchema):
    id: int = Field()
    name: str = Field()
    description: str = Field()
    supported_portfolio_options: SupportedPortfolioOptions
    is_portfolio_only_metric: bool = Field()


class MetricParameterResponse(ArcanaApiSchema):
    name: str = Field()
    value_type: Any = Field()
    supported_values: Optional[List[Any]] = Field(default=None, description="Supported values for the parameter.")
    is_required: Optional[bool] = Field(default=None, description="Whether the parameter is required.")


class SingleMetric(Metric):
    supported_risk_models: list[int] = Field()
    supported_metric_parameters: Optional[List[MetricParameterResponse]] = Field(
        default=None,
        description="Optional parameters to configure the metric.",
        examples=[
            [
                MetricParameterResponse(name="asset_id", value_type="INTEGER"),
                MetricParameterResponse(name="param2", value_type="STRING"),
            ]
        ],
    )
