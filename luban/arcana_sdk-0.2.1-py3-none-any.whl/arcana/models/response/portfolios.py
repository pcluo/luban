# pylint: disable=protected-access, missing-raises-doc, too-many-lines, too-many-lines
from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple, Union

import pandas as pd
from pydantic import Field, PrivateAttr, model_validator
from typing_extensions import deprecated

from arcana.constants.internal import EMAILS_IN_ERROR
from arcana.models.arcana_api_schema import ArcanaApiSchema, PortfolioVisualizationSchema
from arcana.models.common import AssetDetails, Id, Position, Timeseries, format_dataframe_for_display
from arcana.models.enums import (
    OutputMode,
    PerformanceIndicatorEnum,
    Periodicity,
    PointInTimeOutputMode,
    PortfolioEvaluationMode,
    PortfolioType,
    PresetRange,
    TimeGrain,
)
from arcana.models.request import PortfolioUploadRequest
from arcana.models.request.consolidated_models import PortfolioOptimizeRequest

if TYPE_CHECKING:
    from arcana._apis.portfolios.sync_portfolios import _PortfoliosSync


class Portfolio(ArcanaApiSchema):
    id: int = Field()
    name: str = Field()
    type: PortfolioType = Field()
    _portfolios_api: Optional["_PortfoliosSync"] = PrivateAttr(default=None)

    def get_latest_position(self) -> PortfolioData:
        """
        Get the latest position data for a given portfolio.

        Args:

        Returns:
            Latest portfolio position data.

        Raises:
            ValidationError: If the portfolio_id is invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no portfolio is found with the given ID.


        Examples:
            # Get latest positions for a portfolio
            positions = client.get_latest_position()
        """

        if self._portfolios_api is None:
            raise RuntimeError(
                "Portfolio object was not initialized with API context to fetch latest position. "
                "Ensure this Portfolio object was obtained via an SDK method like portfolios.get_all()."
            )
        return self._portfolios_api._get_latest_position(self.id)

    def get_historical_positions(
        self, start_date: Optional[str] = None, end_date: Optional[str] = None
    ) -> TimeseriesHistoricalPortfolioData:
        """
        Get historical position data for a portfolio.

        Args:
            start_date: Optional start date in ISO format (e.g., "2023-01-01"). If not provided, returns all historical data.
            end_date: Optional end date in ISO format (e.g., "2023-12-31"). If not provided, defaults to current date.

        Returns:
            Historical timeseries data.

        Raises:
            ValidationError: If the portfolio_id or dates are invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no portfolio is found with the given ID.

        Examples:
            # Get all historical positions
            positions = client.get_historical_positions(portfolio_id=123)

            # Get historical positions for a specific date range
            positions = client.get_historical_positions(
                portfolio_id=123,
                start_date="2023-01-01",
                end_date="2023-12-31"
            )
        """
        if self._portfolios_api is None:
            raise RuntimeError(
                "Portfolio object was not initialized with API context to fetch historical positions. "
                "Ensure this Portfolio object was obtained via an SDK method like portfolios.get_all()."
            )
        return self._portfolios_api._get_historical_positions(self.id, start_date, end_date)

    def update(self, snapshots: Union[PortfolioUploadRequest, Dict[str, Any]]) -> PortfolioUpdate:
        """
        Update an existing portfolio with new data.

        Args:
            snapshots: The request payload containing the updated data. Can be a dict or PortfolioUploadRequest.
                Must contain:
                - portfolio_name: Name of the portfolio
                - data: List of portfolio snapshots, each containing:
                    - date: Date in ISO format (e.g., "2023-01-01")
                    - aum: Total portfolio value
                    - positions: List of positions, each containing:
                        - asset_id: Optional ID of the asset
                        - ticker: Optional Ticker of the asset
                        - isin: Optional ISIN of the asset
                        - sedol: Optional SEDOL of the asset
                        - ric: Optional RIC of the asset
                        - bloomberg_symbol: Optional Bloomberg symbol of the asset
                        - option_isin: Optional ISIN of the option
                        - option_sedol: Optional SEDOL of the option
                        - option_figi: Optional FIGI of the option
                        - composite_option_figi: Optional Composite FIGI of the option
                        - option_bloomberg_symbol: Optional Bloomberg symbol of the option
                        - sub_asset_class: Optional Sub-asset class of the asset
                        - figi: Optional FIGI of the asset
                        - composite_figi: Optional Composite FIGI of the asset
                        - asset_class: Optional asset class (e.g., "equity")
                        - net_invested: Investment amount

        Returns:
            PortfolioUpdate object.

        Raises:
            ValidationError: If the portfolio_id or request data is invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no portfolio is found with the given ID.
            ConflictError: If a portfolio with the same name already exists.

        Examples:
            ### Update a portfolio with a single snapshot
            snapshots = {
                "portfolio_name": "Updated Portfolio",
                "data": [
                    {
                        "date": "2023-04-01",
                        "aum": 20000000,
                        "positions": [
                            {"asset_id": 1, "asset_class": "equity", "net_invested": 1000000},
                            {"asset_id": 2, "net_invested": 2000000}
                        ]
                    }
                ]
            }
            portfolio = portfolio.update(snapshots=snapshots)

            ### Update a portfolio with multiple snapshots
            snapshots = {
                "portfolio_name": "Updated Portfolio",
                "data": [
                    {
                        "date": "2023-01-01",
                        "aum": 10000000,
                        "positions": [{"asset_id": 1, "net_invested": 1000000}]
                    },
                    {
                        "date": "2023-02-01",
                        "aum": 20000000,
                        "positions": [{"asset_id": 1, "net_invested": 2000000}]
                    }
                ]
            }
            portfolio = portfolio.update(snapshots=snapshots)

            ### Update a portfolio with ticker, isin in positions input.
            snapshots = {
                "portfolio_name": "Updated Portfolio",
                "data": [
                    {
                        "date": "2023-01-01",
                        "aum": 10000000,
                        "positions": [{"ticker": "AAPL US", "asset_class": "EQUITY", "net_invested": 1000000}]
                    }
                ]
            }
            portfolio = portfolio.update(snapshots=snapshots)
        """
        if self._portfolios_api is None:
            raise RuntimeError(
                "Portfolio object was not initialized with API context to update. "
                "Ensure this Portfolio object was obtained via an SDK method like portfolios.get_all()."
            )
        return self._portfolios_api._update(self.id, snapshots)

    def delete(self) -> None:
        if self._portfolios_api is None:
            raise RuntimeError(
                "Portfolio object was not initialized with API context to delete. "
                "Ensure this Portfolio object was obtained via an SDK method like portfolios.get_all()."
            )
        return self._portfolios_api._delete(self.id)

    def share(self, emails: List[str]) -> PortfolioSharing:
        """
        Share a portfolio with a list of users.

        Args:
            emails (List[str]): List of users with which the portfolio should be shared.

        Raises:
            ValidationError: If the emails are invalid.
            BadRequestError: If the portfolio is not sharable.

        Examples:
            ### Share a portfolio with a list of users
            portfolio.share(emails=["user1@example.com", "user2@example.com"])
        """
        if self._portfolios_api is None:
            raise RuntimeError(
                "Portfolio object was not initialized with API context to share. "
                "Ensure this Portfolio object was obtained via an SDK method like portfolios.get_all()."
            )
        return self._portfolios_api._share(self.id, emails)

    def get_timeseries(  # pylint: disable=too-many-arguments
        self,
        metric_id: int,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        preset_range: Optional[PresetRange] = None,
        risk_model_id: int = 3,
        grain: TimeGrain = TimeGrain.DAY,
        evaluation_mode: Optional[PortfolioEvaluationMode] = None,
        output_mode: OutputMode = OutputMode.CUMULATIVE_PERCENTAGE,
        indicator: PerformanceIndicatorEnum = PerformanceIndicatorEnum.GMV,
        aum_override_value: Optional[float] = None,
        use_historical_aum: Optional[bool] = None,
        periodicity: Optional[Periodicity] = None,
        metric_parameters: Optional[Dict[str, Any]] = None,
    ) -> pd.DataFrame:
        """
        Get time series data for a portfolio metric.

        Args:
            metric_id: ID of the metric to fetch. Must be a positive integer.
            start_time: Start time in ISO format (e.g., "2023-01-01"). Required if preset_range is not provided.
            end_time: End time in ISO format (e.g., "2023-12-31"). Required if preset_range is not provided.
            preset_range: Predefined time range. One of ["RANGE_1W", "RANGE_1M", "RANGE_3M", "RANGE_YTD", "RANGE_1Y",
                "RANGE_5Y", "RANGE_MTD", "RANGE_QTD"]. If provided, start_time and end_time are ignored.
            risk_model_id: ID of the risk model to use. Must be a positive integer. Defaults to 3.
            grain: Time grain for the data points. One of ["DAY", "WEEK", "MONTH", "QUARTER", "YEAR"]. Defaults to "DAY".
            evaluation_mode: Optional evaluation mode for the data. One of ["BACKTEST", "HISTORICAL"]. Defaults to "HISTORICAL", if it exists; else "BACKTEST".
            output_mode: Output format for the data. One of ["CUMULATIVE_PERCENTAGE", "CUMULATIVE_DOLLAR", "DAILY_DOLLAR",
                "DAILY_PERCENTAGE", "DOLLAR", "PERCENTAGE"]. Defaults to "CUMULATIVE_PERCENTAGE".
            indicator: Performance indicator to use. One of ["GMV", "AUM"]. Defaults to "GMV".
            aum_override_value: Optional override for the portfolio's AUM value.
            use_historical_aum: Whether to use historical AUM values. If True, aum_override_value is ignored.
            periodicity: Optional frequency override. One of ["DOD", "WOW", "MOM", "QOQ", "YOY"]. Defaults to None.
            metric_parameters: Optional parameters to configure the metric as a dict (e.g., {"asset_id": 21}).
                Defaults to None.
        Returns:
            DataFrame with the timeseries data.

        Raises:
            ValueError: If neither start_time nor preset_range is provided.
            ValidationError: If any of the parameters are invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no portfolio or metric is found with the given IDs.

        Examples:
            # Get daily timeseries data with date range
            timeseries = portfolio.get_timeseries(
                metric_id=37582,
                start_time="2023-01-01"
            )

            # Get timeseries data with preset range
            timeseries = portfolio.get_timeseries(
                metric_id=37582,
                preset_range="RANGE_1M"  # Last month's data
            )

            # Get timeseries with custom settings
            timeseries = portfolio.get_timeseries(
                metric_id=37582,
                start_time="2023-01-01",
                end_time="2023-12-31",
                grain="WEEK",
                evaluation_mode="BACKTEST",
                output_mode="DAILY_PERCENTAGE",
                indicator="AUM",
                aum_override_value=None,
                use_historical_aum=True
                periodicity="WOW"
            )

            # Get timeseries with CUMULATIVE_PERCENTAGE output mode
            timeseries = portfolio.get_timeseries(
                metric_id=37582,
                start_time="2023-01-01",
                output_mode="CUMULATIVE_PERCENTAGE"
            )

            # Get timeseries with CUMULATIVE_DOLLAR output mode
            timeseries = portfolio.get_timeseries(
                metric_id=37582,
                start_time="2023-01-01",
                end_time="2023-12-31",
                grain="WEEK",
                evaluation_mode="BACKTEST",
                output_mode="CUMULATIVE_DOLLAR",
                indicator="GMV",
                periodicity="WOW"
            )

            # Get timeseries with metric parameters
            timeseries = portfolio.get_timeseries(
                metric_id=1000050,
                start_time="2023-01-01",
                end_time="2023-12-31",
                grain="WEEK",
                evaluation_mode="HISTORICAL",
                output_mode="DAILY_PERCENTAGE",
                indicator="GMV",
                metric_parameters={"asset_id": 21}
            )
        """

        if self._portfolios_api is None:
            raise RuntimeError(
                "Portfolio object was not initialized with API context to fetch timeseries. "
                "Ensure this Portfolio object was obtained via an SDK method like portfolios.get_all()."
            )
        return self._portfolios_api._get_timeseries(
            self.id,
            metric_id,
            start_time,
            end_time,
            preset_range,
            risk_model_id,
            grain,
            evaluation_mode,
            output_mode,
            indicator,
            aum_override_value,
            use_historical_aum,
            periodicity,
            metric_parameters,
        )

    def get_timeseries_batch(  # pylint: disable=too-many-arguments
        self,
        metric_ids: List[int],
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        preset_range: Optional[PresetRange] = None,
        risk_model_id: int = 3,
        grain: TimeGrain = TimeGrain.DAY,
        evaluation_mode: Optional[PortfolioEvaluationMode] = None,
        output_mode: OutputMode = OutputMode.CUMULATIVE_PERCENTAGE,
        indicator: PerformanceIndicatorEnum = PerformanceIndicatorEnum.GMV,
        aum_override_value: Optional[float] = None,
        use_historical_aum: Optional[bool] = None,
        periodicity: Optional[Periodicity] = None,
    ) -> Tuple[pd.DataFrame, List[int]]:
        """
        Get time series data for a portfolio metrics.

        Args:
            metric_ids: List of metric IDs to fetch. Must be a list of positive integers.
            start_time: Start time in ISO format (e.g., "2023-01-01"). Required if preset_range is not provided.
            end_time: End time in ISO format (e.g., "2023-12-31"). Required if preset_range is not provided.
            preset_range: Predefined time range. One of ["RANGE_1W", "RANGE_1M", "RANGE_3M", "RANGE_YTD", "RANGE_1Y",
                "RANGE_5Y", "RANGE_MTD", "RANGE_QTD"]. If provided, start_time and end_time are ignored.
            risk_model_id: ID of the risk model to use. Must be a positive integer. Defaults to 3.
            grain: Time grain for the data points. One of ["DAY", "WEEK", "MONTH", "QUARTER", "YEAR"]. Defaults to "DAY".
            evaluation_mode: Optional evaluation mode for the data. One of ["BACKTEST", "HISTORICAL"]. Defaults to "HISTORICAL", if it exists; else "BACKTEST".
            output_mode: Output format for the data. One of ["CUMULATIVE_PERCENTAGE", "CUMULATIVE_DOLLAR", "DAILY_DOLLAR",
                "DAILY_PERCENTAGE", "DOLLAR", "PERCENTAGE"]. Defaults to "CUMULATIVE_PERCENTAGE".
            indicator: Performance indicator to use. One of ["GMV", "AUM"]. Defaults to "GMV".
            aum_override_value: Optional override for the portfolio's AUM value.
            use_historical_aum: Whether to use historical AUM values. If True, aum_override_value is ignored.
            periodicity: Optional frequency override. One of ["DOD", "WOW", "MOM", "QOQ", "YOY"]. Defaults to None.
        Returns:
            Tuple[DataFrame, List[int]]: A tuple containing:
                - DataFrame with the timeseries data.
                - List of invalid metric IDs.

        Raises:
            ValueError: If neither start_time nor preset_range is provided.
            ValidationError: If any of the parameters are invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no portfolio or metric is found with the given IDs.

        Examples:
            # Get daily timeseries data with date range
            timeseries = portfolio.get_timeseries_batch(
                metric_ids=[37582],
                start_time="2023-01-01"
            )

            # Get timeseries data with preset range
            timeseries = portfolio.get_timeseries_batch(
                metric_ids=[37582],
                preset_range="RANGE_1M"  # Last month's data
            )

            # Get timeseries with custom settings
            timeseries = portfolio.get_timeseries_batch(
                metric_ids=[37582],
                start_time="2023-01-01",
                end_time="2023-12-31",
                grain="WEEK",
                evaluation_mode="BACKTEST",
                output_mode="DAILY_PERCENTAGE",
                indicator="AUM",
                aum_override_value=None,
                use_historical_aum=True
                periodicity="WOW"
            )

            # Get timeseries with CUMULATIVE_PERCENTAGE output mode
            timeseries = portfolio.get_timeseries_batch(
                metric_ids=[37582],
                start_time="2023-01-01",
                output_mode="CUMULATIVE_PERCENTAGE"
            )

            # Get timeseries with CUMULATIVE_DOLLAR output mode
            timeseries = portfolio.get_timeseries_batch(
                metric_ids=[37582],
                start_time="2023-01-01",
                end_time="2023-12-31",
                grain="WEEK",
                evaluation_mode="BACKTEST",
                output_mode="CUMULATIVE_DOLLAR",
                indicator="GMV",
                periodicity="WOW"
            )
        """

        if self._portfolios_api is None:
            raise RuntimeError(
                "Portfolio object was not initialized with API context to fetch timeseries batch. "
                "Ensure this Portfolio object was obtained via an SDK method like portfolios.get_all()."
            )
        return self._portfolios_api._get_timeseries_batch(
            self.id,
            metric_ids,
            start_time,
            end_time,
            preset_range,
            risk_model_id,
            grain,
            evaluation_mode,
            output_mode,
            indicator,
            aum_override_value,
            use_historical_aum,
            periodicity,
        )

    def get_summary(
        self,
        risk_model_id: int = 3,
        indicator: PerformanceIndicatorEnum = PerformanceIndicatorEnum.GMV,
        aum_override_value: Optional[float] = None,
        use_historical_aum: Optional[bool] = None,
        as_of_date: Optional[str] = None,
    ) -> PortfolioSummary:
        """
        Get summary analytics for a given portfolio.

        Args:
            risk_model_id: ID of the risk model to use. Must be a positive integer. Defaults to 3.
            indicator: Performance indicator to use. One of ["GMV", "AUM"]. Defaults to "GMV".
            aum_override_value: Optional override for the portfolio's AUM value.
            use_historical_aum: Whether to use historical AUM values. If True, aum_override_value is ignored.
            as_of_date: Optional as of date for the analysis. It should be in YYYY-MM-DD format and for a non-future date. Defaults to None.

        Returns:
            Summary statistics for the portfolio.

        Raises:
            ValidationError: If any of the parameters are invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no portfolio is found with the given ID.

        Examples:
            # Get portfolio summary with default settings
            summary = client.get_summary()

            # Get portfolio summary with custom risk model
            summary = client.get_summary(
                risk_model_id=5,
                indicator="GMV"
            )

            # Get portfolio summary with AUM override
            summary = client.get_summary(
                indicator="AUM",
                aum_override_value=1_000_000.0,
                use_historical_aum=True
            )

            # Get portfolio summary as of historical date
            summary = client.get_summary(
                as_of_date="2025-05-06"
            )
        """
        if self._portfolios_api is None:
            raise RuntimeError(
                "Portfolio object was not initialized with API context to fetch summary. "
                "Ensure this Portfolio object was obtained via an SDK method like portfolios.get_all()."
            )
        return self._portfolios_api._get_summary(
            self.id, risk_model_id, indicator, aum_override_value, use_historical_aum, as_of_date
        )

    def get_performance_summary_stats(
        self,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        preset_range: Optional[PresetRange] = None,
        risk_model_id: int = 3,
        evaluation_mode: Optional[PortfolioEvaluationMode] = None,
        indicator: PerformanceIndicatorEnum = PerformanceIndicatorEnum.GMV,
        aum_override_value: Optional[float] = None,
        use_historical_aum: Optional[bool] = None,
    ) -> PortfolioPerformanceSummaryStats:
        """
        Get performance summary statistics for a portfolio over a time period.

        Args:
            start_time: Start time in ISO format (e.g., "2023-01-01"). Required if preset_range is not provided.
            end_time: End time in ISO format (e.g., "2023-12-31"). Required if preset_range is not provided.
            preset_range: Predefined time range. One of ["RANGE_1W", "RANGE_1M", "RANGE_3M", "RANGE_YTD", "RANGE_1Y",
                "RANGE_5Y", "RANGE_MTD", "RANGE_QTD"]. If provided, start_time and end_time are ignored.
            risk_model_id: ID of the risk model to use. Must be a positive integer. Defaults to 3.
            evaluation_mode: Optional evaluation mode for the data. One of ["BACKTEST", "HISTORICAL"]. Defaults to "HISTORICAL", if it exists; else "BACKTEST".
            indicator: Performance indicator to use. One of ["GMV", "AUM"]. Defaults to "GMV".
            aum_override_value: Optional override for the portfolio's AUM value.
            use_historical_aum: Whether to use historical AUM values. If True, aum_override_value is ignored.

        Returns:
            Performance summary statistics for the portfolio.

        Raises:
            ValueError: If neither start_time nor preset_range is provided.
            ValidationError: If any of the parameters are invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no portfolio is found with the given ID.

        Examples:
            # Get performance summary with date range
            stats = portfolio.get_performance_summary_stats(
                start_time="2023-01-01"
            )

            # Get performance summary with preset range
            stats = portfolio.get_performance_summary_stats(
                preset_range="RANGE_1M"  # Last month's data
            )

            # Get performance summary with custom settings
            stats = portfolio.get_performance_summary_stats(
                start_time="2023-01-01",
                end_time="2023-12-31",
                evaluation_mode="BACKTEST",
                indicator="AUM",
                aum_override_value=1_000_000.0,
                use_historical_aum=True
            )
        """

        if self._portfolios_api is None:
            raise RuntimeError(
                "Portfolio object was not initialized with API context to fetch performance summary stats. "
                "Ensure this Portfolio object was obtained via an SDK method like portfolios.get_all()."
            )
        return self._portfolios_api._get_performance_summary_stats(
            self.id,
            start_time,
            end_time,
            preset_range,
            risk_model_id,
            evaluation_mode,
            indicator,
            aum_override_value,
            use_historical_aum,
        )

    def get_drilldown_data(
        self,
        tab_id: int,
        risk_model_id: int = 3,
        indicator: PerformanceIndicatorEnum = PerformanceIndicatorEnum.GMV,
        aum_override_value: Optional[float] = None,
        use_historical_aum: Optional[bool] = None,
        as_of_date: Optional[str] = None,
    ) -> PortfolioDrillDown:
        """
        Fetch drilldown data for a portfolio tab.

        :param tab_id: ID of the drilldown tab.
        :type tab_id: int
        :param risk_model_id: Risk model ID to use for the analysis. Defaults to 3 (US_INTRADAY_RISK_MODEL_ID).
        :type risk_model_id: int
        :param indicator: Performance indicator to use (e.g., "GMV", "AUM"). Defaults to "GMV".
        :type indicator: str
        :param aum_override_value: Optional override value for AUM. Defaults to None.
        :type aum_override_value: Optional[float]
        :param use_historical_aum: If True, use actual historical AUM. Defaults to None.
        :type use_historical_aum: Optional[bool]
        :param as_of_date: Optional as of date for the analysis. It should be in YYYY-MM-DD format and for a non-future date. Defaults to None.
        :type as_of_date: Optional[str]
        :return: Drilldown data for the specified tab.
        :rtype: PortfolioDrillDown
        :raises:
            ValidationError: If any of the parameters are invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no portfolio or tab is found with the given IDs.
        :example:
            # Get drilldown data with default settings
            drilldown = portfolio.get_drilldown_data(
                tab_id=1
            )

            # Get drilldown data with custom risk model and indicator
            drilldown = portfolio.get_drilldown_data(
                tab_id=1,
                risk_model_id=5,
                indicator="AUM"
            )

            # Get drilldown data with AUM override
            drilldown = portfolio.get_drilldown_data(
                tab_id=1,
                indicator="AUM",
                aum_override_value=1_000_000.0,
                use_historical_aum=True
            )

            # Get drilldown data with as of date
            drilldown = portfolio.get_drilldown_data(
                tab_id=1,
                as_of_date="2025-05-06"
            )
        """

        if self._portfolios_api is None:
            raise RuntimeError(
                "Portfolio object was not initialized with API context to fetch drilldown data. "
                "Ensure this Portfolio object was obtained via an SDK method like portfolios.get_all()."
            )
        return self._portfolios_api._get_drilldown_data(
            self.id, tab_id, risk_model_id, indicator, aum_override_value, use_historical_aum, as_of_date
        )

    def get_factor_exposure_data(
        self,
        risk_factor_id: int,
        risk_model_id: int = 3,
        indicator: PerformanceIndicatorEnum = PerformanceIndicatorEnum.GMV,
        aum_override_value: Optional[float] = None,
        use_historical_aum: Optional[bool] = None,
        as_of_date: Optional[str] = None,
    ) -> PortfolioFactorExposure:
        """
        Fetch factor exposure data for a portfolio.

        :param risk_factor_id: ID of the risk factor.
        :type risk_factor_id: int
        :param risk_model_id: Risk model ID to use for the analysis. Defaults to 3 (US_INTRADAY_RISK_MODEL_ID).
        :type risk_model_id: int
        :param indicator: Performance indicator to use (e.g., "GMV", "AUM"). Defaults to "GMV".
        :type indicator: str
        :param aum_override_value: Optional override value for AUM. Defaults to None.
        :type aum_override_value: Optional[float]
        :param use_historical_aum: If True, use actual historical AUM. Defaults to None.
        :type use_historical_aum: Optional[bool]
        :param as_of_date: Optional as of date for the analysis. It should be in YYYY-MM-DD format and for a non-future date. Defaults to None.
        :type as_of_date: Optional[str]
        :return: Factor exposure analytics for the portfolio.
        :rtype: PortfolioFactorExposure
        :raises:
            ValidationError: If any of the parameters are invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no portfolio or factor is found with the given IDs.
        :example:
            # Get factor exposure data with default settings
            exposure = portfolio.get_factor_exposure_data(
                risk_factor_id=456
            )

            # Get factor exposure data with custom risk model and indicator
            exposure = portfolio.get_factor_exposure_data(
                risk_factor_id=456,
                risk_model_id=5,
                indicator="AUM"
            )

            # Get factor exposure data with AUM override
            exposure = portfolio.get_factor_exposure_data(
                risk_factor_id=456,
                indicator="AUM",
                aum_override_value=1_000_000.0,
                use_historical_aum=True
            )

            # Get factor exposure data with as of date
            exposure = portfolio.get_factor_exposure_data(
                risk_factor_id=456,
                as_of_date="2025-05-06"
            )
        """

        if self._portfolios_api is None:
            raise RuntimeError(
                "Portfolio object was not initialized with API context to fetch factor exposure data. "
                "Ensure this Portfolio object was obtained via an SDK method like portfolios.get_all()."
            )
        return self._portfolios_api._get_factor_exposure_data(
            self.id, risk_factor_id, risk_model_id, indicator, aum_override_value, use_historical_aum, as_of_date
        )

    def get_asset_contribution_data(
        self,
        tab_id: int,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        preset_range: Optional[PresetRange] = None,
        risk_model_id: int = 3,
        evaluation_mode: Optional[PortfolioEvaluationMode] = None,
        indicator: PerformanceIndicatorEnum = PerformanceIndicatorEnum.GMV,
        aum_override_value: Optional[float] = None,
        use_historical_aum: Optional[bool] = None,
    ) -> PortfolioAssetContribution:
        """
        Get asset contribution data for a specific tab over a time period.

        Args:
            tab_id: ID of the asset contribution tab. Must be a positive integer.
            start_time: Start time in ISO format (e.g., "2023-01-01"). Required if preset_range is not provided.
            end_time: End time in ISO format (e.g., "2023-12-31"). Required if preset_range is not provided.
            preset_range: Predefined time range. One of ["RANGE_1W", "RANGE_1M", "RANGE_3M", "RANGE_YTD", "RANGE_1Y",
                "RANGE_5Y", "RANGE_MTD", "RANGE_QTD"]. If provided, start_time and end_time are ignored.
            risk_model_id: ID of the risk model to use. Must be a positive integer. Defaults to 3.
            evaluation_mode: Optional evaluation mode for the data. One of ["BACKTEST", "HISTORICAL"]. Defaults to "HISTORICAL", if it exists; else "BACKTEST".
            indicator: Performance indicator to use. One of ["GMV", "AUM"]. Defaults to "GMV".
            aum_override_value: Optional override for the portfolio's AUM value.
            use_historical_aum: Whether to use historical AUM values. If True, aum_override_value is ignored.

        Returns:
            Asset contribution data for the specified tab.

        Raises:
            ValueError: If neither start_time nor preset_range is provided.
            ValidationError: If any of the parameters are invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no portfolio or tab is found with the given IDs.

        Examples:
            # Get asset contribution data with date range
            contribution = portfolio.get_asset_contribution_data(
                tab_id=1,
                start_time="2023-01-01"
            )

            # Get asset contribution data with preset range
            contribution = portfolio.get_asset_contribution_data(
                tab_id=1,
                preset_range="RANGE_1M"  # Last month's data
            )

            # Get asset contribution data with custom settings
            contribution = portfolio.get_asset_contribution_data(
                tab_id=1,
                start_time="2023-01-01",
                end_time="2023-12-31",
                evaluation_mode="BACKTEST",
                indicator="GMV",
                aum_override_value=1000000
            )
        """
        if self._portfolios_api is None:
            raise RuntimeError(
                "Portfolio object was not initialized with API context to fetch asset contribution data. "
                "Ensure this Portfolio object was obtained via an SDK method like portfolios.get_all()."
            )
        return self._portfolios_api._get_asset_contribution_data(
            self.id,
            tab_id,
            start_time,
            end_time,
            preset_range,
            risk_model_id,
            evaluation_mode,
            indicator,
            aum_override_value,
            use_historical_aum,
        )

    def optimize(self, optimization_constraints: Union[PortfolioOptimizeRequest, Dict[str, Any]]) -> "Portfolio":
        """
        Optimize the portfolio using specified constraints and objectives.

        Args:
            optimization_constraints: The optimization request containing objectives and constraints.
                Can be a dict or PortfolioOptimizeRequest.

        #### Required Parameters

        | Parameter | Type | Description |
        |-----------|------|-------------|
        | `objective` | str | Optimization objective. Valid values: `"sharpe_ratio"`, `"min_volatility"`, `"idio_target"`, `"factor_target"`, `"equal_idiovol"` |

        #### Optional Parameters

        | Parameter | Type | Description | Default |
        |-----------|------|-------------|---------|
        | `risk_model_id` | int | Risk model ID | 3 |
        | `as_of_date` | str | Date for optimization in YYYY-MM-DD format | None |
        | `key_inputs` | dict | Universe configuration and inputs | None |
        | `portfolio_constraints` | dict | Portfolio-level constraints | None |
        | `risk_factor_constraints` | list | Risk factor exposure constraints | None |
        | `metric_constraints` | list | Metric constraints | None |
        | `performance_indicator_options` | dict | Performance indicator settings | None |

        #### Key Inputs Structure

        | Parameter | Type | Description |
        |-----------|------|-------------|
        | `include_portfolios` | list | List of portfolios to include in universe |
        | `exclude_portfolios` | list | List of portfolio IDs to exclude |
        | `idio_target` | float | Target idiosyncratic risk level |
        | `return_assumption` | str | Return assumption methodology: `"user_projected"`, `"equal_return"`, `"conviction_score"`, `"position_size"`, `"idiovol_proportionate"` |
        | `universe_sign` | str | Sign constraint: `"ALL"` (long/short), `"LONG"` (long only), `"SHORT"` (short only) |

        Returns:
            Optimized portfolio configuration.

        Raises:
            ValidationError: If the optimization request data is invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If the portfolio is not found.

        Examples:
            Basic optimization with Sharpe ratio objective:

            optimization_constraint = {
                "risk_model_id": 3,
                "objective": "sharpe_ratio",
                "key_inputs": {
                    "return_assumption": "idiovol_proportionate"
                }
            }
            optimized_portfolio = portfolio.optimize(optimization_constraints=optimization_constraints)

            Basic optimization on a previous day portfolio

            optimization_constraints = {
                "risk_model_id": 3,
                "objective": "sharpe_ratio",
                "key_inputs": {
                    "return_assumption": "idiovol_proportionate"
                },
                "as_of_date": "2025-05-06"
            }
            optimized_portfolio = portfolio.optimize(optimization_constraints=optimization_constraints)
        """
        if self._portfolios_api is None:
            raise RuntimeError(
                "Portfolio object was not initialized with API context to optimize. "
                "Ensure this Portfolio object was obtained via an SDK method like portfolios.get_all()."
            )
        return self._portfolios_api._get_optimized_portfolio(self.id, optimization_constraints)

    def get_snapshot(
        self,
        metric_id: int,
        risk_model_id: int = 3,
        output_mode: PointInTimeOutputMode = PointInTimeOutputMode.PERCENTAGE,
        as_of_date: Optional[str] = None,
        include_asset_breakdown: bool = True,
    ) -> PortfolioMetric:
        """
        Get portfolio snapshot data for the specified metric. Returns asset level breakdown by default.

        Args:
            metric_id: ID of the metric to fetch.
            risk_model_id: ID of the risk model to use.
            output_mode: Output mode for the metric.
            as_of_date: Optional as of date for the analysis. It should be in YYYY-MM-DD format and for a non-future date. Defaults to None.
            include_asset_breakdown: Whether to include asset breakdown in the response. Defaults to True.

        Returns:
            Portfolio snapshot data for the specified metric.

        Raises:
            ValidationError: If any of the parameters are invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no portfolio or metric is found with the given IDs.

        Examples:
            # Get portfolio snapshot with default settings
            portfolio_snapshot = portfolio.get_snapshot(
                metric_id=1234,
                risk_model_id=3,
                output_mode=PointInTimeOutputMode.PERCENTAGE,
                as_of_date="2025-05-06",
                include_asset_breakdown=True
            )

            # Get portfolio snapshot with custom settings
            portfolio_snapshot = portfolio.get_snapshot(
                metric_id=123,
                risk_model_id=3,
                output_mode=PointInTimeOutputMode.DOLLAR,
                as_of_date="2025-05-06",
                include_asset_breakdown=False
            )
        """
        if self._portfolios_api is None:
            raise RuntimeError(
                "Portfolio object was not initialized with API context to fetch asset metrics data. "
                "Ensure this Portfolio object was obtained via an SDK method like portfolios.get_all()."
            )
        return self._portfolios_api._get_snapshot(
            self.id, metric_id, risk_model_id, output_mode, as_of_date, include_asset_breakdown
        )


class ThirteenFPortfolio(Portfolio):
    type: str = Field(default="13F")  # type: ignore

    def update(self, snapshots: Union[PortfolioUploadRequest, Dict[str, Any]]) -> PortfolioUpdate:
        raise RuntimeError("13F portfolios cannot be updated")

    def delete(self) -> None:
        raise RuntimeError("13F portfolios cannot be deleted")

    def get_historical_positions(
        self, start_date: Optional[str] = None, end_date: Optional[str] = None
    ) -> TimeseriesHistoricalPortfolioData:
        raise RuntimeError("13F portfolios do not support historical positions")


class PortfolioUpdate(Id):
    errors: Optional[str] = Field(default=None)


class PortfolioCreate(Id):
    errors: Optional[str] = Field(default=None)


class OptimizedPortfolio(Portfolio):
    id: int = Field(alias="optimized_portfolio_id")

    @model_validator(mode="before")
    @classmethod
    def update_id(cls, values: Dict[str, Any]) -> Dict[str, Any]:
        if isinstance(values, dict):
            if (optimized_portfolio_id := values.get("optimized_portfolio_id")) is not None:
                values["id"] = optimized_portfolio_id
            values["name"] = f"Optimized Portfolio {optimized_portfolio_id}"
            values["type"] = PortfolioType.SAVED_PORTFOLIO
        return values


class PortfolioSharing(ArcanaApiSchema):
    errors: Optional[Any] = Field(default=None, description=EMAILS_IN_ERROR)


class PortfolioData(ArcanaApiSchema):
    data: List[Position] = Field()
    aum: Optional[float] = Field(default=None)

    @deprecated("Use to_df() instead. This will be removed in future versions.")
    def position_df(self) -> pd.DataFrame:
        return pd.DataFrame([position.model_dump() for position in self.data])

    def to_df(self) -> pd.DataFrame:
        return pd.DataFrame([position.model_dump() for position in self.data])

    def __repr__(self) -> str:
        return "AUM: " + str(self.aum) + "\n" + format_dataframe_for_display(self.to_df(), detailed=False)

    def __str__(self) -> str:
        return self.__repr__()


class HistoricalPortfolioData(PortfolioData):
    date: str = Field()

    def __repr__(self) -> str:
        return self.date + "\n" + super().__repr__()


class TimeseriesHistoricalPortfolioData(ArcanaApiSchema):
    data: List[HistoricalPortfolioData]

    def to_df(self) -> pd.DataFrame:
        """
        Convert timeseries of portfolio data (including positions) to a flat DataFrame.

        Returns:
            pd.DataFrame: One row per (date, asset), with columns:
                          [date, aum, asset_id, ticker, net_invested, daily_pnl, tags]

        Example:
            >>> df = response.to_df()
        """
        records = []
        for snapshot in self.data:
            for position in snapshot.data:
                records.append(
                    {
                        "date": snapshot.date,
                        "aum": snapshot.aum,
                        "asset_id": position.asset_id,
                        "ticker": position.ticker,
                        "net_invested": position.net_invested,
                        "daily_pnl": position.daily_pnl,
                        "tags": {tag["key"]: tag["value"] for tag in (position.tags or [])},
                    }
                )

        df = pd.DataFrame(records)
        df["date"] = pd.to_datetime(df["date"], utc=True)
        return df

    def __repr__(self) -> str:
        return format_dataframe_for_display(self.to_df())

    def __str__(self) -> str:
        return self.__repr__()


class PortfolioSummary(PortfolioVisualizationSchema):
    data: Dict[str, Any] = Field()

    def __repr__(self) -> str:
        return json.dumps(self.data, indent=4)

    def __str__(self) -> str:
        return self.__repr__()

    def to_df(self) -> pd.DataFrame:
        return pd.DataFrame(
            [{"key": key, "value": value} for key, value in self.data.items()]  # pylint: disable=no-member
        )


class BreakdownStat(ArcanaApiSchema):
    stat: str = Field()
    value_dollar: Optional[Union[float, str]] = Field(default=None)
    value_number: Optional[Union[float, str]] = Field(default=None)


class SectionBlock(ArcanaApiSchema):
    detailed_breakdown: List[BreakdownStat] = Field()

    def breakdown_df(self) -> pd.DataFrame:
        return pd.DataFrame([breakdown.model_dump() for breakdown in self.detailed_breakdown])

    def __repr__(self) -> str:
        return format_dataframe_for_display(self.breakdown_df(), detailed=False)

    def __str__(self) -> str:
        return self.__repr__()


class PortfolioPerformanceSummaryStats(PortfolioVisualizationSchema):
    data: Dict[str, SectionBlock] = Field()

    def __repr__(self) -> str:
        result = []
        for key, value in self.data.items():  # pylint: disable=no-member
            result.append(f"{key}\n{value.breakdown_df()}\n{'-'*100}")
        return "\n".join(result)

    def __str__(self) -> str:
        return self.__repr__()

    def to_dfs(self) -> Dict[str, pd.DataFrame]:
        return {key: value.breakdown_df() for key, value in self.data.items()}  # pylint: disable=no-member


class FactorBlock(ArcanaApiSchema):
    aggregated_results: Optional[List[dict[str, Any]]] = Field(default=None)
    detailed_breakdown: Optional[List[dict[str, Any]]] = Field(default=None)

    def has_children(self) -> bool:
        return bool(self.detailed_breakdown)

    def get_child_keys(self) -> List[str]:
        if not self.detailed_breakdown:
            return []
        keys = []
        for entry in self.detailed_breakdown:
            if "factor_name" in entry:
                keys.append(entry["factor_name"])
        return keys


class PortfolioDrillDown(ArcanaApiSchema):
    data: List[dict[str, Any]] = Field()

    def __repr__(self) -> str:
        return _get_stringified_data_from_response(self.data)

    def __str__(self) -> str:
        return self.__repr__()

    def to_dfs(self) -> Dict[str, pd.DataFrame]:
        if not self.data or not self.data[0] or not isinstance(self.data[0], dict):
            return {}
        data = self.data[0]
        aggregated_result = data.get("aggregated_results", [])
        detailed_breakdown = data.get("detailed_breakdown", [])
        dfs = {}

        # Add safety check for aggregated_result before accessing index 0
        if aggregated_result:
            aggregated_result[0]["factor_name"] = "Aggregated"
            dfs["Aggregated"] = pd.DataFrame(aggregated_result)

        for idx, category_dict in enumerate(detailed_breakdown):
            category_name = None
            category_aggregated_results = category_dict.get("aggregated_results", [])
            category_drilldown_results = category_dict.get("detailed_breakdown", [])
            total_dict = category_aggregated_results + category_drilldown_results

            # Add safety check for category_aggregated_results before accessing index 0
            if category_aggregated_results:
                category_dict = category_aggregated_results[0]
                raw_factor_name = category_dict.get("factor_name", "")
                category_name = raw_factor_name.lower().replace(":", "").replace(" ", "_").replace('"', "")

                # Ensure category_name is not empty to prevent data loss
                if not category_name.strip():
                    category_name = f"category_{idx}"

                # Handle duplicate keys by appending index if key already exists
                original_name = category_name
                counter = 1
                while category_name in dfs:
                    category_name = f"{original_name}_{counter}"
                    counter += 1

                dfs[category_name] = pd.DataFrame(total_dict)
        return dfs


class PortfolioFactorExposure(ArcanaApiSchema):
    data: List[dict[str, Any]] = Field()

    def __repr__(self) -> str:
        return _format_portfolio_data(self.data[0])

    def __str__(self) -> str:
        return self.__repr__()

    def to_dfs(self) -> Dict[str, pd.DataFrame]:
        if not self.data or not self.data[0] or not isinstance(self.data[0], dict):
            return {}
        return {key: pd.DataFrame(data=value) for key, value in self.data[0].items()}


class PortfolioAssetContribution(ArcanaApiSchema):
    data: List[dict[str, Any]] = Field()

    def __repr__(self) -> str:
        return _format_portfolio_data(self.data[0])

    def __str__(self) -> str:
        return self.__repr__()

    def to_dfs(self) -> Dict[str, pd.DataFrame]:
        if not self.data:
            return {}
        if not self.data[0]:
            return {}
        if not isinstance(self.data[0], dict):
            return {}
        return {key: pd.DataFrame(data=value) for key, value in self.data[0].items()}


class PortfolioMetric(ArcanaApiSchema):
    timestamp: str = Field()
    value: Optional[Union[float, str]] = Field(default=None)
    assets: Optional[List[AssetDetails]] = Field(default=None)

    def __repr__(self) -> str:
        if self.assets:
            df = pd.concat([asset.to_df() for asset in self.assets], ignore_index=True)
            return f"Aggregated Value: {self.value}\n{df.__repr__()}"
        return f"Aggregated Value: {self.value}\n"

    def __str__(self) -> str:
        return self.__repr__()


class PortfolioTimeseries(Timeseries):
    metric_id: int = Field()

    def to_df(self) -> pd.DataFrame:
        df = super().to_df()
        if "value" in df.columns:
            df = df.rename(columns={"value": str(self.metric_id)})
        return df


class PortfolioTimeseriesBatch(ArcanaApiSchema):
    data: List[PortfolioTimeseries] = Field()
    invalid_ids: List[int] = Field(default=[])

    def to_df(self) -> pd.DataFrame:
        if not self.data:
            return pd.DataFrame()
        # Convert each PortfolioTimeseries to a DataFrame and merge on index (timestamp)
        dfs = [timeseries.to_df() for timeseries in self.data]
        # Merge all dataframes on index (timestamp); will align columns by metric_id
        merged = pd.concat(dfs, axis=1, join="outer")
        merged.sort_index(inplace=True)
        return merged

    def __repr__(self) -> str:
        return format_dataframe_for_display(self.to_df())

    def __str__(self) -> str:
        return self.__repr__()


def _format_portfolio_data(data: dict[str, Any]) -> str:
    aggregated = data.get("aggregated_results", [])
    detailed = data.get("detailed_breakdown", [])

    formatted_str = f"Aggregated results: {json.dumps(aggregated, indent=4)}\n"
    if detailed:
        df = pd.DataFrame(detailed)
        formatted_str += f"Detailed breakdown: \n{format_dataframe_for_display(df)}\n"
    return formatted_str


def _get_stringified_data_from_response(data: List[dict[str, Any]]) -> str:
    result = []
    for item in data:
        result.append(f"Aggregated results: {json.dumps(item.get('aggregated_results', []), indent=4)}")

        for breakdown in item.get("detailed_breakdown", []):
            breakdown_str = []
            breakdown_str.append(f"Aggregated results: {json.dumps(breakdown.get('aggregated_results', []), indent=4)}")

            if detailed := breakdown.get("detailed_breakdown", []):
                df = pd.DataFrame(detailed)
                breakdown_str.append(f"Detailed breakdown: \n{format_dataframe_for_display(df)}")

            breakdown_str.append("-" * 100)
            result.append("\n".join(breakdown_str))

    return "\n".join(result)
