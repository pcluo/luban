# pylint: disable=protected-access
from __future__ import annotations

from typing import TYPE_CHECKING, List, Optional

import pandas as pd
from pydantic import ConfigDict, Field, PrivateAttr

from arcana.models.arcana_api_schema import ArcanaApiSchema
from arcana.models.common import IdName, TimestampWithValue, format_dataframe_for_display
from arcana.models.enums import Periodicity, PresetRange, RiskFactorTimeseriesMetric, TimeGrain, TransformMode

if TYPE_CHECKING:
    from arcana._apis.risk_factors.sync_risk_factors import _RiskFactorsSync


class _RiskFactorInner(ArcanaApiSchema):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    id: int = Field()
    name: str = Field()
    description: Optional[str] = Field(None)


class RiskFactor(_RiskFactorInner):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    category: str = Field()
    _risk_factors_api: Optional["_RiskFactorsSync"] = PrivateAttr(default=None)

    def get_timeseries(
        self,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        preset_range: Optional[PresetRange] = None,
        metric: RiskFactorTimeseriesMetric = RiskFactorTimeseriesMetric.TOTAL_RETURN,
        grain: TimeGrain = TimeGrain.DAY,
        risk_model_id: int = 3,
        mode: TransformMode = TransformMode.DAILY,
        periodicity: Optional[Periodicity] = None,
    ) -> pd.DataFrame:
        """
        Retrieve time series data for a specific risk factor.

        Args:
            start_time: Start time in ISO format (e.g., "2023-01-01"). Required if preset_range is not provided.
            end_time: End time in ISO format (e.g., "2023-12-31"). Required if preset_range is not provided.
            preset_range: Predefined time range. One of ["RANGE_1W", "RANGE_1M", "RANGE_3M", "RANGE_YTD", "RANGE_1Y",
                "RANGE_5Y", "RANGE_MTD", "RANGE_QTD"]. If provided, start_time and end_time are ignored.
            metric: The metric to compute over time. One of ["TOTAL_RETURN", "FACTOR_VOL"].
                Defaults to "TOTAL_RETURN".
            grain: Time grain for the data points. One of ["DAY", "WEEK", "MONTH", "QUARTER", "YEAR"]. Defaults to "DAY".
            mode: Output mode for the data. One of ["CUMULATIVE", "DAILY"]. Defaults to "DAILY".
            periodicity: Optional frequency override. One of ["DOD", "WOW", "MOM", "QOQ", "YOY"]. Defaults to None.
            risk_model_id: ID of the risk model. Defaults to 3.

        Returns:
            Time series data for the specified risk factor.

        Raises:
            ValueError: If neither start_time nor preset_range is provided.
            ValidationError: If any of the parameters are invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no risk factor is found with the given ID.
            RuntimeError: If the RiskFactor object was not initialized with API context to fetch timeseries.

        Examples:
            ### Get daily timeseries data with date range
            timeseries = risk_factor.get_timeseries(
                start_time="2023-01-01",
                end_time="2023-12-31"
            )

            ### Get timeseries data with preset range
            timeseries = risk_factor.get_timeseries(
                preset_range="RANGE_1M"  # Last month's data
            )

            ### Get timeseries with custom metric and grain
            timeseries = risk_factor.get_timeseries(
                start_time="2023-01-01",
                end_time="2023-12-31",
                grain="WEEK",
                mode="CUMULATIVE",
                periodicity="MOM"  # Month over Month
            )

            ### Get timeseries with DAILY output mode
            timeseries = risk_factor.get_timeseries(
                start_time="2023-01-01",
                end_time="2023-12-31",
                mode="DAILY",
                grain="WEEK",
                metric="FACTOR_VOL"
            )
        """
        if self._risk_factors_api is None:
            raise RuntimeError(
                "RiskFactor object was not initialized with API context to fetch timeseries. "
                "Ensure this RiskFactor object was obtained via an SDK method like risk_factors.get_all()."
            )

        return self._risk_factors_api._get_timeseries(
            risk_factor_id=self.id,
            start_time=start_time,
            end_time=end_time,
            preset_range=preset_range,
            metric=metric,
            grain=grain,
            risk_model_id=risk_model_id,
            mode=mode,
            periodicity=periodicity,
        )


class RiskFactorCategory(IdName):
    name: str = Field()


class _RiskFactorTimeseries(ArcanaApiSchema):
    risk_factor_id: int = Field()
    name: str = Field()
    short_name: Optional[str] = Field(default=None)
    series: List[TimestampWithValue] = Field()

    def to_df(self) -> pd.DataFrame:
        """
        Convert risk factor timeseries into a pandas DataFrame.
        """
        if not self.series:
            return pd.DataFrame(columns=["timestamp", str(self.risk_factor_id)])
        df = pd.DataFrame(
            [{"timestamp": point.timestamp, str(self.risk_factor_id): point.value} for point in self.series]
        )
        df["timestamp"] = pd.to_datetime(df["timestamp"])
        df.set_index("timestamp", inplace=True)
        return df

    def __repr__(self) -> str:
        return format_dataframe_for_display(self.to_df(), detailed=False)

    def __str__(self) -> str:
        return self.__repr__()


class BatchRiskFactorTimeseries(ArcanaApiSchema):
    data: List[_RiskFactorTimeseries]
    invalid_ids: List[int] = Field(default=[])

    def to_df(self) -> pd.DataFrame:
        """
        Convert batch risk factor timeseries into a wide-form pandas DataFrame,
        with each risk factor as a column.
        """
        # Use to_df of each _RiskFactorTimeseries and merge their dataframes column-wise
        dfs = []
        for ts in self.data:
            df = ts.to_df().copy()
            dfs.append(df)
        if not dfs:
            return pd.DataFrame()
        merged_df = pd.concat(dfs, axis=1)
        return merged_df

    def __repr__(self) -> str:
        return format_dataframe_for_display(self.to_df(), detailed=False)

    def __str__(self) -> str:
        return self.__repr__()
