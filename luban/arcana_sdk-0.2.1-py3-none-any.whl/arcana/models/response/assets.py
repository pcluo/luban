# pylint: disable=protected-access, missing-raises-doc
from __future__ import annotations

from typing import TYPE_CHECKING, Any, List, Optional

import pandas as pd
from pydantic import Field, PrivateAttr

from arcana.models.arcana_api_schema import ArcanaApiSchema
from arcana.models.common import TimestampWithValue, format_dataframe_for_display
from arcana.models.enums import Periodicity, PresetRange, TimeGrain, TransformMode

if TYPE_CHECKING:
    from arcana._apis.assets.sync_assets import _AssetsSync  # For type hint
    from arcana.models.common import Timeseries  # For return type hint


class Asset(ArcanaApiSchema):
    """
    Response schema representing an asset and its identifiers.

    Attributes:
        id (int): Unique identifier of the asset.
        ticker (str): Ticker symbol of the asset.
        name (str): Full name of the asset.
        asset_type (Optional[str]): Type of the asset (e.g., equity, option).
        exchange (str): The exchange where the asset is listed.
        country (str): Country of the exchange or asset issuance.
        currency (Optional[str]): Trading or denomination currency.
        isin (Optional[str]): International Securities Identification Number.
        sedol (Optional[str]): Stock Exchange Daily Official List code.
        cusip (Optional[str]): CUSIP identifier for the asset.
        figi (str): Financial Instrument Global Identifier.
        open_figi_ticker (Optional[str]): OpenFIGI ticker, if available.
        composite_figi (str): Composite FIGI identifier.

    Example:
        >>> Asset(
        ...     id=1,
        ...     ticker="AAPL",
        ...     name="Apple Inc.",
        ...     asset_type="equity",
        ...     exchange="NASDAQ",
        ...     country="US",
        ...     currency="USD",
        ...     isin="US0378331005",
        ...     sedol="2046251",
        ...     cusip="037833100",
        ...     figi="BBG000B9XRY4",
        ...     open_figi_ticker="AAPL",
        ...     composite_figi="BBG000B9XRY4"
        ... )
    """

    id: int = Field()
    ticker: str = Field(description="Ticker symbol of the asset.")
    name: str = Field()
    asset_type: Optional[str] = Field(default=None)
    exchange: str = Field()
    country: str = Field()
    currency: Optional[str] = Field(default=None)
    isin: Optional[str] = Field(default=None)
    sedol: Optional[str] = Field(default=None)
    cusip: Optional[str] = Field(default=None)
    figi: str = Field()
    open_figi_ticker: Optional[str] = Field(default=None)
    composite_figi: str = Field()

    _assets_api: Optional["_AssetsSync"] = PrivateAttr(default=None)

    def get_timeseries(
        self,
        metric_id: int,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        preset_range: Optional[PresetRange] = None,
        risk_model_id: int = 3,
        grain: TimeGrain = TimeGrain.DAY,
        mode: TransformMode = TransformMode.DAILY,
        periodicity: Optional[Periodicity] = None,
    ) -> pd.DataFrame:
        """
        Fetch time series data for a single asset and a single metric.

        Args:
            metric_id: The ID of the metric to fetch time series data for.
            start_time: Start time in ISO format (e.g., "2023-01-01"). Required if preset_range is not provided.
            end_time: End time in ISO format (e.g., "2023-12-31"). Required if preset_range is not provided.
            preset_range: Predefined time range. One of ["RANGE_1W", "RANGE_1M", "RANGE_3M", "RANGE_YTD", "RANGE_1Y",
                "RANGE_5Y", "RANGE_MTD", "RANGE_QTD"]. If provided, start_time and end_time are ignored.
            risk_model_id: ID of the risk model to use. Must be a positive integer. Defaults to 3.
            grain: Time grain for the data points. One of ["DAY", "WEEK", "MONTH", "QUARTER", "YEAR"]. Defaults to "DAY".
            risk_model_id: ID of the risk model to use. Defaults to 3 (US Intraday).
            mode: Data aggregation mode. One of ["DAILY", "CUMULATIVE"]. Defaults to "DAILY".
            periodicity: Optional frequency override. One of ["DOD", "WOW", "MOM", "QOQ", "YOY"]. Defaults to None.

        Returns:
            DataFrame with the timeseries data.

        Raises:
            ValueError: If neither start_time nor preset_range is provided.
            ValidationError: If any of the parameters are invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no asset is found with the given ID.

        Examples:
            # Get daily data for a specific date range
            timeseries = asset.get_timeseries(
                metric_id=37582,
                start_time="2023-01-01",
                end_time="2023-12-31"
            )

            # Get timeseries data with preset range
            timeseries = asset.get_timeseries(
                metric_id=37582,
                preset_range="RANGE_1M"  # Last month's data
            )

            # Get data from start time to current datetime
            timeseries = asset.get_timeseries(
                metric_id=37582,
                start_time="2023-01-01"
            )

            # Get data with custom grain and mode
            timeseries = asset.get_timeseries(
                metric_id=37582,
                start_time="2023-01-01",
                end_time="2023-12-31",
                grain="WEEK",
                mode="CUMULATIVE",
                periodicity="MOM"  # Month over Month
            )

            # Get data with periodicity
            timeseries = asset.get_timeseries(
                metric_id=37582,
                start_time="2023-01-01",
                mode="DAILY"
            )
        """

        if self._assets_api is None:
            raise RuntimeError(
                "Asset object was not initialized with API context to fetch timeseries. "
                "Ensure this Asset object was obtained via an SDK method like assets.get_by_id()."
            )
        # Ensure Timeseries is resolvable, string literal in return type helps with this.
        # from arcana.models.common import Timeseries # Could be imported here if needed.

        return self._assets_api._get_timeseries(
            asset_id=self.id,
            metric_id=metric_id,
            start_time=start_time,
            end_time=end_time,
            preset_range=preset_range,
            risk_model_id=risk_model_id,
            grain=grain,
            mode=mode,
            periodicity=periodicity,
        )


class SingleAssetSearch(ArcanaApiSchema):
    asset_id: Optional[int] = Field(default=None)
    ticker: Optional[str] = Field(default=None)
    name: Optional[str] = Field(default=None)
    open_figi_ticker: Optional[str] = Field(default=None)
    figi: Optional[str] = Field(default=None)
    country: Optional[str] = Field(default=None)
    currency: Optional[str] = Field(default=None)
    isin: Optional[str] = Field(default=None)
    sedol: Optional[str] = Field(default=None)


class AssetSearch(ArcanaApiSchema):
    data: List[SingleAssetSearch] = Field()

    def to_df(self) -> pd.DataFrame:
        return pd.DataFrame([asset.model_dump() for asset in self.data])


class AssetTimeseries(ArcanaApiSchema):
    asset_id: int = Field()
    ticker: Optional[str] = Field(default=None)
    series: List[TimestampWithValue] = Field()

    def to_df(self) -> pd.DataFrame:
        """
        Convert asset timeseries data into a pandas DataFrame.

        Returns:
            pd.DataFrame: DataFrame with datetime index and a single 'value' column.

        Example:
            >>> df = response.to_df()
            >>> df.plot(title=response.ticker or str(response.asset_id))
        """
        if not self.series:
            return pd.DataFrame()
        df = pd.DataFrame([{"timestamp": s.timestamp, "value": s.value} for s in self.series])
        df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
        df.set_index("timestamp", inplace=True)
        return df

    def __repr__(self) -> str:
        return format_dataframe_for_display(self.to_df(), detailed=False)

    def __str__(self) -> str:
        return self.__repr__()


class _BatchEntityTimeseries(ArcanaApiSchema):
    data: List[Any] = Field()
    invalid_ids: Optional[List[int]] = Field(default=None)


class BatchAssetTimeseries(_BatchEntityTimeseries):
    data: List[AssetTimeseries]

    def to_df(self) -> pd.DataFrame:
        """
        Convert batch asset timeseries into a long-form pandas DataFrame.

        Returns:
            pd.DataFrame: Flattened DataFrame with columns:
                ['timestamp', 'value', 'asset_id', 'ticker']

        Example:
            >>> df = batch_response.to_df()
            >>> df[df["ticker"] == "AAPL"].plot(x="timestamp", y="value")
        """
        records = []
        for asset_series in self.data:
            for point in asset_series.series:
                records.append(
                    {
                        "timestamp": point.timestamp,
                        "value": point.value,
                        "asset_id": asset_series.asset_id,
                        "ticker": asset_series.ticker,
                    }
                )
        if not records:
            return pd.DataFrame()
        df = pd.DataFrame(records)
        df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
        return df

    def __repr__(self) -> str:
        return format_dataframe_for_display(self.to_df(), detailed=False)

    def __str__(self) -> str:
        return self.__repr__()
