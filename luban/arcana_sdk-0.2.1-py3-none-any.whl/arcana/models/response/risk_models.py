from __future__ import annotations

from pydantic import Field

from arcana.models.arcana_api_schema import ArcanaApiSchema


class RiskModel(ArcanaApiSchema):
    name: str = Field()
    description: str = Field()
    id: int = Field()
