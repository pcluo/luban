from __future__ import annotations

from typing import Any, Dict, List, Optional, Union

import pandas as pd
from pydantic import AliasChoices, Field, model_validator

from arcana.constants.internal import US_INTRADAY_RISK_MODEL_ID
from arcana.models.arcana_api_schema import ArcanaApiRequestSchema, ArcanaApiSchema
from arcana.models.enums import Periodicity, PresetRange, TimeGrain, TransformMode


def format_dataframe_for_display(df: pd.DataFrame, detailed: bool = True) -> str:
    """
    Standardized DataFrame formatting for consistent display across the SDK.

    Args:
        df: The pandas DataFrame to format
        detailed: If True, uses detailed formatting with row/column limits and dimensions.
                 If False, uses default pandas formatting.

    Returns:
        Formatted string representation of the DataFrame
    """
    if detailed:
        return df.to_string(max_rows=60, max_cols=10, show_dimensions=True, min_rows=10, max_colwidth=50)
    return df.to_string()


class RiskModelRequest(ArcanaApiRequestSchema):
    """
    Base request schema including the risk model identifier.

    Attributes:
        risk_model_id (int): ID of the risk model to use.

    Example:
        >>> RiskModelRequest(risk_model_id=3)
    """

    risk_model_id: int = Field(default=US_INTRADAY_RISK_MODEL_ID)


class TimeRange(ArcanaApiRequestSchema):
    """
    Represents a flexible date range or preset time window. One of start_time/preset_range shoud be provided.
    `end_time` defaults to today if only current time is provided.

    Attributes:
        start_time (Optional[str]): Start of the date range in ISO format.
        end_time (Optional[str]): End of the date range in ISO format.
        preset_range (Optional[PresetRange]): Named range (e.g., PresetRange.RANGE_1W).

    Example:
        >>> TimeRange(start_time="2023-01-01", end_time="2023-06-30")
    """

    start_time: Optional[str] = Field(default=None)
    end_time: Optional[str] = Field(default=None)
    preset_range: Optional[PresetRange] = Field(default=None)


class TimeRangeWithGrain(TimeRange):
    """
    Time range with an additional grain (e.g., DAY).

    Attributes:
        start_time (Optional[str]): Start of the range in ISO Format.
        end_time (Optional[str]): End of the range in ISO Format.
        preset_range (Optional[PresetRange]): Predefined window.
        grain (Optional[TimeGrain]): Granularity of the data (default: DAY).

    Example:
        >>> TimeRangeWithGrain(
        ...     start_time="2024-01-01",
        ...     end_time="2024-01-31",
        ...     grain=TimeGrain.DAY
        ... )
    """

    grain: Optional[TimeGrain] = Field(default=TimeGrain.DAY)


class TimestampWithValue(ArcanaApiSchema):
    """
    Single point in a timeseries: timestamp and value.

    Attributes:
        timestamp (str): Date/time in ISO format.
        value (Optional[float | str]): Associated numeric value.

    Example:
        >>> TimestampWithValue(timestamp="2025-02-26T16:00:00-05:00", value=123.45)
    """

    timestamp: str = Field()
    value: Optional[Union[float, str]] = Field(default=None)


class Timeseries(ArcanaApiSchema):
    """
    Timeseries container response.

    Attributes:
        data (List[TimestampWithValue]): Sequence of timestamped values.

    Example:
        >>> Timeseries(
        ...     data=[
        ...         TimestampWithValue(timestamp="2024-01-01T16:00:00-05:00", value=100.0),
        ...         TimestampWithValue(timestamp="2024-01-02T16:00:00-05:00", value=102.5)
        ...     ]
        ... )
    """

    data: List[TimestampWithValue] = Field(validation_alias=AliasChoices("data", "series"))

    def to_df(self) -> pd.DataFrame:
        """
        Convert the timeseries data into a pandas DataFrame.

        Returns:
            pd.DataFrame: A DataFrame with 'timestamp' as index and 'value' as a column.

        Example:
            >>> df = response.to_df()
            >>> df.head()
        """
        if not self.data:
            return pd.DataFrame()
        df = pd.DataFrame([{"timestamp": item.timestamp, "value": item.value} for item in self.data])
        df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
        df.set_index("timestamp", inplace=True)
        return df

    def __repr__(self) -> str:
        return format_dataframe_for_display(self.to_df())

    def __str__(self) -> str:
        return self.__repr__()


class SingleEntityTimeseriesRequest(RiskModelRequest):
    """
    Request schema for timeseries data of a single entity (asset/risk_factor).

    Attributes:
        risk_model_id (int): Risk model to evaluate against.
        time_range (TimeRangeWithGrain): Date range and grain.
        mode (TransformMode): Type of transformation to apply. DAILY Implies raw data, CUMULATIVE uses Frongello calculation
        periodicity (Optional[Periodicity]): Optional aggregation frequency.

    Example:
        >>> SingleEntityTimeseriesRequest(
        ...     risk_model_id=5,
        ...     time_range=TimeRangeWithGrain(
        ...         start_time="2024-01-01",
        ...         end_time="2024-02-01",
        ...         grain="DAY"
        ...     ),
        ...     mode="DAILY"
        ... )
    """

    time_range: TimeRangeWithGrain
    mode: TransformMode
    periodicity: Optional[Periodicity] = Field(default=None)


class IdName(ArcanaApiSchema):
    """
    Basic identifier and name response.

    Attributes:
        id (int): Numeric ID.
        name (str): Human-readable name.

    Example:
        >>> IdNameResponse(id=21, name="SPY")
    """

    id: int = Field()
    name: str = Field()

    def __repr__(self) -> str:
        return f"(Id={self.id}, Name={self.name})"


class Id(ArcanaApiSchema):
    """
    Response carrying a single ID field.

    Attributes:
        id (int): Identifier value.

    Example:
        >>> IdResponse(id=42)
    """

    id: int = Field()


class KeyValuePair(ArcanaApiSchema):
    """
    Represents a key-value tag for extensible metadata.

    Attributes:
        key (str): Name of the tag.
        value (Union[str, int, float, bool]): Value associated with the key.

    Example:
        >>> KeyValuePair(key="region", value="US")
    """

    key: str = Field()
    value: Union[str, int, float, bool] = Field()


class Position(ArcanaApiSchema):
    """
    Representation of a portfolio position.

    Attributes:
        asset_id (int): Unique asset identifier.
        ticker (Optional[str]): Ticker symbol.
        net_invested (StrictFloat): Investment in the asset for the day.
        daily_pnl (Optional[float]): Daily profit or loss.
        tags (Optional[List[Dict[str, str]]]): Arbitrary metadata tags.

    Example:
        >>> Position(
        ...     asset_id=1001,
        ...     ticker="AAPL",
        ...     net_invested=50000.0,
        ...     daily_pnl=250.0,
        ...     tags=[KeyValuePair(key="sector", value="tech")]
        ... )
    """

    asset_id: Optional[int] = Field(default=None)
    ticker: Optional[str] = Field(default=None)
    net_invested: Optional[float] = Field(default=None)
    daily_pnl: Optional[float] = Field(default=None)
    delta_exposure: Optional[float] = Field(default=None)
    tags: Optional[List[Dict[str, Union[str, float]]]] = Field(default=None)

    @model_validator(mode="before")
    @classmethod
    def validate_asset_id(cls, data: Any) -> Any:
        """
        Ensures that either net_invested, daily_pnl, or delta_exposure is provided.
        """
        if isinstance(data, dict):
            if (
                data.get("net_invested") is None
                and data.get("daily_pnl") is None
                and data.get("delta_exposure") is None
            ):
                raise ValueError("Either net_invested, daily_pnl, or delta_exposure must be provided.")
        return data


class AssetDetails(ArcanaApiSchema):
    """
    Representation of an asset in a portfolio.

    Attributes:
        asset_id (int): Unique asset identifier.
        ticker (str): Ticker symbol.
        value (Optional[float]): Value of the asset.

    Example:
        >>> AssetDetails(asset_id=1, ticker="AAPL", value=100.0)
    """

    asset_id: int = Field()
    ticker: str = Field()
    value: Union[Optional[float], Optional[str]] = Field(default=None)

    def to_df(self) -> pd.DataFrame:
        """
        Convert the asset details into a pandas DataFrame.
        """
        return pd.DataFrame([{"asset_id": self.asset_id, "ticker": self.ticker, "value": self.value}])

    def __repr__(self) -> str:
        return f"Asset ID: {self.asset_id}, Ticker: {self.ticker}, Value: {self.value}"

    def __str__(self) -> str:
        return self.__repr__()
