from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Union

from pydantic import Field, field_validator, model_validator

from arcana.constants.internal import US_INTRADAY_RISK_MODEL_ID
from arcana.models.arcana_api_schema import ArcanaApiRequestSchema
from arcana.models.common import (
    Position,
    RiskModelRequest,
    SingleEntityTimeseriesRequest,
    TimeRange,
    TimeRangeWithGrain,
)
from arcana.models.enums import (
    AssetIdentifiersEnum,
    MetricContainerCategory,
    OptimizationObjective,
    OutputMode,
    PerformanceIndicatorEnum,
    Periodicity,
    PointInTimeOutputMode,
    PortfolioEvaluationMode,
    PortfolioType,
    PortfolioUploadType,
    ReturnAssumption,
    RiskFactorTimeseriesMetric,
    UniverseSign,
)


# Portfolio Models
class PortfoliosFilterSchema(ArcanaApiRequestSchema):
    """
    Filter schema for querying portfolios by name.

    Attributes:
        name (Optional[int]): The name of the portfolio.

    Example:
        >>> PortfoliosFilterSchema(name="SDK Test Portfolio")
    """

    name: Optional[int] = Field(default=None)


class PortfoliosExtendedFilterSchema(PortfoliosFilterSchema):
    """
    Filter schema for querying portfolios by name and type.

    Attributes:
        name (Optional[int]): The name or identifier of the portfolio.
        type (Optional[PortfolioType]): The portfolio type.

    Example:
        >>> PortfoliosExtendedFilterSchema(name="SDK Test Portfolio", type=PortfolioType.SAVED_PORTFOLIO)
    """

    type: Optional[PortfolioType] = Field(default=None)


class PortfoliosDateFilterSchema(ArcanaApiRequestSchema):
    """
    Filter schema for specifying a start and end date range.

    Attributes:
        start_date (Optional[str]): Start date in "YYYY-MM-DD" format.
        end_date (Optional[str]): End date in "YYYY-MM-DD" format.

    Example:
        >>> PortfoliosDateFilterSchema(start_date="2025-04-01", end_date="2025-05-01")
    """

    start_date: Optional[str] = Field(default=None)
    end_date: Optional[str] = Field(default=None)


class PositionWithAssetClass(Position):
    """
    Extension of the Position model to include asset classification and related identifiers.

    Attributes:
        asset_class (Optional[str]): Classification of the asset.
        isin (Optional[str]): ISIN of the asset.
        sedol (Optional[str]): SEDOL of the asset.
        ric (Optional[str]): RIC of the asset.
        bloomberg_symbol (Optional[str]): Bloomberg symbol of the asset.
        option_isin (Optional[str]): ISIN of the option.
        option_sedol (Optional[str]): SEDOL of the option.
        option_figi (Optional[str]): FIGI of the option.
        composite_option_figi (Optional[str]): Composite FIGI of the option.
        option_bloomberg_symbol (Optional[str]): Bloomberg symbol of the option.
        sub_asset_class (Optional[str]): Sub-asset class of the asset.
        figi (Optional[str]): FIGI of the asset.
        composite_figi (Optional[str]): Composite FIGI of the asset.

    Example:
        >>> PositionWithAssetClass(asset_id=1, asset_class="equity", net_invested=1000000)
    """

    asset_class: Optional[str] = Field(default=None)
    isin: Optional[str] = Field(default=None)
    sedol: Optional[str] = Field(default=None)
    ric: Optional[str] = Field(default=None)
    bloomberg_symbol: Optional[str] = Field(default=None)
    option_isin: Optional[str] = Field(default=None)
    option_sedol: Optional[str] = Field(default=None)
    option_figi: Optional[str] = Field(default=None)
    composite_option_figi: Optional[str] = Field(default=None)
    option_bloomberg_symbol: Optional[str] = Field(default=None)
    sub_asset_class: Optional[str] = Field(default=None)
    figi: Optional[str] = Field(default=None)
    composite_figi: Optional[str] = Field(default=None)


class TimedSecuritiesInfo(ArcanaApiRequestSchema):
    """
    Snapshot of portfolio data at a specific date.

    Attributes:
        date (str): Date of the snapshot.
        aum (Optional[float]): Assets under management for the date.
        positions (List[PositionWithAssetClass]): List of positions.

    Example:
        >>> TimedSecuritiesInfo(
        ...     date="2025-04-01",
        ...     aum=10000000,
        ...     positions=[
        ...         PositionWithAssetClass(asset_id=1, asset_class="equity", net_invested=1000000),
        ...         PositionWithAssetClass(asset_id=2, net_invested=2000000)
        ...     ]
        ... )
    """

    date: str = Field()
    aum: Optional[float] = Field(default=None)
    positions: List[PositionWithAssetClass] = Field()


class PortfolioSharingRequest(ArcanaApiRequestSchema):
    """
    Request schema for sharing a portfolio.

    Attributes:
        user_emails (List[str]): List of users with which the portfolio should be shared
    """

    user_emails: List[str] = Field(
        description="List of users with which the portfolio should be shared",
        examples=[["user1@example.com", "user2@example.com"]],
    )

    @model_validator(mode="after")
    def validate_user_emails(self) -> PortfolioSharingRequest:
        if not self.user_emails:
            raise ValueError("user_emails must not be empty")

        email_pattern = re.compile(r"(^[\w\.\+\-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)")
        for email in self.user_emails:
            if not isinstance(email, str) or not email_pattern.match(email):
                raise ValueError(f"Invalid email format: {email}")
        return self


class PortfolioUploadRequest(ArcanaApiRequestSchema):
    """
    Request schema for uploading a time series of portfolio snapshots.

    Attributes:
        portfolio_name (Optional[str]): Name of the portfolio.
        data (List[TimedSecuritiesInfo]): Time series of dated portfolio data.

    Example:
        >>> PortfolioUploadRequest(
        ...     portfolio_name="SDK Test Portfolio",
        ...     data=[
        ...         TimedSecuritiesInfo(
        ...             date="2025-04-01",
        ...             aum=20000000,
        ...             positions=[
        ...                 PositionWithAssetClass(asset_id=1, asset_class="equity", net_invested=1000000),
        ...                 PositionWithAssetClass(asset_id=2, net_invested=2000000)
        ...             ]
        ...         )
        ...     ]
        ... )
    """

    portfolio_name: Optional[str] = Field(default=None)
    portfolio_type: PortfolioUploadType = Field(default=PortfolioUploadType.SAVED_PORTFOLIO)
    data: Optional[List[TimedSecuritiesInfo]] = Field(default=None)


class IndicatorAndOverrideOptions(ArcanaApiRequestSchema):
    """
    Configuration for selecting a performance indicator and optionally overriding the default mode set for the portfolio.

    Attributes:
        indicator (PerformanceIndicatorEnum): Performance metric to use (default: GMV).
        aum_override_value (Optional[float]): User-defined override for AUM.

    Example:
        >>> IndicatorAndOverrideOptions(
        ...     indicator=PerformanceIndicatorEnum.AUM,
        ...     aum_override_value=1_000_000.0
        ... )
    """

    indicator: PerformanceIndicatorEnum = Field(default=PerformanceIndicatorEnum.GMV)
    aum_override_value: Optional[float] = Field(default=None)


class PerformanceIndicatorOptions(IndicatorAndOverrideOptions):
    """
    Extended indicator config with toggle for historical AUM usage.

    Attributes:
        indicator (PerformanceIndicatorEnum): Chosen performance metric.
        aum_override_value (Optional[float]): Override for assets under management.
        use_historical_aum (Optional[bool]): If True, use actual historical AUM.

    Example:
        >>> PerformanceIndicatorOptions(
        ...     indicator=PerformanceIndicatorEnum.GMV,
        ...     aum_override_value=None,
        ...     use_historical_aum=True
        ... )
    """

    use_historical_aum: Optional[bool] = Field(default=None, examples=[True])


# TODO: Clean up this model when we refactor the model codegen
class TimeMachinePerfIndicatorRequestWithRiskModel(RiskModelRequest):
    """
    Request for performance indicator calculation using a risk model as of historical date.

    Attributes:
        performance_indicator_options (PerformanceIndicatorOptions): Settings for performance metrics.
        as_of_date (Optional[str]): Date for which the data is being submitted. Must be in YYYY-MM-DD format and for a non-future date.

    Example:
        >>> TimeMachinePerfIndicatorRequestWithRiskModel(
        ...     risk_model_id=5,
        ...     performance_indicator_options=PerformanceIndicatorOptions(),
        ...     as_of_date="2025-05-06"
        ... )
    """

    performance_indicator_options: PerformanceIndicatorOptions = Field(default=PerformanceIndicatorOptions())
    as_of_date: Optional[str] = Field(default=None)


class TimedHistoricalRequest(RiskModelRequest):
    """
    Request schema for backtesting or evaluating historical portfolio performance.

    Attributes:
        time_range (TimeRange): Date range for evaluation.
        evaluation_mode (Optional[PortfolioEvaluationMode]): Mode of evaluation.
        performance_indicator_options (PerformanceIndicatorOptions): Settings for performance metrics.

    Example:
        >>> TimedHistoricalRequest(
        ...     risk_model_id=5,
        ...     time_range=TimeRange(start_time="2023-01-01", end_time="2023-12-31"),
        ...     evaluation_mode=PortfolioEvaluationMode.BACKTEST,  # or None
        ...     performance_indicator_options=PerformanceIndicatorOptions()
        ... )
    """

    time_range: TimeRange
    evaluation_mode: Optional[PortfolioEvaluationMode] = Field(default=None)
    performance_indicator_options: PerformanceIndicatorOptions = Field(default=PerformanceIndicatorOptions())


class PortfolioOptions(ArcanaApiRequestSchema):
    """
    Settings that control portfolio evaluation behavior.

    Attributes:
        evaluation_mode (Optional[PortfolioEvaluationMode]): Evaluation method (e.g., BACKTEST).
        output_mode (OutputMode): How output values are formatted or scaled.

    Example:
        >>> PortfolioOptions(
        ...     evaluation_mode=PortfolioEvaluationMode.HISTORICAL,  # or None
        ...     output_mode=OutputMode.DAILY_PERCENTAGE
        ... )
    """

    evaluation_mode: Optional[PortfolioEvaluationMode] = Field(default=None)
    output_mode: OutputMode = Field(default=OutputMode.CUMULATIVE_PERCENTAGE)


class InclusionUniverse(ArcanaApiRequestSchema):
    """
    Configuration for including portfolios in optimization universe.

    Attributes:
        portfolio_id (int): ID of the portfolio to include.
        total_basket_size_pct (Optional[float]): Total basket size as percentage.
        max_pct_basket_concentration (Optional[float]): Maximum concentration percentage per basket.

    Example:
        >>> InclusionUniverse(portfolio_id=123, total_basket_size_pct=50.0)
    """

    portfolio_id: int = Field()
    total_basket_size_pct: Optional[float] = Field(default=None)
    max_pct_basket_concentration: Optional[float] = Field(default=None)


class KeyInput(ArcanaApiRequestSchema):
    """
    Key inputs for portfolio optimization.

    Attributes:
        include_portfolios (Optional[List[InclusionUniverse]]): Portfolios to include in universe.
        exclude_portfolios (Optional[List[int]]): Portfolio IDs to exclude from universe.
        idio_target (Optional[float]): Target idiosyncratic risk level.
        return_assumption (Optional[ReturnAssumption]): Return assumption methodology.
        universe_sign (UniverseSign): Sign constraint for positions (default: ALL).

    Example:
        >>> KeyInput(
        ...     include_portfolios=[InclusionUniverse(portfolio_id=123)],
        ...     exclude_portfolios=[456],
        ...     idio_target=0.15,
        ...     return_assumption=ReturnAssumption.EQUAL_RETURN,
        ...     universe_sign=UniverseSign.LONG
        ... )
    """

    include_portfolios: Optional[List[InclusionUniverse]] = Field(default=None)
    exclude_portfolios: Optional[List[int]] = Field(default=None)
    idio_target: Optional[float] = Field(default=None)
    return_assumption: Optional[ReturnAssumption] = Field(default=None)
    universe_sign: UniverseSign = Field(default=UniverseSign.ALL)
    max_number_of_new_names: Optional[int] = Field(default=None)


class AssetIdentifiers(ArcanaApiRequestSchema):
    asset_id: Optional[int] = Field(default=None, description="Asset ID", examples=[1])
    ticker: Optional[str] = Field(description="Ticker", default=None, examples=["AAPL"], alias="symbol")


class PortfolioConstraints(ArcanaApiRequestSchema):
    """
    Portfolio-level constraints for optimization.

    Attributes:
        max_turnover_pct (Optional[float]): Maximum turnover percentage.
        max_single_position_change_pct_gross_aum (Optional[float]): Max single position change as % of gross AUM.
        min_single_position_size_weight (Optional[float]): Minimum single position size weight.
        max_single_position_size_weight (Optional[float]): Maximum single position size weight.
        min_single_position_size_pct_idiovar (Optional[float]): Min single position size as % of idiosyncratic variance.
        max_single_position_size_pct_idiovar (Optional[float]): Max single position size as % of idiosyncratic variance.
        min_net_length_target_weight (Optional[float]): Minimum net length target weight.
        max_net_length_target_weight (Optional[float]): Maximum net length target weight.
        change_industry_nets (Optional[bool]): Whether to change industry net exposures (default: False).
        change_long_positions (Optional[bool]): Whether to change long positions (default: False).
        change_short_positions (Optional[bool]): Whether to change short positions (default: False).
        lock_long_positions (Optional[bool]): Whether to lock long positions (default: False).
        lock_short_positions (Optional[bool]): Whether to lock short positions (default: False).
        lock_all_current_portfolio_options (Optional[bool]): Whether to lock all current portfolio options (default: False).
        lock_etf_indices_baskets_positions (Optional[bool]): Whether to lock ETF indices baskets positions (default: False).
        lock_individual_portfolio_positions (Optional[bool]): Whether to lock individual portfolio positions (default: False).
        individual_portfolio_positions_list_to_lock (List[AssetIdentifiers]): List of asset identifiers to lock.
        max_single_position_change_adv_pct (Optional[float]): Maximum single position change as % of AUM (default: None).
        max_single_position_size_adv (Optional[float]): Maximum single position size as % of AUM (default: None).
        min_single_position_size_adv (Optional[float]): Minimum single position size as % of AUM (default: None).

    Example:
        >>> PortfolioConstraints(
        ...     max_turnover_pct=20.0,
        ...     max_single_position_size_weight=5.0,
        ...     change_long_positions=True
        ... )
    """

    max_turnover_pct: Optional[float] = Field(default=None)
    max_single_position_change_pct_gross_aum: Optional[float] = Field(default=None)
    min_single_position_size_weight: Optional[float] = Field(default=None)
    max_single_position_size_weight: Optional[float] = Field(default=None)
    min_single_position_size_pct_idiovar: Optional[float] = Field(default=None)
    max_single_position_size_pct_idiovar: Optional[float] = Field(default=None)
    min_net_length_target_weight: Optional[float] = Field(default=None)
    max_net_length_target_weight: Optional[float] = Field(default=None)
    change_industry_nets: Optional[bool] = Field(default=False)
    change_long_positions: Optional[bool] = Field(default=False)
    change_short_positions: Optional[bool] = Field(default=False)
    lock_long_positions: Optional[bool] = Field(default=False)
    lock_short_positions: Optional[bool] = Field(default=False)
    lock_all_current_portfolio_options: Optional[bool] = Field(default=False)
    lock_etf_indices_baskets_positions: Optional[bool] = Field(default=False)
    lock_individual_portfolio_positions: Optional[bool] = Field(default=False)
    individual_portfolio_positions_list_to_lock: List[AssetIdentifiers] = Field(default=[])
    max_single_position_change_adv_pct: Optional[float] = Field(default=None)
    max_single_position_size_adv: Optional[float] = Field(default=None)
    min_single_position_size_adv: Optional[float] = Field(default=None)

    @model_validator(mode="after")
    def check_min_max_pairs(self) -> "PortfolioConstraints":
        pairs = [
            ("min_single_position_size_weight", "max_single_position_size_weight"),
            ("min_single_position_size_pct_idiovar", "max_single_position_size_pct_idiovar"),
            ("min_net_length_target_weight", "max_net_length_target_weight"),
        ]

        for min_key, max_key in pairs:
            min_val = getattr(self, min_key)
            max_val = getattr(self, max_key)
            if min_val is not None and max_val is not None:
                if min_val > max_val:
                    raise ValueError(f"{min_key} cannot be greater than {max_key}")

        return self


class RiskFactorConstraints(ArcanaApiRequestSchema):
    """
    Risk factor constraints for optimization.

    Attributes:
        factor_id (int): ID of the risk factor to constrain.
        min (Optional[float]): Minimum exposure to this factor (default: 0).
        max (Optional[float]): Maximum exposure to this factor (default: 0).

    Example:
        >>> RiskFactorConstraints(factor_id=42, min=-0.1, max=0.1)
    """

    factor_id: int = Field()
    min: Optional[float] = Field(default=0)
    max: Optional[float] = Field(default=0)

    @model_validator(mode="after")
    def validate_either_min_or_max(self) -> "RiskFactorConstraints":
        if self.min is None and self.max is None:
            raise ValueError("Either min or max must be provided")
        return self


class MetricConstraints(ArcanaApiRequestSchema):
    metric_id: int
    min: Optional[float] = Field(default=0)
    max: Optional[float] = Field(default=0)

    @model_validator(mode="after")
    def validate_either_min_or_max(self) -> "MetricConstraints":
        if self.min is None and self.max is None:
            raise ValueError("Either min or max must be provided")
        return self


class PortfolioOptimizeRequest(RiskModelRequest):
    """
    Request schema for portfolio optimization.

    Attributes:
        risk_model_id (int): Risk model ID (defaults to US_INTRADAY_RISK_MODEL_ID).
        objective (OptimizationObjective): Optimization objective.
        as_of_date (Optional[str]): Date for optimization in YYYY-MM-DD format.
        key_inputs (Optional[KeyInput]): Key optimization inputs and universe configuration.
        portfolio_constraints (Optional[PortfolioConstraints]): Portfolio-level constraints.
        risk_factor_constraints (Optional[List[RiskFactorConstraints]]): Risk factor exposure constraints.
        performance_indicator_options (Optional[IndicatorAndOverrideOptions]): Performance indicator settings.

    Example:
        >>> PortfolioOptimizeRequest(
        ...     risk_model_id=3,
        ...     objective=OptimizationObjective.SHARPE_RATIO,
        ...     as_of_date="2025-05-06",
        ...     key_inputs=KeyInput(
        ...         include_portfolios=[InclusionUniverse(portfolio_id=123)],
        ...         return_assumption=ReturnAssumption.EQUAL_RETURN
        ...     ),
        ...     portfolio_constraints=PortfolioConstraints(max_turnover_pct=20.0),
        ...     performance_indicator_options=IndicatorAndOverrideOptions(
        ...         indicator=PerformanceIndicatorEnum.GMV
        ...     )
        ... )
    """

    objective: OptimizationObjective = Field()
    as_of_date: Optional[str] = Field(
        default=None,
        description="Date for which the data is being requested. Must be in YYYY-MM-DD format for a past date",
        examples=["2025-05-06"],
    )
    key_inputs: Optional[KeyInput] = Field(default=None)
    portfolio_constraints: Optional[PortfolioConstraints] = Field(default=None)
    risk_factor_constraints: Optional[List[RiskFactorConstraints]] = Field(default=None)
    metric_constraints: Optional[List[MetricConstraints]] = Field(default=None)
    performance_indicator_options: Optional[IndicatorAndOverrideOptions] = Field(default=None)


class MetricParameterRequest(ArcanaApiRequestSchema):
    """Request schema for configuring a metric parameter.

    Accepts both {"name": ..., "value": ...} and {"asset_id": 21} styles.
    """

    name: str = Field(description="Name of the parameter.")
    value: Any = Field(description="Value of the parameter.")


class TimeSeriesRequest(RiskModelRequest):
    """
    Request schema for timeseries analysis over a portfolio with performance settings.

    Attributes:
        risk_model_id (int): Risk model used for timeseries computation.
        portfolio_options (PortfolioOptions): Portfolio evaluation configuration.
        time_range (TimeRangeWithGrain): Date range and grain (e.g., daily).
        performance_indicator_options (PerformanceIndicatorOptions): Performance indicator config.
        periodicity (Optional[Periodicity]): Optional frequency override.

    Example:
        >>> TimeSeriesRequest(
        ...     risk_model_id=1,
        ...     portfolio_options=PortfolioOptions(
        ...         evaluation_mode=PortfolioEvaluationMode.HISTORICAL,
        ...         output_mode=OutputMode.CUMULATIVE_DOLLAR
        ...     ),
        ...     time_range=TimeRangeWithGrain(
        ...         start_time="2023-01-01",
        ...         end_time="2023-12-31",
        ...         grain=TimeGrain.DAY
        ...     ),
        ...     performance_indicator_options=PerformanceIndicatorOptions(
        ...         indicator=PerformanceIndicatorEnum.GMV
        ...     ),
        ...     periodicity=None
        ... )
    """

    portfolio_options: PortfolioOptions = Field(default=PortfolioOptions())
    time_range: TimeRangeWithGrain
    performance_indicator_options: PerformanceIndicatorOptions = Field(default=PerformanceIndicatorOptions())
    periodicity: Optional[Periodicity] = Field(default=None)
    metric_parameters: Optional[List[MetricParameterRequest]] = Field(
        default=None, description="Optional parameters to configure the metric."
    )


class BatchPortfolioTimeseriesRequest(TimeSeriesRequest):
    """
    Request schema for timeseries analysis over a portfolio with performance settings.

    Inherits from:
        TimeSeriesRequest

    Attributes:
        metric_ids (List[int]): List of metric IDs to fetch timeseries for.
    """

    metric_ids: List[int] = Field(description="List of metric IDs to fetch timeseries for.")

    @model_validator(mode="after")
    def check_metric_ids_not_empty(self) -> BatchPortfolioTimeseriesRequest:
        if not self.metric_ids:
            raise ValueError("metric_ids must not be empty")
        return self

    @model_validator(mode="before")
    @classmethod
    def block_metric_parameters(cls, data: Any) -> Any:  # pylint: disable=missing-raises-doc,invalid-name
        # Dynamically block metric_parameters if present
        if getattr(data, "metric_parameters", None) not in (None, []):
            raise ValueError("metric_parameters is not supported in BatchPortfolioTimeseriesRequest.")
        return data


class PointInTimeRequest(RiskModelRequest):
    """
    Request for point in time values in portfolio metrics.

    Attributes:
        output_mode: Output Mode of the result set, defaults to PERCENTAGE
        as_of_date: Optional as of date for the analysis. It should be in YYYY-MM-DD format and for a non-future date. Defaults to None.
        include_asset_breakdown: Whether to include asset breakdown in the response.

    Example:
        >>> PointInTimeRequest(
        ...     risk_model_id=3,
        ...     output_mode=PointInTimeOutputMode.PERCENTAGE,
        ...     as_of_date="2025-05-06",
        ...     include_asset_breakdown=True
        ... )
    """

    output_mode: PointInTimeOutputMode = Field(PointInTimeOutputMode.PERCENTAGE)
    as_of_date: Optional[str] = Field(default=None)
    include_asset_breakdown: bool = Field(default=True)


# Asset Models
class AssetsSearchRequest(ArcanaApiRequestSchema):
    """
    Request model for searching assets using various identifiers.

    This schema allows clients to submit a list of asset identifier dictionaries,
    where each key is an identifier type (e.g., ISIN, SEDOL) and the value is the corresponding identifier.

    The keys can be either values from `AssetIdentifiersEnum` (recommended for safety) or raw strings
    (to allow forward compatibility with server-side additions).

    Example:
        >>> AssetsSearchRequest(assets=[
        ...     {AssetIdentifiersEnum.ISIN: "US0378331005"},
        ...     {AssetIdentifiersEnum.SEDOL: "B0YQ5W0"},
        ...     {"custom_id": "ARC12345"}  # valid as a string, even if not in the enum
        ... ])
    """

    assets: List[Dict[Union[AssetIdentifiersEnum, str], str]]


class BatchAssetTimeseriesRequest(SingleEntityTimeseriesRequest):
    """
    Request schema for fetching timeseries data for multiple assets.

    Inherits from:
        SingleEntityTimeseriesRequest

    Attributes:
        asset_ids (Optional[List[int]]): A list of asset IDs to query timeseries for.
        portfolio_id (Optional[int]): The portfolio ID used for timeseries aggregation context.
    """

    asset_ids: Optional[List[int]] = Field(default=None)
    portfolio_id: Optional[int] = Field(default=None)

    @field_validator("asset_ids", mode="after")
    @classmethod
    def validate_asset_ids(cls, v: Optional[List[int]]) -> Optional[List[int]]:
        if v is None:
            return v
        # Check for negative numbers in asset_ids
        if any(asset_id < 0 for asset_id in v):
            raise ValueError("asset_ids must not contain negative numbers")
        return v


class AssetFilterSchema(ArcanaApiRequestSchema):
    """
    Schema to filter assets based on identifying fields and attributes.

    Inherits from:
        ArcanaApiRequestSchema

    Attributes:
        ticker (Optional[str]): Ticker symbol of the asset.
        isin (Optional[str]): ISIN (International Securities Identification Number).
        sedol (Optional[str]): SEDOL (Stock Exchange Daily Official List) code.
        cusip (Optional[str]): CUSIP (Committee on Uniform Securities Identification Procedures) code.
        figi (Optional[str]): FIGI (Financial Instrument Global Identifier).
        composite_figi (Optional[str]): Composite FIGI for broader matching.
        open_figi_ticker (Optional[str]): OpenFIGI ticker symbol.
        asset_type (Optional[str]): Type of the asset (e.g., equity, bond).
        name (Optional[str]): Name of the asset or issuer.
        exchange (Optional[str]): Exchange on which the asset is listed.
        currency (Optional[str]): Currency in which the asset is denominated.
        country (Optional[str]): Country of issuance or trading.
    """

    ticker: Optional[str] = Field(default=None)
    isin: Optional[str] = Field(default=None)
    sedol: Optional[str] = Field(default=None)
    cusip: Optional[str] = Field(default=None)
    figi: Optional[str] = Field(default=None)
    composite_figi: Optional[str] = Field(default=None)
    open_figi_ticker: Optional[str] = Field(default=None)
    asset_type: Optional[str] = Field(default=None)
    name: Optional[str] = Field(default=None)
    exchange: Optional[str] = Field(default=None)
    currency: Optional[str] = Field(default=None)
    country: Optional[str] = Field(default=None)


class AssetMetricSnapshot(ArcanaApiRequestSchema):
    """
    Represents a snapshot of an asset metric.

    Attributes:
        asset_id (Optional[int]): Asset Id.
        ticker (Optional[str]): Ticker symbol of the asset.
        metric_id (int): Metric Id.
        value (Union[Optional[str], Optional[float]]): Value to be assigned to that metric.
        as_of_date (Optional[str]): Date for which the data is being submitted. Must be in YYYY-MM-DD format and for a non-future date.
    """

    asset_id: Optional[int] = Field(default=None)
    ticker: Optional[str] = Field(default=None)
    metric_id: int = Field()
    value: Union[Optional[str], Optional[float]] = Field()
    as_of_date: Optional[str] = Field(default=None)

    @model_validator(mode="after")
    def validate_model(self) -> AssetMetricSnapshot:
        if self.asset_id is None and self.ticker is None:
            raise ValueError("Either asset_id or ticker must be provided.")
        return self


class AssetMetricUploadRequest(ArcanaApiRequestSchema):
    """
    Represents a request to upload a batch of metric values for a list of assets.
    """

    data: List[AssetMetricSnapshot] = Field()


# Risk Factor Models
class RiskFactorsFilterSchema(ArcanaApiRequestSchema):
    """
    Filter schema for querying risk factors based on category and model.

    Attributes:
        risk_factor_category_id (Optional[int]): ID of the risk factor category to filter by.
        risk_model_id (int): ID of the risk model to use. Defaults to US_INTRADAY_RISK_MODEL_ID (3).

    Example:
        >>> RiskFactorsFilterSchema(
        ...     risk_factor_category_id=12,
        ...     risk_model_id=3
        ... )
    """

    category_id: Optional[int] = Field(default=None)
    risk_model_id: int = Field(default=US_INTRADAY_RISK_MODEL_ID)


class RiskFactorTimeseriesRequest(SingleEntityTimeseriesRequest):
    """
    Request schema for retrieving timeseries data for a specific risk factor.

    Attributes:
        metric (RiskFactorTimeseriesMetric): The metric to compute over time.

    Example:
        >>> RiskFactorTimeseriesRequest(
        ...     time_range=TimeRange(start_time="2023-01-01", end_time="2023-12-31"),
        ...     metric=RiskFactorTimeseriesMetric.TOTAL_RETURN
        ... )
    """

    metric: RiskFactorTimeseriesMetric = Field()


class BatchRiskFactorTimeseriesRequest(SingleEntityTimeseriesRequest):
    """
    Request schema for retrieving timeseries data for multiple risk factors.

    Attributes:
        risk_factor_ids (List[int]): The IDs of the risk factors to query timeseries for.
        metric (RiskFactorTimeseriesMetric): The metric to compute over time.

    Example:
        >>> BatchRiskFactorTimeseriesRequest(
        ...     risk_factor_ids=[1, 2, 3],
        ...     metric=RiskFactorTimeseriesMetric.TOTAL_RETURN,
        ...     time_range=TimeRangeWithGrain(
        ...         start_time="2023-01-01",
        ...         end_time="2023-12-31",
        ...         grain=TimeGrain.DAY
        ...     ),
        ...     mode="DAILY",
        ...     periodicity=None,
        ...     risk_model_id=2
        ... )
    """

    risk_factor_ids: List[int] = Field()
    metric: RiskFactorTimeseriesMetric = Field()

    @field_validator("risk_factor_ids", mode="after")
    @classmethod
    def validate_risk_factor_ids(cls, v: List[int]) -> List[int]:
        if not v:
            raise ValueError("risk_factor_ids must not be empty")
        return v


# Risk Model Models
class RiskModelFilterSchema(ArcanaApiRequestSchema):
    """
    Filter schema for querying risk models by name.

    Attributes:
        name (Optional[str]): Partial or exact name of the risk model.

    Example:
        >>> RiskModelFilterSchema(name="Intraday")
    """

    name: Optional[str] = Field(default=None)


# Metric Models
class MetricFilterSchema(ArcanaApiRequestSchema):
    """
    Request schema for filtering metrics.

    Used to filter metric entities based on category, name, risk model, and associated risk factor category.

    Attributes:
        - risk_factor_category_id (Optional[int]): Optional ID of the associated risk factor category.
        - category (Optional[str]): Optional container category the metric belongs to.
        - name (Optional[str]): Optional name filter for the metric.
        - risk_model_id (int): Risk model ID associated with the metric.

    :param risk_factor_category_id: Optional ID of the associated risk factor category.
    :type risk_factor_category_id: Optional[int]
    :param category: Optional container category the metric belongs to.
    :type category: Optional[MetricContainerCategory]
    :param name: Optional name filter for the metric.
    :type name: Optional[str]
    :param risk_model_id: The risk model ID associated with the metric. Defaults to US_INTRADAY_RISK_MODEL_ID.
    :type risk_model_id: int
    """

    risk_factor_category_id: Optional[int] = Field(
        default=None, description="Optional ID of the associated risk factor category."
    )
    category: Optional[MetricContainerCategory] = Field(default=None)
    name: Optional[str] = Field(default=None)
    risk_model_id: int = Field(default=US_INTRADAY_RISK_MODEL_ID)
