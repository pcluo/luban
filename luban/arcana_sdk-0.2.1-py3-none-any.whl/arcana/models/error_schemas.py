from __future__ import annotations


class APIError(Exception):

    def __init__(self, error_code: str = "UNKNOWN", error_message: str = "Unknown error"):
        self.error_code = error_code
        self.error_message = error_message
        super().__init__(str(self))

    def __repr__(self) -> str:
        return f"({self.error_code}, {self.error_message})"

    def __str__(self) -> str:
        return f"({self.error_code}, {self.error_message})"


class NotFoundError(APIError):
    def __init__(self, error_message: str = "Resource Not Found"):
        super().__init__("NOT_FOUND", error_message)


class BadRequestError(APIError):
    def __init__(self, error_message: str = "Bad Request"):
        super().__init__("BAD_REQUEST", error_message)


class UnauthorizedError(APIError):
    def __init__(self, error_message: str = "Unauthorized"):
        super().__init__("UNAUTHORIZED", error_message)


class ForbiddenError(APIError):
    def __init__(self, error_message: str = "You are not allowed to access this API"):
        super().__init__("FORBIDDEN", error_message)


class InternalServerError(APIError):
    def __init__(self, error_message: str = "Internal Server Error"):
        super().__init__("INTERNAL_SERVER_ERROR", error_message)


class UnprocessableError(APIError):
    def __init__(self, error_message: str = "The provided input is not valid"):
        super().__init__("UNPROCESSABLE_ERROR", error_message)


class TimedOutError(APIError):
    def __init__(self, error_message: str = "The request timed out"):
        super().__init__("TIMED_OUT", error_message)


class RateLimitedError(APIError):
    def __init__(self, error_message: str = "Too many requests"):
        super().__init__("TOO_MANY_REQUESTS", error_message)


__all__ = [cls.__name__ for cls in APIError.__subclasses__()] + ["APIError"]
