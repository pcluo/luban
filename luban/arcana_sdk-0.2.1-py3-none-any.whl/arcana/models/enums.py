# pylint: disable
from __future__ import annotations

from enum import Enum


class AssetIdentifiersEnum(Enum):
    ISIN = "isin"
    SEDOL = "sedol"
    SYMBOL = "symbol"
    ASSET_CLASS = "asset_class"
    RIC = "ric"
    BLOOMBERG_SYMBOL = "bloomberg_symbol"
    OPTION_ISIN = "option_isin"
    OPTION_SEDOL = "option_sedol"
    OPTION_BLOOMBERG_SYMBOL = "option_bloomberg_symbol"
    SUB_ASSET_CLASS = "sub_asset_class"
    FIGI = "figi"
    OPTION_FIGI = "option_figi"
    COMPOSITE_FIGI = "composite_figi"
    OPTION_COMPOSITE_FIGI = "option_composite_figi"


class PresetRange(Enum):
    RANGE_1D = "RANGE_1D"
    RANGE_1W = "RANGE_1W"
    RANGE_1M = "RANGE_1M"
    RANGE_3M = "RANGE_3M"
    RANGE_YTD = "RANGE_YTD"
    RANGE_1Y = "RANGE_1Y"
    RANGE_5Y = "RANGE_5Y"
    RANGE_MTD = "RANGE_MTD"
    RANGE_QTD = "RANGE_QTD"


class TimeGrain(Enum):
    MINUTE = "MINUTE"
    FIVE_MINUTE = "FIVE_MINUTE"
    HOUR = "HOUR"
    DAY = "DAY"
    WEEK = "WEEK"
    MONTH = "MONTH"
    QUARTER = "QUARTER"
    YEAR = "YEAR"


class TransformMode(Enum):
    DAILY = "DAILY"
    CUMULATIVE = "CUMULATIVE"


class Periodicity(Enum):
    DOD = "DOD"
    WOW = "WOW"
    MOM = "MOM"
    QOQ = "QOQ"
    YOY = "YOY"


class MetricContainerCategory(Enum):
    RETURNS = "RETURNS"
    EXPOSURES = "EXPOSURES"
    VARIANCES = "VARIANCES"
    OTHER = "OTHER"


class PortfolioEvaluationMode(Enum):
    """
    Evaluation mode for analyzing portfolio performance.

    Attributes:
        BACKTEST: Simulated evaluation using past data and strategy logic.
        HISTORICAL: Replay using actual historical weights and positions.

    Example:
        >>> mode = PortfolioEvaluationMode.BACKTEST
    """

    BACKTEST = "BACKTEST"
    HISTORICAL = "HISTORICAL"


class OutputMode(Enum):
    """
    Output format for time series values in reports or charts.

    Attributes:
        CUMULATIVE_PERCENTAGE: Cumulative return in percentage.
        CUMULATIVE_DOLLAR: Cumulative return in dollar terms.
        DAILY_DOLLAR: Daily profit/loss in dollars.
        DAILY_PERCENTAGE: Daily return in percentage.
        NUMBER: Number value.
        MULTIPLE: Returned directly without modification, denoted by prefixing with x on the product.
        DOLLAR: Dollar value.
        PERCENTAGE: Percentage value.
        FREEFORM: Freeform value.

    Example:
        >>> mode = OutputMode.DAILY_PERCENTAGE
    """

    CUMULATIVE_PERCENTAGE = "CUMULATIVE_PERCENTAGE"
    CUMULATIVE_DOLLAR = "CUMULATIVE_DOLLAR"
    DAILY_DOLLAR = "DAILY_DOLLAR"
    DAILY_PERCENTAGE = "DAILY_PERCENTAGE"
    NUMBER = "NUMBER"
    MULTIPLE = "MULTIPLE"
    DOLLAR = "DOLLAR"
    PERCENTAGE = "PERCENTAGE"
    FREEFORM = "FREEFORM"


class PointInTimeOutputMode(Enum):
    """
    Output format for point in time values in portfolio metrics.

    Attributes:
        DOLLAR: Dollar value.
        PERCENTAGE: Percentage value.
        FREEFORM: Freeform value.
        NUMBER: Number value.

    Example:
        >>> mode = PointInTimeOutputMode.PERCENTAGE
    """

    DOLLAR = "DOLLAR"
    PERCENTAGE = "PERCENTAGE"
    FREEFORM = "FREEFORM"
    NUMBER = "NUMBER"


class RiskFactorTimeseriesMetric(Enum):
    TOTAL_RETURN = "TOTAL_RETURN"
    FACTOR_VOL = "FACTOR_VOL"


class PortfolioType(Enum):
    """
    Types of portfolios supported in the platform.

    Attributes:
        SAVED_PORTFOLIO: User-defined saved portfolio.
        SHARED_PORTFOLIO: Portfolio shared with the user.
        IMPORTED_PORTFOLIO: Portfolio imported from an external source.

    Example:
        >>> portfolio_type = PortfolioType.SAVED_PORTFOLIO
    """

    SAVED_PORTFOLIO = "SAVED_PORTFOLIO"
    SHARED_PORTFOLIO = "SHARED_PORTFOLIO"
    IMPORTED = "IMPORTED"


class PortfolioUploadType(Enum):
    """
    Types of portfolio uploads supported in the platform.

    Attributes:
        SAVED_PORTFOLIO: User-defined saved portfolio.
        IMPORTED_PORTFOLIO: Portfolio imported from an external source.
    """

    SAVED_PORTFOLIO = "SAVED_PORTFOLIO"
    IMPORTED = "IMPORTED"


class PerformanceIndicatorEnum(Enum):
    """
    Performance indicators used in portfolio analytics.

    Attributes:
        GMV: Gross Market Value.
        AUM: Assets Under Management.

    Example:
        >>> indicator = PerformanceIndicatorEnum.GMV
    """

    GMV = "GMV"
    AUM = "AUM"


class OptimizationObjective(Enum):
    """
    Objectives for portfolio optimization.

    Attributes:
        SHARPE_RATIO: Maximize Sharpe ratio.
        MIN_VOLATILITY: Minimize portfolio volatility.
        IDIO_TARGET: Target specific idiosyncratic risk.
        FACTOR_TARGET: Target specific factor exposure.
        EQUAL_IDIOVOL: Equal idiosyncratic volatility weighting.

    Example:
        >>> objective = OptimizationObjective.SHARPE_RATIO
    """

    SHARPE_RATIO = "sharpe_ratio"
    MIN_VOLATILITY = "min_volatility"
    IDIO_TARGET = "idio_target"
    FACTOR_TARGET = "factor_target"
    EQUAL_IDIOVOL = "equal_idiovol"


class ReturnAssumption(Enum):
    """
    Return assumptions for portfolio optimization.

    Attributes:
        USER_PROJECTED: Use user-provided return projections.
        EQUAL_RETURN: Assume equal returns for all assets.
        CONVICTION_SCORE: Use conviction scores as return proxy.
        POSITION_SIZE: Use position size as return proxy.
        IDIOVOL_PROPORTIONATE: Returns proportional to idiosyncratic volatility.

    Example:
        >>> assumption = ReturnAssumption.EQUAL_RETURN
    """

    USER_PROJECTED = "user_projected"
    EQUAL_RETURN = "equal_return"
    CONVICTION_SCORE = "conviction_score"
    POSITION_SIZE = "position_size"
    IDIOVOL_PROPORTIONATE = "idiovol_proportionate"


class UniverseSign(Enum):
    """
    Universe sign constraints for portfolio optimization.

    Attributes:
        ALL: Allow both long and short positions.
        LONG: Allow only long positions.
        SHORT: Allow only short positions.

    Example:
        >>> sign = UniverseSign.LONG
    """

    ALL = "ALL"
    LONG = "LONG"
    SHORT = "SHORT"
