from __future__ import annotations

from enum import Enum
from typing import Any, Dict
from urllib.parse import urlencode

from pydantic import BaseModel, Field


class ArcanaApiSchema(BaseModel):
    pass


class PortfolioVisualizationSchema(ArcanaApiSchema):
    data: Dict[str, Any] = Field()

    def get_attribute_by_key(self, name: str) -> str:
        return str(self.data[name])


class ArcanaApiRequestSchema(ArcanaApiSchema):

    class Config:
        extra = "forbid"

    def as_query_string(self) -> str:
        """
        Converts the populated fields into a URL query string, excluding None values.

        Returns:
            str: A URL-encoded query string like 'name=A&figi=XYZ'.
        """
        raw = self.model_dump(exclude_none=True)
        processed = {key: (value.value if isinstance(value, Enum) else value) for key, value in raw.items()}
        return urlencode(processed)
