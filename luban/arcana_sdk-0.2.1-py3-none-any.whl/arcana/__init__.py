from __future__ import annotations

from importlib.metadata import version

from ._sdk import ArcanaSDK

__version__ = version("arcana-sdk")
__all__ = ["ArcanaSDK"]
