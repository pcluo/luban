from __future__ import annotations

import logging
import random
import time
from http import HTTPStatus

import requests

# Optional progress bar support
try:
    from tqdm import tqdm  # type: ignore

    TQDM_AVAILABLE = True
except ImportError:
    TQDM_AVAILABLE = False
    tqdm = None

logger = logging.getLogger(__name__)


class RateLimitHandler:
    """Handles rate limiting with exponential backoff and jitter."""

    def __init__(
        self,
        max_retries: int = 5,
        base_delay: float = 10,
        max_delay: float = 600,
        backoff_factor: float = 2,
        jitter: bool = True,
        show_progress: bool = False,
    ):
        self.max_retries = max_retries
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.backoff_factor = backoff_factor
        self.jitter = jitter
        self.show_progress = show_progress

    def should_retry(self, response: requests.Response, attempt: int) -> bool:
        """Check if we should retry based on response status and attempt count."""
        if attempt >= self.max_retries:
            return False

        # Rate limited
        if response.status_code == HTTPStatus.TOO_MANY_REQUESTS:
            return True

        return False

    def get_retry_delay(self, attempt: int, response: requests.Response) -> float:
        """Calculate delay before next retry attempt."""
        # Check for Retry-After header first
        if retry_after := response.headers.get("Retry-After"):
            try:
                return float(retry_after)
            except ValueError:
                pass

        # Exponential backoff with jitter
        delay = self.base_delay * (self.backoff_factor**attempt)
        delay = min(delay, self.max_delay)

        if self.jitter:
            # Add random jitter (±25% of delay)
            # Jitter introduces randomness to avoid "thundering herd" problems (where many clients retry at the same time).
            jitter_range = delay * 0.25
            delay += random.uniform(-jitter_range, jitter_range)  # nosec B311

        return max(0, delay)

    def wait_with_progress(self, delay: float, attempt: int, response: requests.Response) -> None:
        """Wait for the specified delay with optional progress bar."""
        if delay <= 0:
            return

        status_code = response.status_code
        reason = "Rate limited" if status_code == 429 else f"server error ({status_code})"

        if self.show_progress and TQDM_AVAILABLE:
            desc = f"Retry {attempt + 1}/{self.max_retries} - {reason}, waiting"

            # Use tqdm for progress bar during wait
            with tqdm(total=int(delay * 10), desc=desc, unit="0.1s", leave=False) as pbar:
                for _ in range(int(delay * 10)):
                    time.sleep(0.1)
                    pbar.update(1)
        elif attempt == 0:  # Only log on first retry to avoid spam
            logger.info("Request %s, retrying in %.1fs...", reason, delay)
            time.sleep(delay)
