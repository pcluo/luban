from __future__ import annotations

import logging
import time
from http import HTTPStatus
from typing import Any, Dict, Optional, cast

import requests

from arcana._clients.rate_limit import RateLimitHandler
from arcana.constants.internal import DEFAULT_REQUEST_TIMEOUT
from arcana.models.error_schemas import InternalServerError

logger = logging.getLogger(__name__)


def _parse_json_or_return_server_error(response: requests.Response) -> Dict[str, Any]:
    try:
        if response.status_code == HTTPStatus.NO_CONTENT:
            return {}
        return cast(Dict[str, Any], response.json())
    except ValueError as error:
        raise InternalServerError() from error


class _SyncAPIClient:
    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.app.arcana.io",
        timeout: int = DEFAULT_REQUEST_TIMEOUT,
        show_progress: bool = False,
    ) -> None:
        if not api_key or not isinstance(api_key, str):
            raise ValueError("API key must be a non-empty string")

        self.base_url: str = base_url.rstrip("/")
        self.session: requests.Session = requests.Session()
        self.session.headers.update(
            {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": api_key,
            }
        )
        self.timeout: int = timeout

        # Initialize rate limit handler
        self.rate_limit_handler = RateLimitHandler(
            show_progress=show_progress,
        )

        self._validate_api_key()

    def _make_request_with_retry(self, method: str, path: str, **kwargs: Any) -> Dict[str, Any]:
        """Make HTTP request with automatic retry on rate limits and server errors."""
        url = self._build_url(path)
        timeout = kwargs.pop("timeout", None) or self.timeout

        last_response = None
        for attempt in range(self.rate_limit_handler.max_retries + 1):
            try:
                # Make the request
                response = self.session.request(method=method, url=url, timeout=timeout, **kwargs)
                last_response = response

                # Check if request was successful
                if response.status_code < 400:
                    return _parse_json_or_return_server_error(response)

                # Check if we should retry
                if not self.rate_limit_handler.should_retry(response, attempt):
                    # No more retries, parse and return/raise error
                    return _parse_json_or_return_server_error(response)

                # Calculate delay and wait
                delay = self.rate_limit_handler.get_retry_delay(attempt, response)
                self.rate_limit_handler.wait_with_progress(delay, attempt, response)

            except requests.exceptions.RequestException as e:
                # Network errors - retry if we have attempts left
                if attempt < self.rate_limit_handler.max_retries:
                    delay = self.rate_limit_handler.base_delay * (2**attempt)
                    if self.rate_limit_handler.show_progress:
                        logger.info("Network error, retrying in %.1fs: %s", delay, e)
                    time.sleep(delay)
                    continue
                raise

        # If we get here, all retries failed
        if last_response is not None:
            return _parse_json_or_return_server_error(last_response)
        request_info = f"method={method}, url={url}, kwargs={kwargs}"
        logger.error("All retry attempts failed for request: %s", request_info)
        raise RuntimeError(f"All retry attempts failed for request: {request_info}")

    def get(
        self,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> Dict[str, Any]:
        return self._make_request_with_retry("GET", path, params=params, timeout=timeout)

    def post(self, path: str, data: str, timeout: Optional[int] = None) -> Dict[str, Any]:
        return self._make_request_with_retry("POST", path, data=data, timeout=timeout)

    def put(
        self,
        path: str,
        json: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> Dict[str, Any]:
        return self._make_request_with_retry("PUT", path, json=json, timeout=timeout)

    def patch(self, path: str, data: str, timeout: Optional[int] = None) -> Dict[str, Any]:
        return self._make_request_with_retry("PATCH", path, data=data, timeout=timeout)

    def delete(self, path: str, timeout: Optional[int] = None) -> Dict[str, Any]:
        return self._make_request_with_retry("DELETE", path, timeout=timeout)

    def _build_url(self, path: str) -> str:
        return f"{self.base_url}/{path.lstrip('/')}"

    def _validate_api_key(self) -> None:
        url = "/api/v1/portfolios/?limit=1&offset=0"
        response = self.get(path=url)
        status = response.get("status")
        data = response.get("data")
        if status == "ERROR":
            if data and data.get("error_code") == "UNAUTHORIZED":
                raise ValueError("Invalid API key")
            raise ValueError(data.get("error_message", "Unknown error") if data else "Unknown error")
