from __future__ import annotations

from arcana._apis.assets.sync_assets import _AssetsSync
from arcana._apis.metrics.sync_metrics import _MetricsSync
from arcana._apis.portfolios.sync_portfolios import _PortfoliosSync
from arcana._apis.risk_factors.sync_risk_factors import _RiskFactorsSync
from arcana._apis.risk_models.sync_risk_models import _RiskModelsSync
from arcana._clients.sync_client import _SyncAPIClient


class ArcanaSDK:

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.app.arcana.io/",
        show_progress: bool = False,
    ):
        """
        Initialize the Arcana SDK with automatic rate limiting and retry handling.

        Args:
            api_key: Your Arcana API key
            base_url: Base URL for the API (default: "https://api.app.arcana.io/")
            show_progress: Show progress bar during rate limit waits (default: False)
        """
        self._client = _SyncAPIClient(
            base_url=base_url,
            api_key=api_key,
            show_progress=show_progress,
        )
        self.risk_models = _RiskModelsSync(self._client)
        self.assets = _AssetsSync(self._client)
        self.metrics = _MetricsSync(self._client)
        self.risk_factors = _RiskFactorsSync(self._client)
        self.portfolios = _PortfoliosSync(self._client)
