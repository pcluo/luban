from __future__ import annotations

DEFAULT_REQUEST_TIMEOUT = 60  # Default timeout in seconds
DEFAULT_LONG_REQUEST_TIMEOUT = 300  # Default timeout in seconds for long requests
STATUS = "status"
OK = "OK"
ERROR = "ERROR"
DATA = "data"
INVALID_IDS = "invalid_ids"
US_INTRADAY_RISK_MODEL_ID = 3

EMAILS_IN_ERROR = "Returns a dictionary containing email IDs with which the portfolio could not be shared (if any). ALREADY_HAS_ACCESS contains the list of users this portfolio was already shared with, USER_DOES_NOT_EXIST shows the users we don't recognize in Arcana, and INTERNAL_ERROR signifies an issue which is an error on our side and should be resolved via reaching out."
