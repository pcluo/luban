from __future__ import annotations

from typing import List, Optional

from pydantic import ValidationError

from arcana._apis.metrics.metrics import _Metrics
from arcana._apis.utils import _handle_validation_error
from arcana._clients.sync_client import _SyncAPIClient
from arcana.constants.internal import US_INTRADAY_RISK_MODEL_ID
from arcana.models.enums import MetricContainerCategory
from arcana.models.request import MetricFilterSchema
from arcana.models.response.metrics import Metric, SingleMetric


class _MetricsSync(_Metrics):
    """
    [INTERNAL] Synchronous wrapper for the Metrics API.

    This class provides synchronous methods to interact with metric-related endpoints.
    It is used internally by the Arcana SDK and is not part of the public SDK interface.

    :param client: An instance of the internal synchronous API client.
    :type client: _SyncAPIClient
    """

    def __init__(self, client: _SyncAPIClient) -> None:
        """
        Initialize the Metrics API with a synchronous API client.

        :param client: An instance of the internal synchronous API client.
        :type client: _SyncAPIClient
        """
        self._client: _SyncAPIClient = client

    def get_all(
        self,
        limit: int = 50,
        offset: int = 0,
        risk_factor_category_id: Optional[int] = None,
        category: Optional[MetricContainerCategory] = None,
        name: Optional[str] = None,
        risk_model_id: int = US_INTRADAY_RISK_MODEL_ID,
    ) -> List[Metric]:
        """
        Fetch all metrics with optional pagination and filtering.

        Args:
            limit: Maximum number of results to return. Must be between 1 and 500. Defaults to 50.
            offset: Number of metrics to skip (for pagination). Must be >= 0. Defaults to 0.
            risk_factor_category_id: Optional ID of the associated risk factor category. Must be a positive integer.
            category: Optional container category the metric belongs to. One of ["RETURNS", "RISK", "FACTOR", "CUSTOM"].
            name: Optional name filter for the metric. Case-insensitive partial match.
            risk_model_id: Risk model ID associated with the metric. Must be a positive integer. Defaults to 3.

        Returns:
            A list of metric summaries.

        Raises:
            ValidationError: If the filter schema validation fails.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no metrics are found matching the criteria.

        Examples:
            # Get all metrics with default pagination
            metrics = client.get_all()

            # Get metrics with category filter
            metrics = client.get_all(
                category="RETURNS",
                name="Total Return"
            )

            # Get metrics with risk factor category
            metrics = client.get_all(
                risk_factor_category_id=12,
                risk_model_id=5
            )

            # Get metrics with custom pagination
            metrics = client.get_all(
                limit=100,
                offset=50,
                category="RETURNS"
            )
        """
        try:
            filter_schema_obj = MetricFilterSchema(
                risk_factor_category_id=risk_factor_category_id,
                category=category,
                name=name,
                risk_model_id=risk_model_id,
            )
        except ValidationError as e:
            raise _handle_validation_error(e, MetricFilterSchema) from None

        url = self._get_all_metrics_url(limit, offset, filter_schema_obj)
        return self._process_response_for_all_metrics(self._client.get(url))

    def get_by_id(self, metric_id: int) -> SingleMetric:
        """
        Fetch a metric by its unique identifier.

        Args:
            metric_id: The ID of the metric to retrieve. Must be a positive integer.

        Returns:
            Full metric detail for the given ID.

        Raises:
            ValidationError: If the metric_id is invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no metric is found with the given ID.

        Examples:
            # Get a specific metric by ID
            metric = client.get_by_id(metric_id=37582)

            # Get the Total Returns metric
            total_returns = client.get_by_id(metric_id=37582)
        """
        url = f"api/v1/metrics/{metric_id}"
        return self._process_response_for_single_metric(self._client.get(url))
