from __future__ import annotations

from typing import Any, Dict, List

from arcana._apis.error_handler import _parse_api_error_response
from arcana.constants.internal import DATA, OK, STATUS
from arcana.models.request import MetricFilterSchema
from arcana.models.response.metrics import Metric, SingleMetric


class _Metrics:
    """
    Internal base class for processing Metrics API operations and responses.

    This class encapsulates shared logic for handling responses from the Metrics API,
    used across both synchronous and asynchronous SDK clients.
    """

    def _get_all_metrics_url(
        self,
        limit: int = 50,
        offset: int = 0,
        filter_schema: MetricFilterSchema = MetricFilterSchema(),
    ) -> str:
        base_url = f"/api/v1/metrics/?limit={limit}&offset={offset}"
        query_param = filter_schema.as_query_string()
        return f"{base_url}&{query_param}"

    def _process_response_for_all_metrics(self, response: Dict[str, Any]) -> List[Metric]:
        if response.get(STATUS) == OK:
            return [Metric(**metric) for metric in response.get(DATA)]  # type: ignore
        raise _parse_api_error_response(response.get(DATA))

    def _process_response_for_single_metric(self, response: Dict[str, Any]) -> SingleMetric:
        if response.get(STATUS) == OK:
            return SingleMetric(**response.get(DATA))  # type: ignore
        raise _parse_api_error_response(response.get(DATA))
