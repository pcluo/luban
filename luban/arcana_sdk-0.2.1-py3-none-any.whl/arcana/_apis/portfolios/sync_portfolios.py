# pylint: disable=too-many-arguments, too-many-locals, too-many-branches, too-many-statements, too-many-lines, too-many-lines
from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple, Union

import pandas as pd
from pydantic import ValidationError

from arcana._apis.portfolios.portfolios import _Portfolios
from arcana._apis.utils import _handle_validation_error
from arcana._clients.sync_client import _SyncAPIClient
from arcana.constants.internal import DEFAULT_LONG_REQUEST_TIMEOUT
from arcana.models.common import IdName, TimeRange, TimeRangeWithGrain
from arcana.models.enums import (
    OutputMode,
    PerformanceIndicatorEnum,
    Periodicity,
    PointInTimeOutputMode,
    PortfolioEvaluationMode,
    PortfolioType,
    PresetRange,
    TimeGrain,
)
from arcana.models.error_schemas import BadRequestError
from arcana.models.request import (
    PerformanceIndicatorOptions,
    PortfolioOptions,
    PortfolioUploadRequest,
    TimedHistoricalRequest,
    TimeMachinePerfIndicatorRequestWithRiskModel,
    TimeSeriesRequest,
)
from arcana.models.request.consolidated_models import (
    BatchPortfolioTimeseriesRequest,
    MetricParameterRequest,
    PointInTimeRequest,
    PortfolioOptimizeRequest,
    PortfolioSharingRequest,
)
from arcana.models.response.portfolios import (
    Portfolio,
    PortfolioAssetContribution,
    PortfolioData,
    PortfolioDrillDown,
    PortfolioFactorExposure,
    PortfolioMetric,
    PortfolioPerformanceSummaryStats,
    PortfolioSharing,
    PortfolioSummary,
    PortfolioUpdate,
    ThirteenFPortfolio,
    TimeseriesHistoricalPortfolioData,
)


class _PortfoliosSync(_Portfolios):
    """
    [INTERNAL] Synchronous wrapper for the Portfolios API.

    This class provides synchronous methods to interact with portfolio-related endpoints
    including creation, update, deletion, and analytics of portfolios. It is used internally
    by the Arcana SDK and is not part of the public SDK interface.

    Attributes:
        client (_SyncAPIClient): Internal synchronous API client used to perform requests.
    """

    def __init__(self, client: _SyncAPIClient) -> None:
        """
        Initialize the Portfolios API with a synchronous API client.

        Args:
            client: An instance of the internal synchronous API client.
        """
        self._client: _SyncAPIClient = client

    def get_all(
        self,
        limit: int = 50,
        offset: int = 0,
        name: Optional[int] = None,
        portfolio_type: Optional[Union[str, PortfolioType]] = None,
    ) -> List[Portfolio]:
        """
        Retrieve a list of portfolios with optional filtering and pagination.

        Args:
            limit: Maximum number of portfolios to return. Must be between 1 and 1000. Defaults to 50.
            offset: Offset for pagination. Must be >= 0. Defaults to 0.
            name: Optional name filter for the portfolio.
            portfolio_type: Optional type filter for the portfolio. Can be a string or PortfolioType enum.
                Valid values: ["SAVED_PORTFOLIO", "SHARED_PORTFOLIO", "IMPORTED"].

        Returns:
            A list of deserialized portfolio responses.

        Raises:
            ValidationError: If the filter parameters are invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no portfolios are found matching the criteria.

        Examples:
            ### Get all portfolios with default pagination
            portfolios = client.get_all()

            ### Get portfolios with name filter
            portfolios = client.get_all(name=123)

            ### Get portfolios with type filter using string
            portfolios = client.get_all(portfolio_type="SAVED_PORTFOLIO")

            ### Get portfolios with type filter using enum
            portfolios = client.get_all(portfolio_type=PortfolioType.SAVED_PORTFOLIO)

            ### Get portfolios with both filters and custom pagination
            portfolios = client.get_all(
                limit=100,
                offset=50,
                name=123,
                portfolio_type="SAVED_PORTFOLIO"
            )
        """
        url = self._get_all_portfolios_url(limit, offset, name, portfolio_type)
        return self._process_response_for_all_portfolios(self._client.get(path=url))

    def get_by_id(self, portfolio_id: int) -> Portfolio:
        """
        Get a portfolio by its ID.

        Args:
            portfolio_id: ID of the portfolio. Must be a positive integer.
        """
        url = self._get_portfolio_by_id_url(portfolio_id)
        try:
            response_or_exception = self._process_response_for_portfolio(self._client.get(path=url))
            return response_or_exception
        except BadRequestError:
            portfolio = Portfolio(id=portfolio_id, name="", type=PortfolioType.SAVED_PORTFOLIO)
            portfolio._portfolios_api = self  # pylint: disable=protected-access
            return portfolio

    def get_all_thirteen_f_portfolios(
        self,
        limit: int = 50,
        offset: int = 0,
        name: Optional[str] = None,
    ) -> List[ThirteenFPortfolio]:
        """
        Retrieve all 13F portfolios with pagination and filtering.

        Args:
            limit: Maximum number of portfolios to return. Must be between 1 and 1000. Defaults to 50.
            offset: Number of portfolios to skip. Must be >= 0. Defaults to 0.
            name: Optional name filter for the portfolio. Must be a positive integer.

        Returns:
            A list of 13F portfolio summaries.

        Raises:
            ValidationError: If the filter parameters are invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no 13F portfolios are found matching the criteria.

        Examples:
            ### Get all 13F portfolios with default pagination
            portfolios = client.get_all_thirteen_f_portfolios()

            ### Get 13F portfolios with name filter
            portfolios = client.get_all_thirteen_f_portfolios(name=123)

            ### Get 13F portfolios with custom pagination
            portfolios = client.get_all_thirteen_f_portfolios(
                limit=100,
                offset=50,
                name=123
            )
        """
        url = self._get_13f_portfolios_url(limit, offset, name)
        response = self._client.get(url)
        return self._process_response_for_13f_portfolios(response)

    def _get_latest_position(self, portfolio_id: int) -> PortfolioData:
        """
        Get the latest position data for a given portfolio.

        Args:
            portfolio_id: ID of the portfolio. Must be a positive integer.

        Returns:
            Latest portfolio position data.

        Raises:
            ValidationError: If the portfolio_id is invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no portfolio is found with the given ID.

        Examples:
            ### Get latest positions for a portfolio
            positions = client.get_latest_position(portfolio_id=123)
        """
        return self._process_response_for_latest_portfolio_positions(
            self._client.get(path=f"/api/v1/portfolios/{portfolio_id}/positions")
        )

    def _get_historical_positions(
        self,
        portfolio_id: int,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> TimeseriesHistoricalPortfolioData:
        """
        Get historical position data for a portfolio.

        Args:
            portfolio_id: ID of the portfolio. Must be a positive integer.
            start_date: Optional start date in ISO format (e.g., "2023-01-01"). If not provided, returns all historical data.
            end_date: Optional end date in ISO format (e.g., "2023-12-31"). If not provided, defaults to current date.

        Returns:
            Historical timeseries data.

        Raises:
            ValidationError: If the portfolio_id or dates are invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no portfolio is found with the given ID.

        Examples:
            ### Get all historical positions
            positions = client.get_historical_positions(portfolio_id=123)

            ### Get historical positions for a specific date range
            positions = client.get_historical_positions(
                portfolio_id=123,
                start_date="2023-01-01",
                end_date="2023-12-31"
            )
        """
        url = self._get_historical_portfolio_positions_url(portfolio_id, start_date, end_date)
        return self._process_response_for_historical_portfolio_positions(self._client.get(url))

    def create(self, snapshots: Union[PortfolioUploadRequest, Dict[str, Any]]) -> Portfolio:
        """
        Create a new portfolio with the given data.

        Args:
            snapshots: The request payload containing the portfolio upload. Can be a dict or PortfolioUploadRequest.
                Must contain:
                - portfolio_name: Name of the portfolio
                - portfolio_type: Type of portfolio to create. One of ["SAVED_PORTFOLIO", "IMPORTED"]. Defaults to "SAVED_PORTFOLIO".
                - data: List of portfolio snapshots, each containing:
                    - date: Date in ISO format (e.g., "2023-01-01")
                    - aum: Total portfolio value
                    - positions: List of positions, each containing:
                        - asset_id: Optional ID of the asset
                        - ticker: Optional Ticker of the asset
                        - isin: Optional ISIN of the asset
                        - sedol: Optional SEDOL of the asset
                        - ric: Optional RIC of the asset
                        - bloomberg_symbol: Optional Bloomberg symbol of the asset
                        - option_isin: Optional ISIN of the option
                        - option_sedol: Optional SEDOL of the option
                        - option_figi: Optional FIGI of the option
                        - composite_option_figi: Optional Composite FIGI of the option
                        - option_bloomberg_symbol: Optional Bloomberg symbol of the option
                        - sub_asset_class: Optional Sub-asset class of the asset
                        - figi: Optional FIGI of the asset
                        - composite_figi: Optional Composite FIGI of the asset
                        - asset_class: Optional asset class (e.g., "equity")
                        - net_invested: Investment amount

        Returns:
            Newly created portfolio.

        Raises:
            ValidationError: If the request data is invalid.
            BadRequestError: If the API request is invalid.
            ConflictError: If a portfolio with the same name already exists.

        Examples:
            ### Create a portfolio with a single snapshot
            snapshots = {
                "portfolio_name": "Test Portfolio",
                "portfolio_type": "SAVED_PORTFOLIO",
                "data": [
                    {
                        "date": "2023-04-01",
                        "aum": 20000000,
                        "positions": [
                            {"asset_id": 1, "asset_class": "equity", "net_invested": 1000000},
                            {"asset_id": 2, "net_invested": 2000000}
                        ]
                    }
                ]
            }
            portfolio = sdk.portfolios.create(snapshots)

            ### Create a portfolio with multiple snapshots
            snapshots = {
                "portfolio_name": "Test Portfolio",
                "portfolio_type": "SAVED_PORTFOLIO",
                "data": [
                    {
                        "date": "2023-01-01",
                        "aum": 10000000,
                        "positions": [{"asset_id": 1, "net_invested": 1000000}]
                    },
                    {
                        "date": "2023-02-01",
                        "aum": 20000000,
                        "positions": [{"asset_id": 1, "net_invested": 2000000}]
                    }
                ]
            }
            portfolio = sdk.portfolios.create(snapshots)

            ### Create a portfolio with a different portfolio type
            snapshots = {
                "portfolio_name": "Test Portfolio",
                "portfolio_type": "IMPORTED",
                "data": [
                    {
                        "date": "2023-01-01",
                        "aum": 10000000,
                        "positions": [{"asset_id": 1, "net_invested": 1000000}]
                    }
                ]
            }
            portfolio = sdk.portfolios.create(snapshots)

            ### Create a portfolio with ticker, isin in positions input.
            snapshots = {
                "portfolio_name": "Test Saved Portfolio",
                "portfolio_type": "SAVED_PORTFOLIO",
                "data": [
                    {
                        "date": "2023-01-01",
                        "aum": 10000000,
                        "positions": [{"ticker": "AAPL US", "asset_class": "EQUITY", "net_invested": 1000000}]
                    }
                ]
            }
            portfolio = sdk.portfolios.create(snapshots)
        """
        try:
            if isinstance(snapshots, dict):
                request_obj = PortfolioUploadRequest(**snapshots)
            else:
                request_obj = snapshots
        except ValidationError as e:
            raise _handle_validation_error(e, PortfolioUploadRequest) from None
        url = "/api/v1/portfolios/"
        portfolio_create = self._process_response_for_create_portfolio(
            self._client.post(
                path=url, data=request_obj.model_dump_json(exclude_none=True), timeout=DEFAULT_LONG_REQUEST_TIMEOUT
            )
        )
        return self.get_by_id(portfolio_create.id)

    def _update(self, portfolio_id: int, snapshots: Union[PortfolioUploadRequest, Dict[str, Any]]) -> PortfolioUpdate:
        """
        Update an existing portfolio with new data.

        Args:
            portfolio_id: ID of the portfolio to update. Must be a positive integer.
            snapshots: The request payload containing the updated data. Can be a dict or PortfolioUploadRequest.
                Must contain:
                - portfolio_name: Name of the portfolio
                - portfolio_type: Type of portfolio to update. One of ["SAVED_PORTFOLIO", "IMPORTED"]. Defaults to "SAVED_PORTFOLIO".
                - data: List of portfolio snapshots, each containing:
                    - date: Date in ISO format (e.g., "2023-01-01")
                    - aum: Total portfolio value
                    - positions: List of positions, each containing:
                        - asset_id: Optional ID of the asset
                        - ticker: Optional Ticker of the asset
                        - isin: Optional ISIN of the asset
                        - sedol: Optional SEDOL of the asset
                        - ric: Optional RIC of the asset
                        - bloomberg_symbol: Optional Bloomberg symbol of the asset
                        - option_isin: Optional ISIN of the option
                        - option_sedol: Optional SEDOL of the option
                        - option_figi: Optional FIGI of the option
                        - composite_option_figi: Optional Composite FIGI of the option
                        - option_bloomberg_symbol: Optional Bloomberg symbol of the option
                        - sub_asset_class: Optional Sub-asset class of the asset
                        - figi: Optional FIGI of the asset
                        - composite_figi: Optional Composite FIGI of the asset
                        - asset_class: Optional asset class (e.g., "equity")
                        - net_invested: Investment amount

        Returns:
            PortfolioUpdate object.

        Raises:
            ValidationError: If the portfolio_id or request data is invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no portfolio is found with the given ID.
            ConflictError: If a portfolio with the same name already exists.

        Examples:
            ### Update a portfolio with a single snapshot
            snapshots = {
                "portfolio_name": "Updated Portfolio",
                "portfolio_type": "SAVED_PORTFOLIO",
                "data": [
                    {
                        "date": "2023-04-01",
                        "aum": 20000000,
                        "positions": [
                            {"asset_id": 1, "asset_class": "equity", "net_invested": 1000000},
                            {"asset_id": 2, "net_invested": 2000000}
                        ]
                    }
                ]
            }
            portfolio = portfolio.update(portfolio_id=123, snapshots=snapshots)

            ### Update a portfolio with multiple snapshots
            request = {
                "portfolio_name": "Updated Portfolio",
                "portfolio_type": "SAVED_PORTFOLIO",
                "data": [
                    {
                        "date": "2023-01-01",
                        "aum": 10000000,
                        "positions": [{"asset_id": 1, "net_invested": 1000000}]
                    },
                    {
                        "date": "2023-02-01",
                        "aum": 20000000,
                        "positions": [{"asset_id": 1, "net_invested": 2000000}]
                    }
                ]
            }
            portfolio = portfolio.update(portfolio_id=123, request=request)

            ### Update a portfolio with a different portfolio type
            request = {
                "portfolio_name": "Updated Portfolio",
                "portfolio_type": "IMPORTED",
                "data": [
                    {
                        "date": "2023-01-01",
                        "aum": 10000000,
                        "positions": [{"asset_id": 1, "net_invested": 1000000}]
                    }
                ]
            }
            portfolio = portfolio.update(portfolio_id=123, request=request)

            ### Update a portfolio with ticker, isin in positions input.
            request = {
                "portfolio_name": "Updated Portfolio",
                "portfolio_type": "SAVED_PORTFOLIO",
                "data": [
                {
                    "date": "2023-01-01",
                    "aum": 10000000,
                    "positions": [{"ticker": "AAPL US", "asset_class": "EQUITY", "net_invested": 1000000}]
                }]
            }
            portfolio = portfolio.update(portfolio_id=123, request=request)
        """
        try:
            if isinstance(snapshots, dict):
                request_obj = PortfolioUploadRequest(**snapshots)
            else:
                request_obj = snapshots
        except ValidationError as e:
            raise _handle_validation_error(e, PortfolioUploadRequest) from None
        url = f"/api/v1/portfolios/{portfolio_id}/positions"
        data = self._client.patch(
            path=url, data=request_obj.model_dump_json(exclude_none=True), timeout=DEFAULT_LONG_REQUEST_TIMEOUT
        )
        return self._process_response_for_update_portfolio(data)

    def _delete(self, portfolio_id: int) -> None:
        """
        Delete a portfolio by its ID.

        Args:
            portfolio_id: ID of the portfolio to delete. Must be a positive integer.

        Raises:
            ValidationError: If the portfolio_id is invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no portfolio is found with the given ID.

        Examples:
            ### Delete a portfolio
            client.delete(portfolio_id=123)
        """
        self._client.delete(path=f"/api/v1/portfolios/{portfolio_id}")

    def _share(self, portfolio_id: int, emails: List[str]) -> PortfolioSharing:
        """
        Share a portfolio by its ID.

        Args:
            portfolio_id: ID of the portfolio to share. Must be a positive integer.
            emails: List of users with which the portfolio should be shared.

        Returns:
            PortfolioSharing object.

        Raises:
            ValidationError: If the request data is invalid.
            BadRequestError: If the portfolio is not sharable.
            NotFoundError: If no portfolio is found with the given ID.

        Examples:
            ### Share a portfolio with a list of users
            portfolio_sharing = client.share(portfolio_id=123, emails=["user1@example.com", "user2@example.com"])
        """
        try:
            request_obj = PortfolioSharingRequest(**{"user_emails": emails})
        except ValidationError as e:
            raise _handle_validation_error(e, PortfolioSharingRequest) from None
        url = f"/api/v1/portfolios/{portfolio_id}/share"
        return self._process_response_for_portfolio_sharing(
            self._client.post(path=url, data=request_obj.model_dump_json(exclude_none=True))
        )

    def _get_timeseries(
        self,
        portfolio_id: int,
        metric_id: int,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        preset_range: Optional[PresetRange] = None,
        risk_model_id: int = 3,
        grain: TimeGrain = TimeGrain.DAY,
        evaluation_mode: Optional[PortfolioEvaluationMode] = None,
        output_mode: OutputMode = OutputMode.CUMULATIVE_PERCENTAGE,
        indicator: PerformanceIndicatorEnum = PerformanceIndicatorEnum.GMV,
        aum_override_value: Optional[float] = None,
        use_historical_aum: Optional[bool] = None,
        periodicity: Optional[Periodicity] = None,
        metric_parameters: Optional[Dict[str, Any]] = None,
    ) -> pd.DataFrame:
        """
        Get time series data for a portfolio metric.

        Args:
            portfolio_id: ID of the portfolio. Must be a positive integer.
            metric_id: ID of the metric to fetch. Must be a positive integer.
            start_time: Start time in ISO format (e.g., "2023-01-01"). Required if preset_range is not provided.
            end_time: End time in ISO format (e.g., "2023-12-31"). Required if preset_range is not provided.
            preset_range: Predefined time range. One of ["RANGE_1W", "RANGE_1M", "RANGE_3M", "RANGE_YTD", "RANGE_1Y",
                "RANGE_5Y", "RANGE_MTD", "RANGE_QTD"]. If provided, start_time and end_time are ignored.
            risk_model_id: ID of the risk model to use. Must be a positive integer. Defaults to 3.
            grain: Time grain for the data points. One of ["DAY", "WEEK", "MONTH", "QUARTER", "YEAR"]. Defaults to "DAY".
            evaluation_mode: Optional evaluation mode for the data. One of ["BACKTEST", "HISTORICAL"].
                             Defaults to "HISTORICAL", if it exists; else "BACKTEST".
            output_mode: Output format for the data. One of ["CUMULATIVE_PERCENTAGE", "CUMULATIVE_DOLLAR", "DAILY_DOLLAR",
                "DAILY_PERCENTAGE", "MULTIPLE"]. Defaults to "CUMULATIVE_PERCENTAGE".
            indicator: Performance indicator to use. One of ["GMV", "AUM"]. Defaults to "GMV".
            aum_override_value: Optional override for the portfolio's AUM value.
            use_historical_aum: Whether to use historical AUM values. If True, aum_override_value is ignored.
            periodicity: Optional frequency override. One of ["DOD", "WOW", "MOM", "QOQ", "YOY"]. Defaults to None.
            metric_parameters: Optional parameters to configure the metric. Defaults to None.

        Returns:
            DataFrame with the timeseries data.

        Raises:
            ValueError: If neither start_time nor preset_range is provided.
            ValidationError: If any of the parameters are invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no portfolio or metric is found with the given IDs.

        Examples:
            ### Get daily timeseries data with date range
            timeseries = client.get_timeseries(
                portfolio_id=123,
                metric_id=37582,
                start_time="2023-01-01"
            )

            ### Get timeseries data with preset range
            timeseries = client.get_timeseries(
                portfolio_id=123,
                metric_id=37582,
                preset_range="RANGE_1M"  # Last month's data
            )

            ### Get timeseries with custom settings
            timeseries = client.get_timeseries(
                portfolio_id=123,
                metric_id=37582,
                start_time="2023-01-01",
                end_time="2023-12-31",
                grain="WEEK",
                evaluation_mode="BACKTEST",
                output_mode="DAILY_PERCENTAGE",
                indicator="AUM",
                use_historical_aum=True,
                periodicity="WOW"
            )

            ### Get timeseries with CUMULATIVE_PERCENTAGE output mode
            timeseries = client.get_timeseries(
                portfolio_id=123,
                metric_id=37582,
                start_time="2023-01-01",
                output_mode="CUMULATIVE_PERCENTAGE"
            )

            # Get timeseries with CUMULATIVE_DOLLAR output mode
            timeseries = client.get_timeseries(
                portfolio_id=123,
                metric_id=37582,
                start_time="2023-01-01",
                end_time="2023-12-31",
                grain="WEEK",
                evaluation_mode="BACKTEST",
                output_mode="CUMULATIVE_DOLLAR",
                indicator="GMV",
                periodicity="WOW"
            )
        """
        if preset_range is None and start_time is None:
            raise ValueError("Either start_time or preset_range must be provided")

        if end_time is None and preset_range is None:
            end_time = datetime.now().strftime("%Y-%m-%d")

        try:
            request_obj = TimeSeriesRequest(
                risk_model_id=risk_model_id,
                portfolio_options=PortfolioOptions(evaluation_mode=evaluation_mode, output_mode=output_mode),
                time_range=TimeRangeWithGrain(
                    start_time=start_time, end_time=end_time, preset_range=preset_range, grain=grain
                ),
                performance_indicator_options=PerformanceIndicatorOptions(
                    indicator=indicator, aum_override_value=aum_override_value, use_historical_aum=use_historical_aum
                ),
                periodicity=periodicity,
                metric_parameters=(
                    [MetricParameterRequest(name=key, value=value) for key, value in metric_parameters.items()]
                    if metric_parameters
                    else None
                ),
            )
        except ValidationError as e:
            raise _handle_validation_error(e, TimeSeriesRequest) from None

        return self._process_response_for_portfolio_timeseries(
            self._client.post(
                path=f"/api/v1/portfolios/{portfolio_id}/metrics/{metric_id}/timeseries",
                data=request_obj.model_dump_json(exclude_none=True),
            )
        )

    def _get_timeseries_batch(
        self,
        portfolio_id: int,
        metric_ids: List[int],
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        preset_range: Optional[PresetRange] = None,
        risk_model_id: int = 3,
        grain: TimeGrain = TimeGrain.DAY,
        evaluation_mode: Optional[PortfolioEvaluationMode] = None,
        output_mode: OutputMode = OutputMode.CUMULATIVE_PERCENTAGE,
        indicator: PerformanceIndicatorEnum = PerformanceIndicatorEnum.GMV,
        aum_override_value: Optional[float] = None,
        use_historical_aum: Optional[bool] = None,
        periodicity: Optional[Periodicity] = None,
    ) -> Tuple[pd.DataFrame, List[int]]:
        """
        Get time series data for multiple portfolio metrics.

        Args:
            portfolio_id: ID of the portfolio. Must be a positive integer.
            metric_ids: List of metric IDs to fetch. Must be a list of positive integers.
            start_time: Start time in ISO format (e.g., "2023-01-01"). Required if preset_range is not provided.
            end_time: End time in ISO format (e.g., "2023-12-31"). Required if preset_range is not provided.
            preset_range: Predefined time range. One of ["RANGE_1W", "RANGE_1M", "RANGE_3M", "RANGE_YTD", "RANGE_1Y",
                "RANGE_5Y", "RANGE_MTD", "RANGE_QTD"]. If provided, start_time and end_time are ignored.
            risk_model_id: ID of the risk model to use. Must be a positive integer. Defaults to 3.
            grain: Time grain for the data points. One of ["DAY", "WEEK", "MONTH", "QUARTER", "YEAR"]. Defaults to "DAY".
            evaluation_mode: Optional evaluation mode for the data. One of ["BACKTEST", "HISTORICAL"].
                             Defaults to "HISTORICAL", if it exists; else "BACKTEST".
            output_mode: Output format for the data. One of ["CUMULATIVE_PERCENTAGE", "CUMULATIVE_DOLLAR", "DAILY_DOLLAR",
                "DAILY_PERCENTAGE", "MULTIPLE"]. Defaults to "CUMULATIVE_PERCENTAGE".
            indicator: Performance indicator to use. One of ["GMV", "AUM"]. Defaults to "GMV".
            aum_override_value: Optional override for the portfolio's AUM value.
            use_historical_aum: Whether to use historical AUM values. If True, aum_override_value is ignored.
            periodicity: Optional frequency override. One of ["DOD", "WOW", "MOM", "QOQ", "YOY"]. Defaults to None.
        Returns:
            Tuple[DataFrame, List[int]]: A tuple containing:
                - DataFrame with the timeseries data.
                - List of invalid metric IDs.

        Raises:
            ValueError: If neither start_time nor preset_range is provided.
            ValidationError: If any of the parameters are invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no portfolio or metric is found with the given IDs.
        """
        if preset_range is None and start_time is None:
            raise ValueError("Either start_time or preset_range must be provided")

        if end_time is None and preset_range is None:
            end_time = datetime.now().strftime("%Y-%m-%d")

        try:
            request_obj = BatchPortfolioTimeseriesRequest(
                risk_model_id=risk_model_id,
                time_range=TimeRangeWithGrain(
                    start_time=start_time, end_time=end_time, preset_range=preset_range, grain=grain
                ),
                portfolio_options=PortfolioOptions(evaluation_mode=evaluation_mode, output_mode=output_mode),
                performance_indicator_options=PerformanceIndicatorOptions(
                    indicator=indicator, aum_override_value=aum_override_value, use_historical_aum=use_historical_aum
                ),
                periodicity=periodicity,
                metric_ids=metric_ids,
            )
        except ValidationError as e:
            raise _handle_validation_error(e, BatchPortfolioTimeseriesRequest) from None

        return self._process_response_for_portfolio_timeseries_batch(
            self._client.post(
                path=f"/api/v1/portfolios/{portfolio_id}/metrics/timeseries/batch",
                data=request_obj.model_dump_json(exclude_none=True),
            )
        )

    def _get_summary(
        self,
        portfolio_id: int,
        risk_model_id: int = 3,
        indicator: PerformanceIndicatorEnum = PerformanceIndicatorEnum.GMV,
        aum_override_value: Optional[float] = None,
        use_historical_aum: Optional[bool] = None,
        as_of_date: Optional[str] = None,
    ) -> PortfolioSummary:
        """
        Get summary analytics for a given portfolio.

        Args:
            portfolio_id: ID of the portfolio. Must be a positive integer.
            risk_model_id: ID of the risk model to use. Must be a positive integer. Defaults to 3.
            indicator: Performance indicator to use. One of ["GMV", "AUM"]. Defaults to "GMV".
            aum_override_value: Optional override for the portfolio's AUM value.
            use_historical_aum: Whether to use historical AUM values. If True, aum_override_value is ignored.
            as_of_date: Optional as of date for the analysis. It should be in YYYY-MM-DD format and for a non-future date. Defaults to None.

        Returns:
            Summary statistics for the portfolio.

        Raises:
            ValidationError: If any of the parameters are invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no portfolio is found with the given ID.

        Examples:
            ### Get portfolio summary with default settings
            summary = client.get_summary(portfolio_id=123)

            ### Get portfolio summary with custom risk model
            summary = client.get_summary(
                portfolio_id=123,
                risk_model_id=5,
                indicator="GMV"
            )

            ### Get portfolio summary with AUM override
            summary = client.get_summary(
                portfolio_id=123,
                indicator="AUM",
                aum_override_value=1_000_000.0,
                use_historical_aum=True
            )

            ### Get portfolio summary as of historical date
            summary = client.get_summary(
                portfolio_id=123,
                risk_model_id=5,
                indicator="GMV",
                as_of_date="2025-05-06"
            )
        """
        try:
            request = TimeMachinePerfIndicatorRequestWithRiskModel(
                risk_model_id=risk_model_id,
                performance_indicator_options=PerformanceIndicatorOptions(
                    indicator=indicator, aum_override_value=aum_override_value, use_historical_aum=use_historical_aum
                ),
                as_of_date=as_of_date,
            )
        except ValidationError as e:
            raise _handle_validation_error(e, TimeMachinePerfIndicatorRequestWithRiskModel) from None

        return self._process_response_for_portfolio_summary(
            self._client.post(
                path=f"/api/v1/portfolios/{portfolio_id}/summary",
                data=request.model_dump_json(exclude_none=True),
            )
        )

    def _get_performance_summary_stats(
        self,
        portfolio_id: int,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        preset_range: Optional[PresetRange] = None,
        risk_model_id: int = 3,
        evaluation_mode: Optional[PortfolioEvaluationMode] = None,
        indicator: PerformanceIndicatorEnum = PerformanceIndicatorEnum.GMV,
        aum_override_value: Optional[float] = None,
        use_historical_aum: Optional[bool] = None,
    ) -> PortfolioPerformanceSummaryStats:
        """
        Get performance summary statistics for a portfolio over a time period.

        Args:
            portfolio_id: ID of the portfolio. Must be a positive integer.
            start_time: Start time in ISO format (e.g., "2023-01-01"). Required if preset_range is not provided.
            end_time: End time in ISO format (e.g., "2023-12-31"). Required if preset_range is not provided.
            preset_range: Predefined time range. One of ["RANGE_1W", "RANGE_1M", "RANGE_3M", "RANGE_YTD", "RANGE_1Y",
                "RANGE_5Y", "RANGE_MTD", "RANGE_QTD"]. If provided, start_time and end_time are ignored.
            risk_model_id: ID of the risk model to use. Must be a positive integer. Defaults to 3.
            evaluation_mode: Optional evaluation mode for the data. One of ["BACKTEST", "HISTORICAL"].
                             Defaults to "HISTORICAL", if it exists; else "BACKTEST".
            indicator: Performance indicator to use. One of ["GMV", "AUM"]. Defaults to "GMV".
            aum_override_value: Optional override for the portfolio's AUM value.
            use_historical_aum: Whether to use historical AUM values. If True, aum_override_value is ignored.

        Returns:
            Performance summary statistics for the portfolio.

        Raises:
            ValueError: If neither start_time nor preset_range is provided.
            ValidationError: If any of the parameters are invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no portfolio is found with the given ID.

        Examples:
            ### Get performance summary with date range
            stats = client.get_performance_summary_stats(
                portfolio_id=123,
                start_time="2023-01-01"
            )

            ### Get performance summary with preset range
            stats = client.get_performance_summary_stats(
                portfolio_id=123,
                preset_range="RANGE_1M"  # Last month's data
            )

            ### Get performance summary with custom settings
            stats = client.get_performance_summary_stats(
                portfolio_id=123,
                start_time="2023-01-01",
                end_time="2023-12-31",
                evaluation_mode="BACKTEST",
                indicator="AUM",
                aum_override_value=1_000_000.0,
                use_historical_aum=True
            )
        """
        if preset_range is None and start_time is None:
            raise ValueError("Either start_time or preset_range must be provided")

        if end_time is None and preset_range is None:
            end_time = datetime.now().strftime("%Y-%m-%d")

        try:
            request_obj = TimedHistoricalRequest(
                risk_model_id=risk_model_id,
                time_range=TimeRange(start_time=start_time, end_time=end_time, preset_range=preset_range),
                evaluation_mode=evaluation_mode,
                performance_indicator_options=PerformanceIndicatorOptions(
                    indicator=indicator, aum_override_value=aum_override_value, use_historical_aum=use_historical_aum
                ),
            )
        except ValidationError as e:
            raise _handle_validation_error(e, TimedHistoricalRequest) from None

        return self._process_response_for_portfolio_performance_summary_stats(
            self._client.post(
                path=f"/api/v1/portfolios/{portfolio_id}/performance_summary_stats",
                data=request_obj.model_dump_json(exclude_none=True),
            )
        )

    def get_drilldown_metadata(self) -> List[IdName]:
        """
        Retrieve metadata for portfolio drilldown tabs.

        :return: List of drilldown tab metadata.
        :rtype: List[IdName]
        """
        return self._process_response_for_portfolio_metadata(
            self._client.get(path="/api/v1/portfolios/drilldown/metadata")
        )

    def get_asset_contribution_metadata(self) -> List[IdName]:
        """
        Retrieve metadata for asset contribution tabs.

        :return: List of asset contribution tab metadata.
        :rtype: List[IdNameResponse]
        """
        return self._process_response_for_portfolio_metadata(
            self._client.get(path="/api/v1/portfolios/asset_contributions/metadata")
        )

    def _get_drilldown_data(  # pylint: disable=missing-raises-doc
        self,
        portfolio_id: int,
        tab_id: int,
        risk_model_id: int = 3,
        indicator: PerformanceIndicatorEnum = PerformanceIndicatorEnum.GMV,
        aum_override_value: Optional[float] = None,
        use_historical_aum: Optional[bool] = None,
        as_of_date: Optional[str] = None,
    ) -> PortfolioDrillDown:
        """
        Fetch drilldown data for a portfolio tab.

        :param portfolio_id: ID of the portfolio.
        :type portfolio_id: int
        :param tab_id: ID of the drilldown tab.
        :type tab_id: int
        :param risk_model_id: Risk model ID to use for the analysis. Defaults to 3 (US_INTRADAY_RISK_MODEL_ID).
        :type risk_model_id: int
        :param indicator: Performance indicator to use (e.g., "GMV", "AUM"). Defaults to "GMV".
        :type indicator: str
        :param aum_override_value: Optional override value for AUM. Defaults to None.
        :type aum_override_value: Optional[float]
        :param use_historical_aum: If True, use actual historical AUM. Defaults to None.
        :type use_historical_aum: Optional[bool]
        :param as_of_date: Optional as of date for the analysis. It should be in YYYY-MM-DD format and for a non-future date. Defaults to None.
        :type as_of_date: Optional[str]
        :return: Drilldown data for the specified tab.
        :rtype: PortfolioDrillDown
        :raises:
            ValueError: If neither start_time nor preset_range is provided.
            ValidationError: If any of the parameters are invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no portfolio or tab is found with the given IDs.
        :example:
            ### Get drilldown data with default settings
            drilldown = client.get_drilldown_data(
                portfolio_id=123,
                tab_id=1
            )

            ### Get drilldown data with custom risk model and indicator
            drilldown = client.get_drilldown_data(
                portfolio_id=123,
                tab_id=1,
                risk_model_id=5,
                indicator="AUM"
            )

            ### Get drilldown data with AUM override
            drilldown = client.get_drilldown_data(
                portfolio_id=123,
                tab_id=1,
                indicator="AUM",
                aum_override_value=1_000_000.0,
                use_historical_aum=True
            )
        """
        try:
            request = TimeMachinePerfIndicatorRequestWithRiskModel(
                risk_model_id=risk_model_id,
                performance_indicator_options=PerformanceIndicatorOptions(
                    indicator=indicator, aum_override_value=aum_override_value, use_historical_aum=use_historical_aum
                ),
                as_of_date=as_of_date,
            )
        except ValidationError as e:
            raise _handle_validation_error(e, TimeMachinePerfIndicatorRequestWithRiskModel) from None

        return self._process_response_for_portfolio_drilldown(
            self._client.post(
                path=f"/api/v1/portfolios/{portfolio_id}/drilldown/{tab_id}",
                data=request.model_dump_json(exclude_none=True),
            )
        )

    def _get_factor_exposure_data(  # pylint: disable=missing-raises-doc
        self,
        portfolio_id: int,
        risk_factor_id: int,
        risk_model_id: int = 3,
        indicator: PerformanceIndicatorEnum = PerformanceIndicatorEnum.GMV,
        aum_override_value: Optional[float] = None,
        use_historical_aum: Optional[bool] = None,
        as_of_date: Optional[str] = None,
    ) -> PortfolioFactorExposure:
        """
        Fetch factor exposure data for a portfolio.

        :param portfolio_id: ID of the portfolio.
        :type portfolio_id: int
        :param risk_factor_id: ID of the risk factor.
        :type risk_factor_id: int
        :param risk_model_id: Risk model ID to use for the analysis. Defaults to 3 (US_INTRADAY_RISK_MODEL_ID).
        :type risk_model_id: int
        :param indicator: Performance indicator to use (e.g., "GMV", "AUM"). Defaults to "GMV".
        :type indicator: str
        :param aum_override_value: Optional override value for AUM. Defaults to None.
        :type aum_override_value: Optional[float]
        :param use_historical_aum: If True, use actual historical AUM. Defaults to None.
        :type use_historical_aum: Optional[bool]
        :param as_of_date: Optional as of date for the analysis. It should be in YYYY-MM-DD format and for a non-future date. Defaults to None.
        :type as_of_date: Optional[str]
        :return: Factor exposure analytics for the portfolio.
        :rtype: PortfolioFactorExposure
        :raises:
            ValueError: If neither start_time nor preset_range is provided.
            ValidationError: If any of the parameters are invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no portfolio or factor is found with the given IDs.
        :example:
            ### Get factor exposure data with default settings
            exposure = client.get_factor_exposure_data(
                portfolio_id=123,
                risk_factor_id=456
            )

            ### Get factor exposure data with custom risk model and indicator
            exposure = client.get_factor_exposure_data(
                portfolio_id=123,
                risk_factor_id=456,
                risk_model_id=5,
                indicator="AUM"
            )

            ### Get factor exposure data with AUM override
            exposure = client.get_factor_exposure_data(
                portfolio_id=123,
                risk_factor_id=456,
                indicator="AUM",
                aum_override_value=1_000_000.0,
                use_historical_aum=True
            )

            ### Get factor exposure data with as of date
            exposure = client.get_factor_exposure_data(
                portfolio_id=123,
                risk_factor_id=456,
                as_of_date="2025-05-06"
            )
        """
        try:
            request = TimeMachinePerfIndicatorRequestWithRiskModel(
                risk_model_id=risk_model_id,
                performance_indicator_options=PerformanceIndicatorOptions(
                    indicator=indicator, aum_override_value=aum_override_value, use_historical_aum=use_historical_aum
                ),
                as_of_date=as_of_date,
            )
        except ValidationError as e:
            raise _handle_validation_error(e, TimeMachinePerfIndicatorRequestWithRiskModel) from None

        return self._process_response_for_factor_exposure(
            self._client.post(
                path=f"/api/v1/portfolios/{portfolio_id}/factor_drilldown/{risk_factor_id}",
                data=request.model_dump_json(exclude_none=True),
            )
        )

    def _get_asset_contribution_data(
        self,
        portfolio_id: int,
        tab_id: int,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        preset_range: Optional[PresetRange] = None,
        risk_model_id: int = 3,
        evaluation_mode: Optional[PortfolioEvaluationMode] = None,
        indicator: PerformanceIndicatorEnum = PerformanceIndicatorEnum.GMV,
        aum_override_value: Optional[float] = None,
        use_historical_aum: Optional[bool] = None,
    ) -> PortfolioAssetContribution:
        """
        Get asset contribution data for a specific tab over a time period.

        Args:
            portfolio_id: ID of the portfolio. Must be a positive integer.
            tab_id: ID of the asset contribution tab. Must be a positive integer.
            start_time: Start time in ISO format (e.g., "2023-01-01"). Required if preset_range is not provided.
            end_time: End time in ISO format (e.g., "2023-12-31"). Required if preset_range is not provided.
            preset_range: Predefined time range. One of ["RANGE_1W", "RANGE_1M", "RANGE_3M", "RANGE_YTD", "RANGE_1Y",
                "RANGE_5Y", "RANGE_MTD", "RANGE_QTD"]. If provided, start_time and end_time are ignored.
            risk_model_id: ID of the risk model to use. Must be a positive integer. Defaults to 3.
            evaluation_mode: Optional evaluation mode for the data. One of ["BACKTEST", "HISTORICAL"].
                             Defaults to "HISTORICAL", if it exists; else "BACKTEST".
            indicator: Performance indicator to use. One of ["GMV", "AUM"]. Defaults to "GMV".
            aum_override_value: Optional override for the portfolio's AUM value.
            use_historical_aum: Whether to use historical AUM values. If True, aum_override_value is ignored.

        Returns:
            Asset contribution data for the specified tab.

        Raises:
            ValueError: If neither start_time nor preset_range is provided.
            ValidationError: If any of the parameters are invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no portfolio or tab is found with the given IDs.

        Examples:
            ### Get asset contribution data with date range
            contribution = client.get_asset_contribution_data(
                portfolio_id=123,
                tab_id=1,
                start_time="2023-01-01"
            )

            ### Get asset contribution data with preset range
            contribution = client.get_asset_contribution_data(
                portfolio_id=123,
                tab_id=1,
                preset_range="RANGE_1M"  # Last month's data
            )

            ### Get asset contribution data with custom settings
            contribution = client.get_asset_contribution_data(
                portfolio_id=123,
                tab_id=1,
                start_time="2023-01-01",
                end_time="2023-12-31",
                evaluation_mode="BACKTEST",
                indicator="GMV",
                aum_override_value=1000000
            )
        """
        if preset_range is None and start_time is None:
            raise ValueError("Either start_time or preset_range must be provided")

        if end_time is None and preset_range is None:
            end_time = datetime.now().strftime("%Y-%m-%d")

        try:
            request_obj = TimedHistoricalRequest(
                risk_model_id=risk_model_id,
                time_range=TimeRange(start_time=start_time, end_time=end_time, preset_range=preset_range),
                evaluation_mode=evaluation_mode,
                performance_indicator_options=PerformanceIndicatorOptions(
                    indicator=indicator, aum_override_value=aum_override_value, use_historical_aum=use_historical_aum
                ),
            )
        except ValidationError as e:
            raise _handle_validation_error(e, TimedHistoricalRequest) from None

        return self._process_response_for_asset_contribution(
            self._client.post(
                path=f"/api/v1/portfolios/{portfolio_id}/asset_contributions/{tab_id}",
                data=request_obj.model_dump_json(exclude_none=True),
            )
        )

    def _get_snapshot(
        self,
        portfolio_id: int,
        metric_id: int,
        risk_model_id: int = 3,
        output_mode: PointInTimeOutputMode = PointInTimeOutputMode.PERCENTAGE,
        as_of_date: Optional[str] = None,
        include_asset_breakdown: bool = True,
    ) -> PortfolioMetric:
        """
        Get portfolio snapshot data for the specified metric. Returns asset level breakdown by default.

        Args:
            portfolio_id: ID of the portfolio. Must be a positive integer.
            metric_id: ID of the metric to fetch. Must be a positive integer.
            risk_model_id: ID of the risk model to use. Must be a positive integer.
            output_mode: Output mode for the metric.
            as_of_date: Optional as of date for the analysis. It should be in YYYY-MM-DD format and for a non-future date. Defaults to None.
            include_asset_breakdown: Whether to include asset breakdown in the response. Defaults to True.

        Returns:
            Portfolio snapshot data for the specified metric.

        Raises:
            ValidationError: If any of the parameters are invalid.

        Examples:
            portfolio_snapshot = portfolio.get_snapshot(
                metric_id=1000010,
                risk_model_id=3,
                output_mode=PointInTimeOutputMode.PERCENTAGE,
                as_of_date="2025-05-06",
                include_asset_breakdown=True
            )

            # Get portfolio snapshot with custom settings
            portfolio_snapshot = portfolio.get_snapshot(
                metric_id=123,
                risk_model_id=3,
                output_mode=PointInTimeOutputMode.DOLLAR,
                as_of_date="2025-05-06",
                include_asset_breakdown=False
            )
        """
        try:
            request_obj = PointInTimeRequest(
                risk_model_id=risk_model_id,
                output_mode=output_mode,
                as_of_date=as_of_date,
                include_asset_breakdown=include_asset_breakdown,
            )
        except ValidationError as e:
            raise _handle_validation_error(e, PointInTimeRequest) from None

        return self._process_response_for_portfolio_metrics(
            self._client.post(
                path=f"/api/v1/portfolios/{portfolio_id}/metrics/{metric_id}",
                data=request_obj.model_dump_json(exclude_none=True),
            )
        )

    def _get_optimized_portfolio(
        self, portfolio_id: int, optimize_request: Union[PortfolioOptimizeRequest, Dict[str, Any]]
    ) -> Portfolio:
        try:
            if isinstance(optimize_request, dict):
                request_obj = PortfolioOptimizeRequest(**optimize_request)
            else:
                request_obj = optimize_request
        except ValidationError as e:
            raise _handle_validation_error(e, PortfolioOptimizeRequest) from None

        optimized_portfolio = self._process_response_for_optimizer(
            self._client.post(
                path=f"/api/v1/portfolios/{portfolio_id}/optimize",
                data=request_obj.model_dump_json(),
            )
        )
        return optimized_portfolio

    def _process_response_for_portfolio(self, response: Dict[str, Any]) -> Portfolio:
        portfolio = super()._process_response_for_portfolio(response)
        setattr(portfolio, "_portfolios_api", self)
        return portfolio

    def _process_response_for_all_portfolios(self, response: Dict[str, Any]) -> List[Portfolio]:
        portfolios = super()._process_response_for_all_portfolios(response)
        for portfolio in portfolios:
            setattr(portfolio, "_portfolios_api", self)
        return portfolios

    def _process_response_for_13f_portfolios(self, response: Dict[str, Any]) -> List[ThirteenFPortfolio]:
        thirteen_f_portfolios = super()._process_response_for_13f_portfolios(response)
        for thirteen_f_portfolio in thirteen_f_portfolios:
            setattr(thirteen_f_portfolio, "_portfolios_api", self)
        return thirteen_f_portfolios

    def _process_response_for_optimizer(self, response: Dict[str, Any]) -> Portfolio:
        optimized_portfolio = super()._process_response_for_optimizer(response)
        setattr(optimized_portfolio, "_portfolios_api", self)
        return optimized_portfolio
