from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple, Union
from urllib.parse import urlencode

import pandas as pd

from arcana._apis.error_handler import _parse_api_error_response
from arcana.constants.internal import DATA, ERROR, INVALID_IDS, OK, STATUS
from arcana.models.common import IdName, Position, Timeseries, TimestampWithValue
from arcana.models.enums import PortfolioType
from arcana.models.response.portfolios import (
    BreakdownStat,
    HistoricalPortfolioData,
    OptimizedPortfolio,
    Portfolio,
    PortfolioAssetContribution,
    PortfolioCreate,
    PortfolioData,
    PortfolioDrillDown,
    PortfolioFactorExposure,
    PortfolioMetric,
    PortfolioPerformanceSummaryStats,
    PortfolioSharing,
    PortfolioSummary,
    PortfolioTimeseries,
    PortfolioTimeseriesBatch,
    PortfolioUpdate,
    SectionBlock,
    ThirteenFPortfolio,
    TimeseriesHistoricalPortfolioData,
)


class _Portfolios:
    """
    Internal base class for processing Metrics API operations and responses.

    This class encapsulates shared logic for handling responses from the Metrics API,
    used across both synchronous and asynchronous SDK clients.
    """

    def _get_portfolio_by_id_url(self, portfolio_id: int) -> str:
        return f"/api/v1/portfolios/{portfolio_id}"

    def _get_all_portfolios_url(
        self,
        limit: int = 50,
        offset: int = 0,
        name: Optional[int] = None,
        portfolio_type: Optional[Union[str, PortfolioType]] = None,
    ) -> str:
        # Build query parameters dictionary, excluding None values
        params: Dict[str, Union[int, str]] = {"limit": limit, "offset": offset}

        if name is not None:
            params["name"] = name
        if portfolio_type is not None:
            # Convert string to enum if needed
            if isinstance(portfolio_type, str):
                try:
                    portfolio_type = PortfolioType(portfolio_type)
                except ValueError as e:
                    raise ValueError(
                        f"Invalid portfolio type: {portfolio_type}. Valid values are: {[t.value for t in PortfolioType]}"
                    ) from e
            params["type"] = portfolio_type.value

        # Use urlencode for proper URL encoding
        query_string = urlencode(params)
        return f"/api/v1/portfolios/?{query_string}"

    def _get_13f_portfolios_url(
        self,
        limit: int = 50,
        offset: int = 0,
        name: Optional[str] = None,
    ) -> str:
        # Build query parameters dictionary, excluding None values
        params: Dict[str, Union[int, str]] = {"limit": limit, "offset": offset}

        if name is not None:
            params["name"] = name

        # Use urlencode for proper URL encoding
        query_string = urlencode(params)
        return f"/api/v1/portfolios/13f/?{query_string}"

    def _get_historical_portfolio_positions_url(
        self,
        portfolio_id: int,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> str:
        base_url = f"/api/v1/portfolios/{portfolio_id}/historical_positions"

        # Build query parameters dictionary, excluding None values
        params: Dict[str, Union[int, str]] = {}
        if start_date is not None:
            params["start_date"] = start_date
        if end_date is not None:
            params["end_date"] = end_date

        if params:
            # Use urlencode for proper URL encoding
            query_string = urlencode(params)
            return f"{base_url}?{query_string}"
        return base_url

    def _get_optimizer_url(self, portfolio_id: int) -> str:
        return f"/api/v1/portfolios/{portfolio_id}/optimize"

    def _process_response_for_portfolio(self, response: Dict[str, Any]) -> Portfolio:
        if response.get(STATUS) == OK:
            data = response.get(DATA)
            if data and data.get("type") == "13F":
                return ThirteenFPortfolio(**data)
            return Portfolio(**data)  # type: ignore
        raise _parse_api_error_response(response.get(DATA))

    def _process_response_for_all_portfolios(self, response: Dict[str, Any]) -> List[Portfolio]:
        if response.get(STATUS) == OK:
            return [Portfolio(**portfolio) for portfolio in response.get(DATA)]  # type: ignore
        raise _parse_api_error_response(response.get(DATA))

    def _process_response_for_13f_portfolios(self, response: Dict[str, Any]) -> List[ThirteenFPortfolio]:
        if response.get(STATUS) == OK:
            return [ThirteenFPortfolio(**portfolio) for portfolio in response.get(DATA)]  # type: ignore
        raise _parse_api_error_response(response.get(DATA))

    def _process_response_for_create_portfolio(self, response: Dict[str, Any]) -> PortfolioCreate:
        if response.get(STATUS) == OK:
            return PortfolioCreate(**response.get(DATA))  # type: ignore
        raise _parse_api_error_response(response.get(DATA))

    def _process_response_for_update_portfolio(self, response: Dict[str, Any]) -> PortfolioUpdate:
        if response.get(STATUS) == OK:
            return PortfolioUpdate(**response.get(DATA))  # type: ignore
        raise _parse_api_error_response(response.get(DATA))

    def _process_response_for_portfolio_sharing(self, response: Dict[str, Any]) -> PortfolioSharing:
        if response.get(STATUS) == OK:
            return PortfolioSharing(**response.get(DATA))  # type: ignore
        raise _parse_api_error_response(response.get(DATA))

    def _process_response_for_latest_portfolio_positions(self, response: Dict[str, Any]) -> PortfolioData:
        if response.get(STATUS) != ERROR:
            return PortfolioData(
                data=[Position(**position) for position in response.get(DATA)],  # type: ignore
                aum=response.get("aum"),
            )
        raise _parse_api_error_response(response.get(DATA))

    def _process_response_for_historical_portfolio_positions(
        self, response: Dict[str, Any]
    ) -> TimeseriesHistoricalPortfolioData:
        if response.get(STATUS) != ERROR:
            return TimeseriesHistoricalPortfolioData(
                data=[
                    HistoricalPortfolioData(
                        date=single_day_data.get("date"),
                        aum=single_day_data.get("aum"),
                        data=[Position(**position) for position in single_day_data.get("data", [])],
                    )
                    for single_day_data in response.get(DATA, [])
                ]
            )
        raise _parse_api_error_response(response.get(DATA))

    def _process_response_for_portfolio_timeseries(self, response: Dict[str, Any]) -> pd.DataFrame:
        if response.get(STATUS) != ERROR:
            ts = Timeseries(data=[TimestampWithValue(**val) for val in response.get(DATA)])  # type: ignore
            return ts.to_df()
        raise _parse_api_error_response(response.get(DATA))

    def _process_response_for_portfolio_timeseries_batch(
        self, response: Dict[str, Any]
    ) -> Tuple[pd.DataFrame, List[int]]:
        if response.get(STATUS) != ERROR:
            data = PortfolioTimeseriesBatch(data=[PortfolioTimeseries(**timeseries) for timeseries in response.get(DATA)], invalid_ids=response.get(INVALID_IDS, []))  # type: ignore
            return data.to_df(), data.invalid_ids

        raise _parse_api_error_response(response.get(DATA))

    def _process_response_for_portfolio_summary(self, response: Dict[str, Any]) -> PortfolioSummary:
        if response.get(STATUS) != ERROR:
            return PortfolioSummary(data=response.get(DATA))  # type: ignore

        raise _parse_api_error_response(response.get(DATA))

    def _process_response_for_portfolio_performance_summary_stats(
        self, response: Dict[str, Any]
    ) -> PortfolioPerformanceSummaryStats:
        if response.get(STATUS) != ERROR:
            return PortfolioPerformanceSummaryStats(
                data={
                    data["section"][0]["stat"]: SectionBlock(
                        detailed_breakdown=[
                            BreakdownStat(**breakdown_stat) for breakdown_stat in data["detailed_breakdown"]
                        ]
                    )
                    for data in response.get(DATA)  # type: ignore
                }
            )

        raise _parse_api_error_response(response.get(DATA))

    def _process_response_for_portfolio_metadata(self, response: Dict[str, Any]) -> List[IdName]:
        if response.get(STATUS) == OK:
            return [IdName(**value) for value in response.get(DATA)]  # type: ignore

        raise _parse_api_error_response(response.get(DATA))

    def _process_response_for_portfolio_drilldown(self, response: Dict[str, Any]) -> PortfolioDrillDown:
        if response.get(STATUS) != ERROR:
            return PortfolioDrillDown(data=response.get(DATA))  # type: ignore

        raise _parse_api_error_response(response.get(DATA))

    def _process_response_for_factor_exposure(self, response: Dict[str, Any]) -> PortfolioFactorExposure:
        if response.get(STATUS) != ERROR:
            return PortfolioFactorExposure(data=response.get(DATA))  # type: ignore

        raise _parse_api_error_response(response.get(DATA))

    def _process_response_for_asset_contribution(self, response: Dict[str, Any]) -> PortfolioAssetContribution:
        if response.get(STATUS) != ERROR:
            return PortfolioAssetContribution(data=response.get(DATA))  # type: ignore

        raise _parse_api_error_response(response.get(DATA))

    def _process_response_for_portfolio_metrics(self, response: Dict[str, Any]) -> PortfolioMetric:
        if response.get(STATUS) != ERROR:
            return PortfolioMetric(**response.get(DATA))  # type: ignore

        raise _parse_api_error_response(response.get(DATA))

    def _process_response_for_optimizer(self, response: Dict[str, Any]) -> Portfolio:
        if response.get(STATUS) == OK:
            return OptimizedPortfolio(**response.get(DATA))  # type: ignore
        raise _parse_api_error_response(response.get(DATA))
