# pylint: disable=too-many-arguments, too-many-locals, too-many-branches, too-many-statements
from __future__ import annotations

import inspect
from enum import Enum
from typing import Any, Callable, Dict, Optional, Type, Union

from pydantic import BaseModel, ValidationError

from arcana.models.error_schemas import BadRequestError


def _handle_validation_error(
    error: ValidationError, model_class: Type[BaseModel], func: Optional[Callable[..., Any]] = None
) -> BadRequestError:
    """
    Handle Pydantic validation errors and generate a user-friendly error message.

    Args:
        error (ValidationError): The Pydantic validation error to handle
        model_class (Type[BaseModel]): The Pydantic model class that caused the error
        func (Optional[Callable]): The function whose signature should be used for error message.
            If provided, will extract arguments from function signature and docstring.

    Returns:
        BadRequestError: A user-friendly error with field descriptions and validation details

    Example:
        try:
            model = MyModel(**data)
        except ValidationError as e:
            raise handle_validation_error(e, MyModel, get_timeseries)
    """
    # Get validation error details
    error_details = []
    for err in error.errors():
        field = err.get("loc", [""])[0]
        msg = err.get("msg", "")
        error_details.append(f"{field}: {msg}")

    field_descriptions = []

    if func:
        # Get function signature and docstring
        sig = inspect.signature(func)
        doc = inspect.getdoc(func) or ""

        # Parse docstring to get parameter descriptions
        param_docs: Dict[str, str] = {}
        current_param = None
        for line in doc.split("\n"):
            line = line.strip()
            if line.startswith("Args:"):
                continue
            if line.startswith("Returns:") or line.startswith("Examples:"):
                break
            if line.startswith("    "):
                if current_param:
                    param_docs[current_param] = line.strip()
            elif ":" in line:
                current_param = line.split(":")[0].strip()

        # Process each parameter
        for name, param in sig.parameters.items():
            if name == "self":
                continue

            # Get parameter type
            param_type = param.annotation
            if hasattr(param_type, "__origin__") and param_type.__origin__ is Union:
                # Handle Optional types
                types = [t for t in param_type.__args__ if t is not type(None)]
                param_type = types[0] if types else Any

            # Convert type to string
            if isinstance(param_type, type):
                type_str = param_type.__name__
            else:
                type_str = str(param_type)

            # Handle enum types
            if isinstance(param_type, type) and issubclass(param_type, Enum):
                enum_values = [e.value for e in param_type]
                type_str = f"enum: [{', '.join(f'{v!r}' for v in enum_values)}]"

            # Get description from docstring
            description = param_docs.get(name, name)

            # Handle default value
            if (default := param.default) is not inspect.Parameter.empty:
                default_str = f" (default: {default!r})"
            else:
                default_str = ""

            field_descriptions.append(f"- {name} ({type_str}){default_str}: {description}")
    else:
        # Fallback to schema parsing if no function provided
        schema = model_class.model_json_schema()

        def process_properties(properties: Dict[str, Any], prefix: str = "") -> None:
            for field_name, field_info in properties.items():
                # Skip internal fields
                if field_name.startswith("$"):
                    continue

                description = field_info.get("description", field_name)
                field_type = field_info.get("type", "")

                # Handle nested objects
                if field_type == "object" and "properties" in field_info:
                    process_properties(field_info["properties"], f"{prefix}{field_name}.")
                    continue

                # Handle arrays
                if field_type == "array" and "items" in field_info:
                    items = field_info["items"]
                    if isinstance(items, dict) and items.get("type") == "object":
                        process_properties(items.get("properties", {}), f"{prefix}{field_name}.")
                        continue

                # Handle enums
                if "enum" in field_info:
                    enum_values = ", ".join(f"'{v}'" for v in field_info["enum"])
                    field_type = f"enum: [{enum_values}]"

                # Handle default values
                default = field_info.get("default")
                default_str = f" (default: {default})" if default is not None else ""

                # Build the field description
                full_field_name = f"{prefix}{field_name}"
                field_descriptions.append(f"- {full_field_name} ({field_type}){default_str}: {description}")

        # Process the main properties
        properties = schema.get("properties", {})
        process_properties(properties)

    error_message = (
        "Invalid parameters provided. Please check the following fields:\n"
        f"{chr(10).join(error_details)}\n\n"
        "Valid parameters are:\n"
        f"{chr(10).join(field_descriptions)}"
    )
    return BadRequestError(error_message)
