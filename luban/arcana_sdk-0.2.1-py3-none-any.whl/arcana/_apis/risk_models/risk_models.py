from __future__ import annotations

from typing import Any, Dict, List

from arcana._apis.error_handler import _parse_api_error_response
from arcana.constants.internal import DATA, OK, STATUS
from arcana.models.request import RiskModelFilterSchema
from arcana.models.response.risk_models import RiskModel


class _RiskModel:

    def _build_get_all_risk_models_url(self, limit: int, offset: int, filter_schema: RiskModelFilterSchema) -> str:
        url = f"/api/v1/risk_models/?limit={limit}&offset={offset}"
        if query_param := filter_schema.as_query_string():
            url = f"{url}&{query_param}"

        return url

    def _process_response_for_all_risk_models(self, response: Dict[str, Any]) -> List[RiskModel]:
        if response.get(STATUS) == OK:
            return [RiskModel(**model) for model in response.get(DATA)]  # type: ignore

        raise _parse_api_error_response(response.get(DATA))

    def _process_response_for_get_risk_model_by_id(self, response: Dict[str, Any]) -> RiskModel:
        if response.get(STATUS) == OK:
            return RiskModel(**response.get(DATA))  # type: ignore

        raise _parse_api_error_response(response.get(DATA))
