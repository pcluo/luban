from __future__ import annotations

from typing import List, Optional

from pydantic import ValidationError

from arcana._apis.risk_models.risk_models import _RiskModel
from arcana._apis.utils import _handle_validation_error
from arcana._clients.sync_client import _SyncAPIClient
from arcana.models.request import RiskModelFilterSchema
from arcana.models.response.risk_models import RiskModel


class _RiskModelsSync(_RiskModel):
    """
    [INTERNAL] Synchronous wrapper for Risk Models API.

    This class is not part of the public SDK interface. It is used internally
    by the ArcanaSDK to provide synchronous access to the Risk Models endpoints.

    Attributes:
        client (_SyncAPIClient): Internal synchronous API client used to perform requests.
    """

    def __init__(self, client: _SyncAPIClient) -> None:
        """
        Initialize the Risk Models API with a synchronous API client.

        Args:
            client: An instance of the internal synchronous API client.
        """
        self._client: _SyncAPIClient = client

    def get_all(
        self,
        limit: int = 50,
        offset: int = 0,
        name: Optional[str] = None,
    ) -> List[RiskModel]:
        """
        Retrieve a list of available risk models, with optional filtering and pagination.

        Args:
            limit: Maximum number of models to return. Must be between 1 and 1000. Defaults to 50.
            offset: Offset for pagination. Must be >= 0. Defaults to 0.
            name: Optional partial or exact name of the risk model to filter by. Case-insensitive.

        Returns:
            A list of deserialized risk model responses.

        Raises:
            ValidationError: If the filter schema validation fails.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no risk models are found matching the criteria.

        Examples:
            # Get all risk models with default pagination
            risk_models = client.get_all()

            # Get risk models with name filter
            risk_models = client.get_all(
                name="Intraday"
            )

            # Get risk models with custom pagination
            risk_models = client.get_all(
                limit=100,
                offset=50
            )

            # Get risk models with name filter and custom pagination
            risk_models = client.get_all(
                name="Intraday",
                limit=100,
                offset=50
            )
        """
        try:
            filter_schema_obj = RiskModelFilterSchema(name=name)
        except ValidationError as e:
            raise _handle_validation_error(e, RiskModelFilterSchema) from None

        url = self._build_get_all_risk_models_url(limit, offset, filter_schema_obj)
        return self._process_response_for_all_risk_models(self._client.get(path=url))

    def get_by_id(self, risk_model_id: int) -> RiskModel:
        """
        Retrieve a single risk model by its unique identifier.

        Args:
            risk_model_id: The ID of the risk model to retrieve. Must be a positive integer.

        Returns:
            A deserialized risk model response object.

        Raises:
            ValidationError: If the risk_model_id is invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no risk model is found with the given ID.

        Examples:
            # Get a specific risk model by ID
            risk_model = client.get_by_id(risk_model_id=3)

            # Get the US Intraday risk model
            us_intraday = client.get_by_id(risk_model_id=3)
        """
        url = f"/api/v1/risk_models/{risk_model_id}"
        return self._process_response_for_get_risk_model_by_id(self._client.get(path=url))
