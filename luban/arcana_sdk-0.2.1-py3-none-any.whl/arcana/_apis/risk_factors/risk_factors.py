from __future__ import annotations

from typing import Any, Dict, List, Tuple

import pandas as pd

from arcana._apis.error_handler import _parse_api_error_response
from arcana.constants.internal import DATA, ERROR, INVALID_IDS, OK, STATUS
from arcana.models.common import Timeseries, TimestampWithValue
from arcana.models.request import RiskFactorsFilterSchema
from arcana.models.response.risk_factors import (
    BatchRiskFactorTimeseries,
    RiskFactor,
    RiskFactorCategory,
    _RiskFactorTimeseries,
)


class _RiskFactors:
    """
    Internal base class for processing Risk factors API operations and responses.

    This class encapsulates shared logic for handling responses from the Risk factors API,
    used across both synchronous and asynchronous SDK clients.
    """

    def _get_all_risk_factors_url(
        self,
        limit: int = 50,
        offset: int = 0,
        filter_schema: RiskFactorsFilterSchema = RiskFactorsFilterSchema(),
    ) -> str:
        base_url = f"/api/v1/risk_factors/?limit={limit}&offset={offset}"
        base_url = f"{base_url}&{filter_schema.as_query_string()}"
        return base_url

    def _get_all_risk_factors_categories_url(self, limit: int = 50, offset: int = 0) -> str:
        return f"/api/v1/risk_factors/categories?limit={limit}&offset={offset}"

    def _process_response_for_all_risk_factors(self, response: Dict[str, Any]) -> List[RiskFactor]:
        if response.get(STATUS) == OK:
            return [RiskFactor(**rf) for rf in response.get(DATA)]  # type: ignore
        raise _parse_api_error_response(response.get(DATA))

    def _process_response_for_risk_factor_category(self, response: Dict[str, Any]) -> List[RiskFactorCategory]:
        if response.get(STATUS) == OK:
            return [RiskFactorCategory(**category) for category in response.get(DATA)]  # type: ignore
        raise _parse_api_error_response(response.get(DATA))

    def _process_response_for_risk_factor_timeseries(self, response: Dict[str, Any]) -> pd.DataFrame:
        if response.get(STATUS) != ERROR:
            ts = Timeseries(data=[TimestampWithValue(**val) for val in response.get(DATA)])  # type: ignore
            return ts.to_df()
        raise _parse_api_error_response(response.get(DATA))

    def _process_response_for_batch_risk_factor_timeseries(
        self, response: Dict[str, Any]
    ) -> Tuple[pd.DataFrame, List[int]]:
        if response.get(STATUS) != ERROR:
            ts = BatchRiskFactorTimeseries(data=[_RiskFactorTimeseries(**val) for val in response.get(DATA)], invalid_ids=response.get(INVALID_IDS, []))  # type: ignore
            return ts.to_df(), ts.invalid_ids
        raise _parse_api_error_response(response.get(DATA))
