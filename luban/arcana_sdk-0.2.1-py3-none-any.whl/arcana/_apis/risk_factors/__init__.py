from __future__ import annotations

from .sync_risk_factors import _RiskFactorsSync

__all__ = [
    "_RiskFactorsSync",
]
