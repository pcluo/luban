from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd
from pydantic import ValidationError

from arcana._apis.risk_factors.risk_factors import _RiskFactors
from arcana._apis.utils import _handle_validation_error
from arcana._clients.sync_client import _SyncAPIClient
from arcana.models.common import TimeRangeWithGrain
from arcana.models.enums import Periodicity, PresetRange, RiskFactorTimeseriesMetric, TimeGrain, TransformMode
from arcana.models.request import BatchRiskFactorTimeseriesRequest, RiskFactorsFilterSchema, RiskFactorTimeseriesRequest
from arcana.models.response.risk_factors import RiskFactor, RiskFactorCategory


class _RiskFactorsSync(_RiskFactors):
    """
    [INTERNAL] Synchronous wrapper for the Risk Factors API.

    This class provides synchronous methods to interact with risk factor-related endpoints
    including retrieval of risk factors, categories, and timeseries data. It is used internally
    by the Arcana SDK and is not part of the public SDK interface.

    Attributes:
        client (_SyncAPIClient): Internal synchronous API client used to perform requests.
        _sdk (ArcanaSDK): Reference to the parent SDK instance.
    """

    def __init__(self, client: _SyncAPIClient) -> None:
        """
        Initialize the Risk Factors API with a synchronous API client.

        :param client: An instance of the internal synchronous API client.
        :type client: _SyncAPIClient
        :param sdk: The parent SDK instance.
        :type sdk: ArcanaSDK
        """
        self._client: _SyncAPIClient = client

    def get_all(
        self,
        limit: int = 50,
        offset: int = 0,
        risk_factor_category_id: Optional[int] = None,
        risk_model_id: int = 3,
    ) -> List[RiskFactor]:
        """
        Retrieve a list of risk factors with optional filtering and pagination.

        Args:
            limit: Maximum number of risk factors to return. Defaults to 50.
            offset: Offset for pagination. Defaults to 0.
            risk_factor_category_id: Optional ID of the risk factor category to filter by.
            risk_model_id: ID of the risk model to use. Defaults to 3.

        Returns:
            A list of RiskFactor objects.

        Raises:
            ValidationError: If the filter schema validation fails.
            BadRequestError: If the API request is invalid.

        Examples:
            ### Get all risk factors with default pagination
            risk_factors = client.get_all()

            ### Get risk factors for a specific category
            risk_factors = client.get_all(
                risk_factor_category_id=5
            )

            ### Get risk factors with custom risk model
            risk_factors = client.get_all(
                risk_model_id=5
            )

            ### Get risk factors with custom pagination
            risk_factors = client.get_all(
                limit=100,
                offset=50,
                risk_factor_category_id=5
            )
        """
        try:
            filter_schema_obj = RiskFactorsFilterSchema(
                category_id=risk_factor_category_id, risk_model_id=risk_model_id
            )
        except ValidationError as e:
            raise _handle_validation_error(e, RiskFactorsFilterSchema, self.get_all) from None

        url = self._get_all_risk_factors_url(limit, offset, filter_schema_obj)
        return self._process_response_for_all_risk_factors(self._client.get(path=url))

    def _process_response_for_all_risk_factors(self, response: Dict[str, Any]) -> List[RiskFactor]:

        risk_factors = super()._process_response_for_all_risk_factors(response)
        for rf in risk_factors:
            setattr(rf, "_risk_factors_api", self)
        return risk_factors

    def get_categories(self) -> List[RiskFactorCategory]:
        """
        Retrieve all available risk factor categories.

        Returns:
            A list of risk factor category response objects.

        Raises:
            BadRequestError: If the API request is invalid.

        Examples:
            ### Get all risk factor categories
            categories = client.get_categories()
        """
        return self._process_response_for_risk_factor_category(self._client.get(path="/api/v1/risk_factors/categories"))

    def _get_timeseries(
        self,
        risk_factor_id: int,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        preset_range: Optional[PresetRange] = None,
        metric: RiskFactorTimeseriesMetric = RiskFactorTimeseriesMetric.TOTAL_RETURN,
        grain: TimeGrain = TimeGrain.DAY,
        risk_model_id: int = 3,
        mode: TransformMode = TransformMode.DAILY,
        periodicity: Optional[Periodicity] = None,
    ) -> pd.DataFrame:
        """
        Retrieve time series data for a specific risk factor.

        Args:
            risk_factor_id: ID of the risk factor. Must be a positive integer.
            start_time: Start time in ISO format (e.g., "2023-01-01"). Required if preset_range is not provided.
            end_time: End time in ISO format (e.g., "2023-12-31"). Required if preset_range is not provided.
            preset_range: Predefined time range. One of ["RANGE_1W", "RANGE_1M", "RANGE_3M", "RANGE_YTD", "RANGE_1Y",
                "RANGE_5Y", "RANGE_MTD", "RANGE_QTD"]. If provided, start_time and end_time are ignored.
            metric: The metric to compute over time. One of ["TOTAL_RETURN", "FACTOR_VOL"].
                Defaults to "TOTAL_RETURN".
            grain: Time grain for the data points. One of ["DAY", "WEEK", "MONTH", "QUARTER", "YEAR"]. Defaults to "DAY".
            mode: Output mode for the data. One of ["CUMULATIVE", "DAILY"]. Defaults to "CUMULATIVE".
            periodicity: Optional frequency override. One of ["DOD", "WOW", "MOM", "QOQ", "YOY"]. Defaults to None.

        Returns:
            DataFrame with the timeseries data.

        Raises:
            ValueError: If neither start_time nor preset_range is provided.
            ValidationError: If any of the parameters are invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no risk factor is found with the given ID.

        Examples:
            ### Get daily timeseries data with date range
            timeseries = client.get_timeseries(
                risk_factor_id=123,
                start_time="2023-01-01"
            )

            ### Get timeseries data with preset range
            timeseries = client.get_timeseries(
                risk_factor_id=123,
                preset_range="RANGE_1M"  # Last month's data
            )

            ### Get timeseries with custom metric and grain
            timeseries = client.get_timeseries(
                risk_factor_id=123,
                start_time="2023-01-01",
                end_time="2023-12-31",
                grain="WEEK",
                mode="PERIODIC",
                periodicity="MOM"  # Month over Month
            )

            ### Get timeseries with DAILY output mode
            timeseries = client.get_timeseries(
                start_time="2023-01-01",
                end_time="2023-12-31",
                mode="DAILY",
                grain="WEEK",
                metric="FACTOR_VOL"
            )
        """
        if preset_range is None and start_time is None:
            raise ValueError("Either start_time or preset_range must be provided")

        if end_time is None and preset_range is None:
            end_time = datetime.now().strftime("%Y-%m-%d")

        try:
            request_obj = RiskFactorTimeseriesRequest(
                time_range=TimeRangeWithGrain(
                    start_time=start_time, end_time=end_time, preset_range=preset_range, grain=grain
                ),
                metric=metric,
                mode=mode,
                periodicity=periodicity,
                risk_model_id=risk_model_id,
            )
        except ValidationError as e:
            raise _handle_validation_error(e, RiskFactorTimeseriesRequest, self._get_timeseries) from None

        return self._process_response_for_risk_factor_timeseries(
            self._client.post(
                path=f"/api/v1/risk_factors/{risk_factor_id}/timeseries",
                data=request_obj.model_dump_json(exclude_none=True),
            )
        )

    def get_timeseries_batch(
        self,
        risk_factor_ids: List[int],
        metric: RiskFactorTimeseriesMetric = RiskFactorTimeseriesMetric.TOTAL_RETURN,
        start_time: Optional[str] = None,
        preset_range: Optional[PresetRange] = None,
        end_time: Optional[str] = None,
        grain: TimeGrain = TimeGrain.DAY,
        risk_model_id: int = 3,
        mode: TransformMode = TransformMode.DAILY,
        periodicity: Optional[Periodicity] = None,
    ) -> Tuple[pd.DataFrame, List[int]]:
        """
        Fetch time series data for multiple risk factors in a single request.

        Args:
            risk_factor_ids: List of risk factor IDs to fetch data for.
            metric: The metric to compute over time. One of ["TOTAL_RETURN", "FACTOR_VOL"].
                Defaults to "TOTAL_RETURN".
            start_time: Start time in ISO format (e.g., "2023-01-01").
            preset_range: Predefined time range. One of ["RANGE_1W", "RANGE_1M", "RANGE_3M", "RANGE_YTD", "RANGE_1Y",
                "RANGE_5Y", "RANGE_MTD", "RANGE_QTD"]. If provided, start_time and end_time are ignored.
            end_time: End time in ISO format (e.g., "2023-12-31"). Defaults to current datetime if not provided.
            grain: Time grain for the data points. Defaults to "DAY".
            risk_model_id: ID of the risk model to use. Defaults to 3.
            mode: Data aggregation mode. Defaults to "DAILY".
            periodicity: Optional frequency override. One of ["DOD", "WOW", "MOM", "QOQ", "YOY"]. Defaults to None.
        Returns:
            Tuple[DataFrame, List[int]]: A tuple containing:
                - DataFrame with the timeseries data.
                - List of invalid risk factor IDs.

        Raises:
            ValueError: If neither start_time nor preset_range is provided, or if risk_factor_ids is empty.
            ValidationError: If any of the parameters are invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no risk factor is found with the given ID.

        Examples:
            # Get daily data for multiple risk factors
            timeseries, invalid_ids = sdk.risk_factors.get_timeseries_batch(
                risk_factor_ids=[1, 2, 3],
                metric="TOTAL_RETURN",
                start_time="2024-12-25T00:00:00-05:00",
                end_time="2024-12-27T00:00:00-05:00"
            )

            # Get data from start time to current datetime
            timeseries, invalid_ids = sdk.risk_factors.get_timeseries_batch(
                risk_factor_ids=[1, 2, 3],
                start_time="2023-01-01",
                metric="FACTOR_VOL"
            )

            # Get data with custom grain and mode
            timeseries, invalid_ids = sdk.risk_factors.get_timeseries_batch(
                risk_factor_ids=[1, 2, 3],
                preset_range="RANGE_1Y",
                grain="WEEK",
                mode="CUMULATIVE",
                periodicity="WOW"
            )

            >> timeseries, invalid_ids = sdk.risk_factors.get_timeseries_batch(
                        risk_factor_ids=[1, 2, -1],
                        metric="TOTAL_RETURN",
                        preset_range="RANGE_1Y"
                    )
            >> timeseries
                                            1         2
            timestamp
            2024-11-18T16:00:00-05:00  0.043586  0.083366
            2024-11-19T16:00:00-05:00  0.019077  0.464545
            2024-11-20T16:00:00-05:00  0.085426 -0.088280
            2024-11-21T16:00:00-05:00  0.129864  0.227225
            2024-11-22T16:00:00-05:00  0.156280 -0.088013
            ...                             ...       ...
            [250 rows x 2 columns]
        """
        if preset_range is None and start_time is None:
            raise ValueError("Either start_time or preset_range must be provided")

        if not risk_factor_ids:
            raise ValueError("risk_factor_ids must not be empty")

        if end_time is None and preset_range is None:
            end_time = datetime.now().strftime("%Y-%m-%d")

        try:
            request_obj = BatchRiskFactorTimeseriesRequest(
                risk_factor_ids=risk_factor_ids,
                metric=metric,
                time_range=TimeRangeWithGrain(
                    start_time=start_time, end_time=end_time, preset_range=preset_range, grain=grain
                ),
                mode=mode,
                periodicity=periodicity,
                risk_model_id=risk_model_id,
            )
        except ValidationError as e:
            raise _handle_validation_error(e, BatchRiskFactorTimeseriesRequest) from None

        response = self._client.post(
            path="/api/v1/risk_factors/timeseries/batch",
            data=request_obj.model_dump_json(exclude_none=True),
        )
        return self._process_response_for_batch_risk_factor_timeseries(response)
