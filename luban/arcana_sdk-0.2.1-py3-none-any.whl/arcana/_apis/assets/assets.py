# pylint: disable=too-many-arguments, too-many-locals, too-many-branches, too-many-statements
from __future__ import annotations

from typing import Any, Dict, List, Optional
from urllib.parse import urlencode

import pandas as pd

from arcana._apis.error_handler import _parse_api_error_response
from arcana.constants.internal import DATA, ERROR, OK, STATUS
from arcana.models.common import Timeseries, TimestampWithValue
from arcana.models.error_schemas import UnprocessableError
from arcana.models.response.assets import Asset, AssetSearch, AssetTimeseries, BatchAssetTimeseries, SingleAssetSearch


class _Assets:
    """
    Internal base class for processing Asset API operations and responses.

    This class encapsulates shared logic for handling responses from the Assets API,
    used across both synchronous and asynchronous SDK clients. It validates responses
    and raises APIError subclasses for error conditions.
    """

    def _get_all_assets_url(
        self,
        limit: int = 50,
        offset: int = 0,
        ticker: Optional[str] = None,
        isin: Optional[str] = None,
        sedol: Optional[str] = None,
        cusip: Optional[str] = None,
        figi: Optional[str] = None,
        composite_figi: Optional[str] = None,
        open_figi_ticker: Optional[str] = None,
        asset_type: Optional[str] = None,
        name: Optional[str] = None,
        exchange: Optional[str] = None,
        currency: Optional[str] = None,
        country: Optional[str] = None,
    ) -> str:
        # Build query parameters dictionary, excluding None values
        params: dict[str, str | int] = {"limit": limit, "offset": offset}

        if ticker is not None:
            params["ticker"] = ticker
        if isin is not None:
            params["isin"] = isin
        if sedol is not None:
            params["sedol"] = sedol
        if cusip is not None:
            params["cusip"] = cusip
        if figi is not None:
            params["figi"] = figi
        if composite_figi is not None:
            params["composite_figi"] = composite_figi
        if open_figi_ticker is not None:
            params["open_figi_ticker"] = open_figi_ticker
        if asset_type is not None:
            params["asset_type"] = asset_type
        if name is not None:
            params["name"] = name
        if exchange is not None:
            params["exchange"] = exchange
        if currency is not None:
            params["currency"] = currency
        if country is not None:
            params["country"] = country

        # Use urlencode for proper URL encoding
        query_string = urlencode(params)
        return f"/api/v1/assets/?{query_string}"

    def _process_response_for_all_assets(self, response: Dict[str, Any]) -> List[Asset]:
        if response.get(STATUS) == OK:
            return [Asset(**asset) for asset in response.get(DATA)]  # type: ignore
        raise _parse_api_error_response(response.get(DATA))

    def _process_response_for_single_asset(self, response: Dict[str, Any]) -> Asset:
        if response.get(STATUS) == OK:
            return Asset(**response.get(DATA))  # type: ignore
        raise _parse_api_error_response(response.get(DATA))

    def _process_response_for_batch_asset_search(self, response: Dict[str, Any]) -> AssetSearch:
        """
        Parses the response from the batch asset search API.

        If the response indicates success, it returns a parsed AssetSearchResponse object.
        If the response indicates an error, it raises an appropriate subclass of APIError.

        Args:
            response (Dict[str, Any]): The raw JSON response from the API.

        Returns:
            AssetSearchResponse: Parsed list of asset matches.

        Raises:
            APIError: A specific subclass (e.g., BadRequestError, InternalServerError) based on API error content.
        """

        if response.get(STATUS) != ERROR:
            return AssetSearch(data=[SingleAssetSearch(**model) for model in response.get(DATA)])  # type: ignore

        raise _parse_api_error_response(response.get(DATA))

    def _process_response_for_asset_timeseries(self, response: Dict[str, Any]) -> pd.DataFrame:

        if response.get(STATUS) != ERROR:
            ts = Timeseries(data=[TimestampWithValue(**val) for val in response.get(DATA)])  # type: ignore
            return ts.to_df()

        raise _parse_api_error_response(response.get(DATA))

    def _process_response_for_batch_asset_timeseries(self, response: Dict[str, Any]) -> pd.DataFrame:
        if response.get(STATUS) != ERROR:
            ts = BatchAssetTimeseries(
                data=[AssetTimeseries(**timeseries) for timeseries in response.get(DATA)],  # type: ignore
                invalid_ids=response.get("invalid_ids"),
            )
            return ts.to_df()

        raise _parse_api_error_response(response.get(DATA))

    def _process_response_for_update_metric_value_batch(self, response: Dict[str, Any]) -> None:
        if response.get(STATUS) != ERROR:
            data = response.get(DATA)
            if data and data.get("errors"):
                raise UnprocessableError(error_message=data.get("errors"))
            return None

        raise _parse_api_error_response(response.get(DATA))
