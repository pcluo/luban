# pylint: disable=too-many-arguments, too-many-locals, too-many-branches, too-many-statements
from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional, Union

import pandas as pd
from pydantic import ValidationError

from arcana._apis.assets.assets import _Assets
from arcana._apis.utils import _handle_validation_error
from arcana._clients.sync_client import _SyncAPIClient
from arcana.models.common import SingleEntityTimeseriesRequest, TimeRangeWithGrain
from arcana.models.enums import AssetIdentifiersEnum, Periodicity, PresetRange, TimeGrain, TransformMode
from arcana.models.request import AssetsSearchRequest, BatchAssetTimeseriesRequest
from arcana.models.request.consolidated_models import AssetMetricSnapshot, AssetMetricUploadRequest
from arcana.models.response.assets import Asset, AssetSearch


class _AssetsSync(_Assets):
    """
    [INTERNAL] Synchronous wrapper for the Assets API.

    This class provides synchronous methods to interact with asset-related endpoints.
    It is used internally by the Arcana SDK and is not part of the public SDK interface.

    :param client: An instance of the internal synchronous API client.
    :type client: _SyncAPIClient
    """

    def __init__(self, client: _SyncAPIClient) -> None:
        self._client: _SyncAPIClient = client

    def get_all(
        self,
        limit: int = 50,
        offset: int = 0,
        ticker: Optional[str] = None,
        isin: Optional[str] = None,
        sedol: Optional[str] = None,
        cusip: Optional[str] = None,
        figi: Optional[str] = None,
        composite_figi: Optional[str] = None,
        open_figi_ticker: Optional[str] = None,
        asset_type: Optional[str] = None,
        name: Optional[str] = None,
        exchange: Optional[str] = None,
        currency: Optional[str] = None,
        country: Optional[str] = None,
    ) -> List[Asset]:
        """
        Retrieve a list of assets with optional filtering and pagination.

        Args:
            limit: Maximum number of assets to return. Defaults to 50.
            offset: Offset for pagination. Defaults to 0.
            ticker: Filter by ticker symbol (e.g., "AAPL")
            isin: Filter by ISIN (e.g., "US0378331005")
            sedol: Filter by SEDOL (e.g., "2046251")
            cusip: Filter by CUSIP (e.g., "037833100")
            figi: Filter by FIGI (e.g., "BBG000B9XRY4")
            composite_figi: Filter by Composite FIGI
            open_figi_ticker: Filter by OpenFIGI ticker
            asset_type: Filter by asset type (e.g., "equity")
            name: Filter by asset name (e.g., "Apple Inc.")
            exchange: Filter by exchange (e.g., "NASDAQ")
            currency: Filter by currency (e.g., "USD")
            country: Filter by country (e.g., "US")

        Returns:
            A list of deserialized asset responses.

        Examples:
            # Get all assets with default pagination
            assets = client.get_all()

            # Search by ticker
            apple_assets = client.get_all(ticker="AAPL")

            # Search by multiple criteria
            us_equities = client.get_all(
                asset_type="equity",
                country="US",
                exchange="NASDAQ"
            )

            # Search by ISIN
            specific_asset = client.get_all(isin="US0378331005")
        """
        url = self._get_all_assets_url(
            limit=limit,
            offset=offset,
            ticker=ticker,
            isin=isin,
            sedol=sedol,
            cusip=cusip,
            figi=figi,
            composite_figi=composite_figi,
            open_figi_ticker=open_figi_ticker,
            asset_type=asset_type,
            name=name,
            exchange=exchange,
            currency=currency,
            country=country,
        )
        return self._process_response_for_all_assets(self._client.get(path=url))

    def get_by_id(self, asset_id: int) -> Asset:
        """
        Retrieve a single asset by its unique identifier.

        :param asset_id: The ID of the asset to retrieve.
        :type asset_id: int
        :return: A deserialized asset response object.
        :rtype: AssetResponse
        """
        url = f"/api/v1/assets/{asset_id}"
        return self._process_response_for_single_asset(self._client.get(path=url))

    def _process_response_for_single_asset(self, response: Dict[str, Any]) -> Asset:
        asset_obj = super()._process_response_for_single_asset(response)
        setattr(asset_obj, "_assets_api", self)
        return asset_obj

    def get_batch(
        self,
        assets: List[Dict[Union[AssetIdentifiersEnum, str], str]],
    ) -> AssetSearch:
        """
        Search for assets in batch using various identifiers.

        Args:
            assets: List of dictionaries containing asset identifiers. Each dictionary can contain one or more of:
                - isin: ISIN identifier (e.g., "US0378331005")
                - sedol: SEDOL identifier (e.g., "B0YQ5W0")
                - cusip: CUSIP identifier (e.g., "037833100")
                - figi: FIGI identifier (e.g., "BBG000B9XRY4")
                - composite_figi: Composite FIGI identifier
                - open_figi_ticker: OpenFIGI ticker (e.g., "AAPL")
                - ticker: Ticker symbol (e.g., "AAPL")

        Returns:
            A deserialized asset search response object containing matches for each identifier.

        Raises:
            ValueError: If neither start_time nor preset_range is provided.
            ValidationError: If any of the parameters are invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no asset is found with the given ID.

        Examples:
            # Search by ISIN
            results = client.get_batch([
                {"isin": "US0378331005"}
            ])

            # Search by multiple identifiers
            results = client.get_batch([
                {"isin": "US0378331005"},
                {"sedol": "B0YQ5W0"},
                {"ticker": "AAPL"}
            ])

            # Search by FIGI
            results = client.get_batch([
                {"figi": "BBG000B9XRY4"}
            ])
        """
        try:
            request_obj = AssetsSearchRequest(assets=assets)
        except ValidationError as e:
            raise _handle_validation_error(e, AssetsSearchRequest) from None

        return self._process_response_for_batch_asset_search(
            self._client.post(path="/api/v1/assets/search/batch", data=request_obj.model_dump_json(exclude_none=True))
        )

    def _get_timeseries(
        self,
        asset_id: int,
        metric_id: int,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        preset_range: Optional[PresetRange] = None,
        risk_model_id: int = 3,
        grain: TimeGrain = TimeGrain.DAY,
        mode: TransformMode = TransformMode.DAILY,
        periodicity: Optional[Periodicity] = None,
    ) -> pd.DataFrame:
        """
        Fetch time series data for a single asset and a single metric.

        Args:
            asset_id: The ID of the asset to fetch time series data for.
            metric_id: The ID of the metric to fetch time series data for.
            start_time: Start time in ISO format (e.g., "2023-01-01"). Required if preset_range is not provided.
            end_time: End time in ISO format (e.g., "2023-12-31"). Required if preset_range is not provided.
            preset_range: Predefined time range. One of ["RANGE_1W", "RANGE_1M", "RANGE_3M", "RANGE_YTD", "RANGE_1Y",
                "RANGE_5Y", "RANGE_MTD", "RANGE_QTD"]. If provided, start_time and end_time are ignored.
            risk_model_id: ID of the risk model to use. Must be a positive integer. Defaults to 3.
            grain: Time grain for the data points. One of ["DAY", "WEEK", "MONTH", "QUARTER", "YEAR"]. Defaults to "DAY".
            risk_model_id: ID of the risk model to use. Defaults to 3 (US Intraday).
            mode: Data aggregation mode. One of ["DAILY", "CUMULATIVE"]. Defaults to "DAILY".
            periodicity: Optional frequency override. One of ["DOD", "WOW", "MOM", "QOQ", "YOY"]. Defaults to None.

        Returns:
            DataFrame with the timeseries data.

        Raises:
            ValueError: If neither start_time nor preset_range is provided.
            ValidationError: If any of the parameters are invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no asset is found with the given ID.

        Examples:
            # Get daily data for a specific date range
            timeseries = client.get_timeseries(
                asset_id=123,
                metric_id=37582,
                start_time="2023-01-01",
                end_time="2023-12-31"
            )

            # Get timeseries data with preset range
            timeseries = client.get_timeseries(
                asset_id=123,
                metric_id=37582,
                preset_range="RANGE_1M"  # Last month's data
            )

            # Get data from start time to current datetime
            timeseries = client.get_timeseries(
                asset_id=123,
                metric_id=37582,
                start_time="2023-01-01"
            )

            # Get data with custom grain and mode
            timeseries = client.get_timeseries(
                asset_id=123,
                metric_id=37582,
                start_time="2023-01-01",
                end_time="2023-12-31",
                grain="WEEK",
                mode="CUMULATIVE",
                periodicity="MOM"  # Month over Month
            )

            # Get data with periodicity
            timeseries = client.get_timeseries(
                asset_id=123,
                metric_id=37582,
                start_time="2023-01-01",
                mode="DAILY"
            )
        """
        if preset_range is None and start_time is None:
            raise ValueError("Either start_time or preset_range must be provided")

        if end_time is None and preset_range is None:
            end_time = datetime.now().strftime("%Y-%m-%d")

        try:
            request_obj = SingleEntityTimeseriesRequest(
                risk_model_id=risk_model_id,
                time_range=TimeRangeWithGrain(
                    start_time=start_time, end_time=end_time, preset_range=preset_range, grain=grain
                ),
                mode=mode,
                periodicity=periodicity,
            )
        except ValidationError as e:
            raise _handle_validation_error(e, SingleEntityTimeseriesRequest) from None

        return self._process_response_for_asset_timeseries(
            self._client.post(
                path=f"/api/v1/assets/{asset_id}/metrics/{metric_id}/timeseries",
                data=request_obj.model_dump_json(exclude_none=True),
            )
        )

    def get_timeseries_batch(
        self,
        metric_id: int,
        asset_ids: Optional[List[int]] = None,
        start_time: Optional[str] = None,
        preset_range: Optional[PresetRange] = None,
        end_time: Optional[str] = None,
        grain: TimeGrain = TimeGrain.DAY,
        risk_model_id: int = 3,
        mode: TransformMode = TransformMode.DAILY,
        portfolio_id: Optional[int] = None,
        periodicity: Optional[Periodicity] = None,
    ) -> pd.DataFrame:
        """
        Fetch time series data for multiple assets in a single request.

        Args:
            metric_id: The ID of the metric to fetch time series data for.
            asset_ids: List of asset IDs to fetch data for.
            start_time: Start time in ISO format (e.g., "2023-01-01").
            preset_range: Predefined time range. One of ["RANGE_1W", "RANGE_1M", "RANGE_3M", "RANGE_YTD", "RANGE_1Y",
                "RANGE_5Y", "RANGE_MTD", "RANGE_QTD"]. If provided, start_time and end_time are ignored.
            end_time: End time in ISO format (e.g., "2023-12-31"). Defaults to current datetime if not provided.
            grain: Time grain for the data points. Defaults to "DAY".
            risk_model_id: ID of the risk model to use. Defaults to 3 (US Intraday).
            mode: Data aggregation mode. Defaults to "DAILY".
            portfolio_id: Optional portfolio ID for context. If provided, data will be aggregated in portfolio context.
            periodicity: Optional frequency override. One of ["DOD", "WOW", "MOM", "QOQ", "YOY"]. Defaults to None.
        Returns:
            DataFrame with the timeseries data.

        Raises:
            ValueError: If neither start_time nor preset_range is provided.
            ValidationError: If any of the parameters are invalid.
            BadRequestError: If the API request is invalid.
            NotFoundError: If no asset is found with the given ID.

        Examples:
            # Get daily data for multiple assets
            timeseries = client.get_timeseries_batch(
                metric_id=37582,
                asset_ids=[123, 124, 125],
                start_time="2024-12-25T00:00:00-05:00",
                end_time="2024-12-27T00:00:00-05:00"
            )

            # Get data from start time to current datetime
            timeseries = client.get_timeseries_batch(
                metric_id=37582,
                asset_ids=[1, 2, 3],
                start_time="2023-01-01"
            )

            # Get data with custom grain and mode
            timeseries = client.get_timeseries_batch(
                metric_id=37582,
                asset_ids=[1, 2, 3],
                start_time="2023-01-01",
                grain="WEEK",
                mode="DAILY",
                periodicity="WOW"
            )
        """
        if preset_range is None and start_time is None:
            raise ValueError("Either start_time or preset_range must be provided")

        if not portfolio_id and not asset_ids:
            raise ValueError("Either portfolio_id or asset_ids must be provided")

        if end_time is None and preset_range is None:
            end_time = datetime.now().strftime("%Y-%m-%d")

        try:
            request_obj = BatchAssetTimeseriesRequest(
                risk_model_id=risk_model_id,
                time_range=TimeRangeWithGrain(
                    start_time=start_time, end_time=end_time, preset_range=preset_range, grain=grain
                ),
                mode=mode,
                periodicity=periodicity,
                asset_ids=asset_ids,
                portfolio_id=portfolio_id,
            )
        except ValidationError as e:
            raise _handle_validation_error(e, BatchAssetTimeseriesRequest) from None

        response = self._client.post(
            path=f"/api/v1/assets/metrics/{metric_id}/timeseries/batch",
            data=request_obj.model_dump_json(exclude_none=True),
        )
        return self._process_response_for_batch_asset_timeseries(response)

    def update_metric_value_batch(self, snapshots: List[Union[AssetMetricSnapshot, Dict[str, Any]]]) -> None:
        """
        Update a batch of metric values for a list of assets.

        Args:
            snapshots: List of dictionaries containing asset metric snapshot requests.
            Must contain:
                - asset_id [Optional]: ID of the asset.
                - ticker [Optional]: Ticker symbol of the asset.
                - metric_id: ID of the metric.
                - value: Value to be assigned to that metric.
                - as_of_date [Optional]: Date for which the data is being submitted. Must be in YYYY-MM-DD format (timestamps are not accepted) and for a non-future date.

        Notes:
            - Timestamps are not accepted in the as_of_date field; only dates in YYYY-MM-DD format are allowed.
            - If multiple values are supplied for the same asset, metric, and as_of_date, only the last value in the list will be used.

        Returns:
            None

        Raises:
            UnprocessableError: If any of the parameters are invalid.
            BadRequestError: If the API request is invalid.

        Examples:
            # Update a batch of metric values for a list of assets
            snapshots = [
                {"asset_id": 3, "metric_id": 101, "value": 100},
                {"ticker": "AAPL", "metric_id": 102, "value": 100},
                {"asset_id": 1, "metric_id": 105, "value": "Test text", "as_of_date": "2025-06-19"},
            ]
            client.update_metric_value_batch(snapshots=snapshots)
        """
        try:
            converted_snapshots = [
                snapshot if isinstance(snapshot, AssetMetricSnapshot) else AssetMetricSnapshot(**snapshot)
                for snapshot in snapshots
            ]
            request_obj = AssetMetricUploadRequest(data=converted_snapshots)
        except ValidationError as e:
            raise _handle_validation_error(e, AssetMetricUploadRequest) from None

        response = self._client.post(
            path="/api/v1/assets/metrics/batch",
            data=request_obj.model_dump_json(exclude_none=True),
        )
        return self._process_response_for_update_metric_value_batch(response)
