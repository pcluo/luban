# internal/error_handler.py

from __future__ import annotations

from typing import Any, Dict, Type

from arcana.models import error_schemas
from arcana.models.error_schemas import *  # pylint: disable=unused-wildcard-import,wildcard-import


# Build registry of subclasses keyed by their error_code
def _build_error_registry() -> Dict[str, Type[APIError]]:  # type: ignore
    registry = {}
    for name in error_schemas.__all__:
        cls = getattr(error_schemas, name)
        instance = cls()
        registry[instance.error_code] = cls
    return registry


ERROR_CLASSES: Dict[str, Type[APIError]] = _build_error_registry()  # type: ignore


def _parse_api_error_response(data: Any) -> APIError:  # type: ignore
    """
    Parses a raw API error dict into the correct subclass of APIError based on `error_code`.
    Falls back to APIError itself if no match is found.

    Args:
        data (dict[str, Any]): The raw API error response.

    Returns:
        APIError: The parsed error model.
    """

    if not isinstance(data, dict):
        return APIError()  # type: ignore

    error_code = str(data["error_code"])
    error_cls = ERROR_CLASSES.get(error_code, APIError)  # type: ignore
    data = {k: v for k, v in data.items() if k != "error_code"}
    return error_cls(**data)
